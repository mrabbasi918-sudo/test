# api/v1/projects/service.py
from __future__ import annotations
from uuid import UUID
from typing import List

from app.application.usecases.submit_project import SubmitProjectUseCase
from app.application.usecases.evaluate_product import EvaluateProductUseCase
from app.application.usecases.upload_document import UploadDocumentUseCase
from app.application.usecases.manage_user import ManageUserUseCase
from app.application.usecases.approve_invoice import ApproveInvoiceUseCase
from app.api.v1.projects.schemas import ProjectResponse, ProjectVersionResponse, TimelineItem, AllowedTransition


class ProjectService:
    """
    Thin API Service for projects.
    This service does NOT contain business logic.
    It simply calls UseCases and transforms domain entities into Response DTOs.
    """

    def __init__(
        self,
        submit_project_uc: SubmitProjectUseCase,
        evaluate_product_uc: EvaluateProductUseCase,
        upload_document_uc: UploadDocumentUseCase,
        manage_user_uc: ManageUserUseCase,
        approve_invoice_uc: ApproveInvoiceUseCase
    ):
        self.submit_project_uc = submit_project_uc
        self.evaluate_product_uc = evaluate_product_uc
        self.upload_document_uc = upload_document_uc
        self.manage_user_uc = manage_user_uc
        self.approve_invoice_uc = approve_invoice_uc

    # ---------------------------
    # Submit / Create Project
    # ---------------------------
    def submit_project(self, project_id: UUID) -> ProjectResponse:
        project = self.submit_project_uc.execute(project_id)
        return self._to_project_response(project)

    # ---------------------------
    # Upload Document
    # ---------------------------
    def upload_document(self, project_id: UUID, file_ids: list[UUID]) -> ProjectVersionResponse:
        version = self.upload_document_uc.execute(project_id, file_ids)
        return self._to_project_version_response(version)

    # ---------------------------
    # Evaluate Product
    # ---------------------------
    def evaluate_product(self, project_id: UUID, result: str) -> ProjectVersionResponse:
        version = self.evaluate_product_uc.execute(project_id, result)
        return self._to_project_version_response(version)

    # ---------------------------
    # Approve Invoice
    # ---------------------------
    def approve_invoice(self, project_id: UUID, invoice_id: UUID) -> ProjectVersionResponse:
        version = self.approve_invoice_uc.execute(project_id, invoice_id)
        return self._to_project_version_response(version)

    # ---------------------------
    # Helpers to map Domain -> Response DTO
    # ---------------------------
    def _to_project_response(self, project) -> ProjectResponse:
        return ProjectResponse(
            project_id=project.id,
            owner_id=project.owner_id,
            current_version=project.current_version,
            current_state=project.current_state,
            allowed_transitions=[
                AllowedTransition(to_state=t.to_state, action=t.action)
                for t in project.allowed_transitions
            ],
            timeline=[
                TimelineItem(
                    from_state=item.from_state,
                    to_state=item.to_state,
                    actor_id=item.actor_id,
                    role=item.role,
                    reason=item.reason,
                    timestamp=item.timestamp
                )
                for item in project.timeline
            ],
            versions=[self._to_project_version_response(v) for v in project.versions]
        )

    def _to_project_version_response(self, version) -> ProjectVersionResponse:
        return ProjectVersionResponse(
            version=version.version,
            state=version.state,
            is_writable=version.is_writable,
            created_at=version.created_at,
            files=[f.filename for f in version.files]
        )
