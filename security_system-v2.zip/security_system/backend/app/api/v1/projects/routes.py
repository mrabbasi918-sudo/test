from fastapi import APIRouter, Depends
from uuid import UUID
from typing import List
from app.api.v1.projects.schemas import CreateProjectRequest, UpdateProjectCompanyRequest, UpdateProjectProductRequest, ProjectResponse
from app.api.v1.projects.service import ProjectService

router = APIRouter(prefix="/projects", tags=["projects"])

@router.post("/", response_model=ProjectResponse)
def create_project(request: CreateProjectRequest, service: ProjectService = Depends()):
    return service.create_project(request)

@router.put("/{project_id}/company", response_model=ProjectResponse)
def update_company(project_id: UUID, request: UpdateProjectCompanyRequest, service: ProjectService = Depends()):
    return service.update_company(project_id, request)

@router.put("/{project_id}/product", response_model=ProjectResponse)
def update_product(project_id: UUID, request: UpdateProjectProductRequest, service: ProjectService = Depends()):
    return service.update_product(project_id, request)

@router.get("/{project_id}", response_model=ProjectResponse)
def get_project(project_id: UUID, service: ProjectService = Depends()):
    return service.get_project(project_id)
