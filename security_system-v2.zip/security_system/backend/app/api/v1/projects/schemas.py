# api/v1/projects/schemas.py
from __future__ import annotations
from typing import List, Optional
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, Field, conint, constr

# استفاده از Value Objects دامنه برای consistency
from app.domain.value_objects.state import ProjectStateEnum
from app.domain.value_objects.role import RoleEnum


# ---------------------------
# Base Schemas
# ---------------------------
class ProjectVersionBase(BaseModel):
    version: conint(ge=1)
    state: ProjectStateEnum
    is_writable: bool
    created_at: datetime


class ProjectBase(BaseModel):
    project_id: UUID
    current_version: conint(ge=1)
    current_state: ProjectStateEnum
    owner_id: UUID
    created_at: datetime


# ---------------------------
# Timeline / Transition Info
# ---------------------------
class AllowedTransition(BaseModel):
    to_state: ProjectStateEnum
    action: str


class TimelineItem(BaseModel):
    from_state: ProjectStateEnum
    to_state: ProjectStateEnum
    actor_id: UUID
    role: RoleEnum                # اینجا RoleEnum واقعی دامنه استفاده شد
    reason: Optional[str]
    timestamp: datetime


# ---------------------------
# Request Schemas
# ---------------------------
class CreateProjectRequest(BaseModel):
    project_id: UUID = Field(..., description="UUID of the project")
    # initial state is always DRAFT, so no need to send current_state


class UpdateProjectCompanyRequest(BaseModel):
    company_name: constr(min_length=1, max_length=200)
    company_address: Optional[constr(max_length=500)]
    contact_email: Optional[constr(max_length=200)]
    contact_phone: Optional[constr(max_length=20)]


class UpdateProjectProductRequest(BaseModel):
    product_name: constr(min_length=1, max_length=200)
    product_description: Optional[constr(max_length=1000)]
    product_version: Optional[constr(max_length=50)]


# ---------------------------
# Response Schemas
# ---------------------------
class ProjectVersionResponse(ProjectVersionBase):
    files: List[str] = Field(default_factory=list)


class ProjectResponse(ProjectBase):
    allowed_transitions: List[AllowedTransition] = Field(default_factory=list)
    timeline: List[TimelineItem] = Field(default_factory=list)
    versions: List[ProjectVersionResponse] = Field(default_factory=list)
