# api/v1/reports/service.py
from __future__ import annotations
from uuid import UUID
from typing import Optional
from app.application.services.report_service import ReportService as ReportUseCase
from app.api.v1.reports.schemas import CreateReportJobRequest, ReportJobResponse


class ReportService:
    """Thin API Service for report generation."""

    def __init__(self, usecase: ReportUseCase):
        self.usecase = usecase

    def create_report_job(self, request: CreateReportJobRequest) -> ReportJobResponse:
        job = self.usecase.create_job(
            type=request.type,
            from_date=request.from_date,
            to_date=request.to_date,
            parameters=request.parameters
        )
        return ReportJobResponse(**job.dict())

    def get_report_job(self, job_id: UUID) -> ReportJobResponse:
        job = self.usecase.get_job(job_id)
        return ReportJobResponse(**job.dict())
