# api/v1/reports/schemas.py
from __future__ import annotations
from typing import Optional, Dict, Any
from uuid import UUID
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field

# ---------------------------
# Enums
# ---------------------------
class ReportJobStatusEnum(str, Enum):
    PROCESSING = "PROCESSING"
    DONE = "DONE"
    FAILED = "FAILED"


# ---------------------------
# Request Schemas
# ---------------------------
class CreateReportJobRequest(BaseModel):
    type: str = Field(..., description="Type of report, e.g., FINANCIAL, PROJECT_STATUS")
    from_date: Optional[datetime] = Field(None, description="Start of reporting period")
    to_date: Optional[datetime] = Field(None, description="End of reporting period")
    parameters: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional filters or options")


# ---------------------------
# Response Schemas
# ---------------------------
class ReportJobResponse(BaseModel):
    job_id: UUID
    type: str
    status: ReportJobStatusEnum
    parameters: Optional[Dict[str, Any]] = None
    download_url: Optional[str] = None
    created_at: datetime
    completed_at: Optional[datetime] = None
