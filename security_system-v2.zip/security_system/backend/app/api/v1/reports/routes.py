from fastapi import APIRouter, Depends
from uuid import UUID
from app.api.v1.reports.schemas import CreateReportJobRequest, ReportJobResponse
from app.api.v1.reports.service import ReportService

router = APIRouter(prefix="/reports", tags=["reports"])

@router.post("/", response_model=ReportJobResponse)
def create_report_job(request: CreateReportJobRequest, service: ReportService = Depends()):
    return service.create_report_job(request)

@router.get("/{job_id}", response_model=ReportJobResponse)
def get_report_job(job_id: UUID, service: ReportService = Depends()):
    return service.get_report_job(job_id)
