from fastapi import APIRouter, Depends
from uuid import UUID
from typing import List
from app.api.v1.users.schemas import CreateUserRequest, UpdateUserRequest, UserResponse
from app.api.v1.users.service import UserService

router = APIRouter(prefix="/users", tags=["users"])

@router.post("/", response_model=UserResponse)
def create_user(request: CreateUserRequest, service: UserService = Depends()):
    return service.create_user(request)

@router.get("/{user_id}", response_model=UserResponse)
def get_user(user_id: UUID, service: UserService = Depends()):
    return service.get_user(user_id)

@router.get("/", response_model=List[UserResponse])
def list_users(service: UserService = Depends()):
    return service.list_users()

@router.put("/{user_id}", response_model=UserResponse)
def update_user(user_id: UUID, request: UpdateUserRequest, service: UserService = Depends()):
    return service.update_user(user_id, request)

@router.delete("/{user_id}", response_model=bool)
def delete_user(user_id: UUID, service: UserService = Depends()):
    return service.delete_user(user_id)
