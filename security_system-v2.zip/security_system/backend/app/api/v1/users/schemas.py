# api/v1/users/schemas.py
from __future__ import annotations
from typing import Optional, Literal
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, constr, Field

from app.domain.value_objects.role import RoleEnum
from app.core.constants import UserStatusEnum  # فرض بر این است که در constants تعریف شده

# ---------------------------
# Base Schemas
# ---------------------------
class UserBase(BaseModel):
    full_name: constr(min_length=1, max_length=200)
    mobile: constr(regex=r"^09\d{9}$")
    role: RoleEnum
    status: UserStatusEnum

    class Config:
        orm_mode = True


# ---------------------------
# Request Schemas
# ---------------------------
class CreateUserRequest(UserBase):
    password: constr(min_length=8, max_length=128)


class UpdateUserRequest(BaseModel):
    full_name: Optional[constr(min_length=1, max_length=200)] = None
    mobile: Optional[constr(regex=r"^09\d{9}$")] = None
    role: Optional[RoleEnum] = None
    status: Optional[UserStatusEnum] = None


# ---------------------------
# Response Schemas
# ---------------------------
class UserResponse(UserBase):
    id: UUID
    created_at: datetime
    updated_at: datetime
