# api/v1/users/service.py
from __future__ import annotations
from uuid import UUID
from typing import List, Optional

from app.application.usecases.manage_user import ManageUserUseCase
from app.api.v1.users.schemas import UserResponse, CreateUserRequest, UpdateUserRequest
from app.domain.value_objects.role import RoleEnum
from app.core.constants import UserStatusEnum


class UserService:
    """
    Thin API Service for user management.
    Calls underlying UseCase (ManageUserUseCase) and maps domain entities to Response DTOs.
    """

    def __init__(self, user_uc: ManageUserUseCase):
        self.user_uc = user_uc

    # ---------------------------
    # CREATE USER
    # ---------------------------
    def create_user(self, user_data: CreateUserRequest) -> UserResponse:
        user = self.user_uc.create_user(user_data)
        return self._to_user_response(user)

    # ---------------------------
    # GET USER
    # ---------------------------
    def get_user(self, user_id: UUID) -> UserResponse:
        user = self.user_uc.get_user(user_id)
        return self._to_user_response(user)

    # ---------------------------
    # LIST USERS
    # ---------------------------
    def list_users(self, skip: int = 0, limit: int = 100) -> List[UserResponse]:
        users = self.user_uc.list_users(skip, limit)
        return [self._to_user_response(u) for u in users]

    # ---------------------------
    # UPDATE USER
    # ---------------------------
    def update_user(self, user_id: UUID, user_data: UpdateUserRequest) -> UserResponse:
        user = self.user_uc.update_user(user_id, user_data)
        return self._to_user_response(user)

    # ---------------------------
    # DELETE USER
    # ---------------------------
    def delete_user(self, user_id: UUID) -> bool:
        return self.user_uc.delete_user(user_id)

    # ---------------------------
    # HELPER: map domain entity -> DTO
    # ---------------------------
    @staticmethod
    def _to_user_response(user) -> UserResponse:
        return UserResponse(
            id=user.id,
            full_name=user.full_name,
            mobile=user.mobile,
            role=RoleEnum(user.role),
            status=UserStatusEnum(user.status),
            created_at=user.created_at,
            updated_at=user.updated_at
        )
