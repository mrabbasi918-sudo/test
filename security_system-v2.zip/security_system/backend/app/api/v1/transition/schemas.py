# api/v1/transition/schemas.py
from __future__ import annotations
from typing import Optional
from uuid import UUID
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, conint

from app.domain.value_objects.state import ProjectStateEnum
from app.domain.value_objects.role import RoleEnum


# ---------------------------
# Enums
# ---------------------------
class TransitionStatusEnum(str, Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"


# ---------------------------
# Request Schema
# ---------------------------
class TransitionRequest(BaseModel):
    project_id: UUID
    to_state: ProjectStateEnum
    reason: Optional[str] = Field(None, max_length=500)
    expected_version: conint(ge=1)  # optimistic locking


# ---------------------------
# Response Schema
# ---------------------------
class TransitionResponse(BaseModel):
    project_id: UUID
    project_version: conint(ge=1)
    from_state: ProjectStateEnum
    to_state: ProjectStateEnum
    status: TransitionStatusEnum
    timestamp: datetime
    detail: Optional[str] = None  # optional error or validation message
