from __future__ import annotations
from uuid import UUID
from typing import List
from app.application.usecases.submit_project import ProjectTransitionUseCase
from app.api.v1.transition.schemas import TransitionRequest, TransitionResponse, AllowedTransition
from app.domain.value_objects.role import UserRole
from app.domain.state_machine.state_machine import TransitionResult


class TransitionService:
    """Service for project state transitions."""

    def __init__(self, usecase: ProjectTransitionUseCase):
        self.usecase = usecase

    async def apply_transition(
        self,
        request: TransitionRequest,
        actor_id: UUID,
        actor_role: UserRole
    ) -> TransitionResponse:
        result: TransitionResult = await self.usecase.apply_transition(
            project_id=request.project_id,
            to_state=request.to_state,
            reason=request.reason,
            expected_version=request.expected_version,
            actor_id=str(actor_id),
            actor_role=actor_role
        )

        return TransitionResponse(
            project_id=request.project_id,
            project_version=result.project_version,  # version واقعی از entity
            from_state=result.from_state.value,
            to_state=result.to_state.value,
            status="success" if result.success else "failed",
            timestamp=result.timestamp,
            detail=result.message
        )

    async def get_allowed_transitions(
        self,
        project_id: UUID,
        actor_role: UserRole
    ) -> List[AllowedTransition]:
        transitions = await self.usecase.get_allowed_transitions(project_id, actor_role)
        return [
            AllowedTransition(
                to_state=t["to_state"].value,
                action=t.get("side_effects")
            )
            for t in transitions
        ]
