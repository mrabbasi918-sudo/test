from fastapi import APIRouter, Depends, HTTPException
from uuid import UUID
from typing import List
from app.api.v1.transition.schemas import TransitionRequest, TransitionResponse, AllowedTransition
from app.api.v1.transition.service import TransitionService
from app.core.security import get_current_user
from app.domain.value_objects.role import UserRole

router = APIRouter(prefix="/transition", tags=["transition"])

@router.post("/{project_id}", response_model=TransitionResponse)
async def apply_transition(
    project_id: UUID,
    request: TransitionRequest,
    current_user=Depends(get_current_user),
    service: TransitionService = Depends()
):
    """
    اجرای transition روی پروژه
    """
    if request.project_id != str(project_id):
        raise HTTPException(status_code=400, detail="Project ID mismatch between path and request body")
    try:
        return await service.apply_transition(
            request=request,
            actor_id=current_user.id,
            actor_role=current_user.role
        )
    except Exception as e:
        # می‌توان دقیق‌تر دسته‌بندی کرد (ValidationError, PermissionDenied ...)
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{project_id}/allowed", response_model=List[AllowedTransition])
async def allowed_transitions(
    project_id: UUID,
    current_user=Depends(get_current_user),
    service: TransitionService = Depends()
):
    """
    دریافت لیست transitionهای مجاز برای نقش فعلی
    """
    try:
        return await service.get_allowed_transitions(
            project_id=project_id,
            actor_role=current_user.role
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
