from fastapi import APIRouter, Depends
from app.api.v1.audit.schemas import AuditLogQueryRequest, AuditLogResponse
from app.api.v1.audit.service import AuditService

router = APIRouter(prefix="/audit", tags=["audit"])

@router.post("/query", response_model=AuditLogResponse)
def query_audit_logs(request: AuditLogQueryRequest, service: AuditService = Depends()):
    return service.query_logs(request)
