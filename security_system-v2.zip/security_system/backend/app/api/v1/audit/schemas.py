# api/v1/audit/schemas.py
from __future__ import annotations
from typing import Optional, List
from uuid import UUID
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, conint

from app.domain.value_objects.state import ProjectStateEnum
from app.domain.value_objects.role import RoleEnum


# ---------------------------
# Request Schema
# ---------------------------
class AuditLogQueryRequest(BaseModel):
    project_id: Optional[UUID] = None
    user_id: Optional[UUID] = None
    action_type: Optional[str] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    page: Optional[conint(ge=1)] = 1
    size: Optional[conint(ge=1, le=100)] = 50


# ---------------------------
# Response Schema
# ---------------------------
class AuditLogItem(BaseModel):
    log_id: UUID
    project_id: Optional[UUID] = None
    project_version: Optional[conint(ge=1)] = None
    actor_id: UUID
    role: RoleEnum
    action_type: str
    from_state: Optional[ProjectStateEnum] = None
    to_state: Optional[ProjectStateEnum] = None
    reason: Optional[str] = None
    timestamp: datetime


class AuditLogResponse(BaseModel):
    logs: List[AuditLogItem] = Field(default_factory=list)
    total_count: int
    page: int
    size: int
