# api/v1/audit/service.py
from __future__ import annotations
from uuid import UUID
from typing import List
from app.application.services.audit_service import AuditUseCase
from app.api.v1.audit.schemas import AuditLogQueryRequest, AuditLogResponse, AuditLogItem


class AuditService:
    """Thin API Service for audit logs."""

    def __init__(self, usecase: AuditUseCase):
        self.usecase = usecase

    def query_logs(self, request: AuditLogQueryRequest) -> AuditLogResponse:
        logs, total_count = self.usecase.query_logs(
            project_id=request.project_id,
            user_id=request.user_id,
            action_type=request.action_type,
            from_date=request.from_date,
            to_date=request.to_date,
            skip=(request.page - 1) * request.size,
            limit=request.size
        )

        return AuditLogResponse(
            logs=[AuditLogItem(**log.dict()) for log in logs],
            total_count=total_count,
            page=request.page,
            size=request.size
        )
