from fastapi import APIRouter, Depends
from uuid import UUID
from app.api.v1.auth.schemas import LoginRequest, LoginResponse, OTPRequest, OTPVerificationRequest, OTPResponse
from app.api.v1.auth.service import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login", response_model=LoginResponse)
def login(request: LoginRequest, service: AuthService = Depends()):
    return service.login(request.username, request.password)

@router.post("/otp/send", response_model=OTPResponse)
def send_otp(request: OTPRequest, service: AuthService = Depends()):
    return service.send_otp(request.mobile)

@router.post("/otp/verify", response_model=OTPResponse)
def verify_otp(request: OTPVerificationRequest, service: AuthService = Depends()):
    return service.verify_otp(request.mobile, request.otp, request.new_password)
