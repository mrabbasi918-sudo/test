# api/v1/auth/schemas.py
from __future__ import annotations
from typing import Optional, Literal
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, Field, constr

from app.domain.value_objects.role import RoleEnum


# ---------------------------
# Request Schemas
# ---------------------------
class LoginRequest(BaseModel):
    username: constr(min_length=3, max_length=150)
    password: constr(min_length=6)
    captcha: Optional[constr(max_length=10)] = None


class OTPRequest(BaseModel):
    mobile: constr(regex=r"^09\d{9}$")
    captcha: Optional[constr(max_length=10)] = None


class OTPVerificationRequest(BaseModel):
    mobile: constr(regex=r"^09\d{9}$")
    otp: constr(min_length=4, max_length=6)
    new_password: Optional[constr(min_length=6)] = None


# ---------------------------
# Response Schemas
# ---------------------------
class LoginResponse(BaseModel):
    access_token: str
    token_type: Literal["bearer"] = "bearer"
    user_id: UUID
    role: RoleEnum
    expired_at: datetime


class LogoutResponse(BaseModel):
    message: str = Field(default="Successfully logged out")


class OTPResponse(BaseModel):
    message: str
