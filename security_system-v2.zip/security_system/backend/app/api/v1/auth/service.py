# api/v1/auth/service.py
from __future__ import annotations
from typing import Optional
from uuid import UUID
from datetime import datetime, timedelta

from app.application.services.auth_service import AuthService as AuthUseCase
from app.api.v1.auth.schemas import LoginResponse, OTPResponse
from app.domain.value_objects.role import RoleEnum


class AuthService:
    """
    Thin API Service for authentication.
    Calls underlying AuthUseCase and maps results to Response DTOs.
    """

    def __init__(self, auth_uc: AuthUseCase):
        self.auth_uc = auth_uc

    # ---------------------------
    # LOGIN
    # ---------------------------
    def login(self, username: str, password: str) -> LoginResponse:
        result = self.auth_uc.login(username, password)
        return LoginResponse(
            access_token=result["access_token"],
            refresh_token=result["refresh_token"],
            token_type="bearer",
            user_id=result["user_id"],
            role=RoleEnum(result["role"]),
            expired_at=result["expired_at"],
            refresh_token_expired_at=result["refresh_token_expired_at"]
        )

    # ---------------------------
    # SEND OTP
    # ---------------------------
    def send_otp(self, mobile: str) -> OTPResponse:
        self.auth_uc.send_otp(mobile)
        return OTPResponse(message=f"OTP sent to {mobile}")

    # ---------------------------
    # VERIFY OTP
    # ---------------------------
    def verify_otp(self, mobile: str, otp: str, new_password: Optional[str] = None) -> OTPResponse:
        self.auth_uc.verify_otp(mobile, otp, new_password)
        return OTPResponse(message="OTP verified successfully")
