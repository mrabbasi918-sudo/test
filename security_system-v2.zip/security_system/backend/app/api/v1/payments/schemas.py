# api/v1/payments/schemas.py
from __future__ import annotations
from typing import Optional
from uuid import UUID
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, condecimal

from app.domain.value_objects.state import ProjectStateEnum
from app.domain.value_objects.money import Money


# ---------------------------
# Enums
# ---------------------------
class InvoiceStatusEnum(str, Enum):
    PENDING = "PENDING"
    PAID = "PAID"
    CANCELED = "CANCELED"


class PaymentStatusEnum(str, Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"


# ---------------------------
# Request Schemas
# ---------------------------
class CreateInvoiceRequest(BaseModel):
    project_id: UUID
    amount: condecimal(gt=0, max_digits=18, decimal_places=2)


class CreatePaymentRequest(BaseModel):
    project_id: UUID
    invoice_id: UUID
    amount: condecimal(gt=0, max_digits=18, decimal_places=2)


# ---------------------------
# Response Schemas
# ---------------------------
class InvoiceResponse(BaseModel):
    invoice_id: UUID
    project_id: UUID
    project_version: int
    amount: condecimal(gt=0, max_digits=18, decimal_places=2)
    status: InvoiceStatusEnum
    created_at: datetime


class PaymentResponse(BaseModel):
    payment_id: UUID
    invoice_id: UUID
    project_id: UUID
    project_version: int
    amount: condecimal(gt=0, max_digits=18, decimal_places=2)
    status: PaymentStatusEnum
    timestamp: datetime
