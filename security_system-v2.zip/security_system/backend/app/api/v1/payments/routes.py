from fastapi import APIRouter, Depends
from uuid import UUID
from typing import List
from app.api.v1.payments.schemas import CreateInvoiceRequest, CreatePaymentRequest, InvoiceResponse, PaymentResponse
from app.api.v1.payments.service import PaymentService

router = APIRouter(prefix="/payments", tags=["payments"])

@router.post("/invoice", response_model=InvoiceResponse)
def create_invoice(request: CreateInvoiceRequest, service: PaymentService = Depends()):
    return service.create_invoice(request)

@router.post("/payment", response_model=PaymentResponse)
def create_payment(request: CreatePaymentRequest, service: PaymentService = Depends()):
    return service.create_payment(request)

@router.get("/invoice/{invoice_id}", response_model=InvoiceResponse)
def get_invoice(invoice_id: UUID, service: PaymentService = Depends()):
    return service.get_invoice(invoice_id)
