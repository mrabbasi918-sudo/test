# api/v1/payments/service.py
from __future__ import annotations
from uuid import UUID
from typing import List
from app.application.usecases.approve_invoice import PaymentUseCase
from app.api.v1.payments.schemas import CreateInvoiceRequest, CreatePaymentRequest, InvoiceResponse, PaymentResponse


class PaymentService:
    """Thin API Service for payments and invoices."""

    def __init__(self, usecase: PaymentUseCase):
        self.usecase = usecase

    def create_invoice(self, request: CreateInvoiceRequest) -> InvoiceResponse:
        invoice = self.usecase.create_invoice(request.project_id, request.amount)
        return InvoiceResponse(**invoice.dict())

    def create_payment(self, request: CreatePaymentRequest) -> PaymentResponse:
        payment = self.usecase.create_payment(request.project_id, request.invoice_id, request.amount)
        return PaymentResponse(**payment.dict())

    def get_invoice(self, invoice_id: UUID) -> InvoiceResponse:
        invoice = self.usecase.get_invoice(invoice_id)
        return InvoiceResponse(**invoice.dict())
