# api/v1/files/service.py
from __future__ import annotations
from uuid import UUID
from typing import List
from app.application.usecases.upload_document import FileUseCase
from app.api.v1.files.schemas import UploadFileRequest, DeleteFileRequest, FileResponse


class FileService:
    """Thin API Service for file management."""

    def __init__(self, usecase: FileUseCase):
        self.usecase = usecase

    def upload_file(self, request: UploadFileRequest) -> FileResponse:
        file = self.usecase.upload_file(
            project_id=request.project_id,
            project_version=request.project_version,
            filename=request.filename,
            extension=request.extension,
            size=request.size,
            description=request.description
        )
        return FileResponse(**file.dict())

    def delete_file(self, request: DeleteFileRequest) -> bool:
        return self.usecase.delete_file(request.file_id)
