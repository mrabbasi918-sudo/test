from fastapi import APIRouter, Depends
from uuid import UUID
from typing import List
from app.api.v1.files.schemas import UploadFileRequest, DeleteFileRequest, FileResponse
from app.api.v1.files.service import FileService

router = APIRouter(prefix="/files", tags=["files"])

@router.post("/", response_model=FileResponse)
def upload_file(request: UploadFileRequest, service: FileService = Depends()):
    return service.upload_file(request)

@router.delete("/", response_model=bool)
def delete_file(request: DeleteFileRequest, service: FileService = Depends()):
    return service.delete_file(request)
