# api/v1/files/schemas.py
from __future__ import annotations
from typing import Optional
from uuid import UUID
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, conint, constr

from app.domain.value_objects.state import ProjectStateEnum
from app.domain.value_objects.role import RoleEnum


# ---------------------------
# Enums
# ---------------------------
class FileStatusEnum(str, Enum):
    UPLOADED = "UPLOADED"
    DELETED = "DELETED"


class FileExtensionEnum(str, Enum):
    ZIP = "zip"
    RAR = "rar"


# ---------------------------
# Request Schemas
# ---------------------------
class UploadFileRequest(BaseModel):
    filename: constr(min_length=1, max_length=255)
    extension: FileExtensionEnum
    size: conint(ge=1, le=104_857_600)  # Max 100MB
    # Optional: additional metadata
    description: Optional[constr(max_length=500)] = None


class DeleteFileRequest(BaseModel):
    file_id: UUID


# ---------------------------
# Response Schemas
# ---------------------------
class FileResponse(BaseModel):
    file_id: UUID
    project_id: UUID
    project_version: conint(ge=1)
    filename: str
    extension: FileExtensionEnum
    size: int
    path: str
    status: FileStatusEnum
    uploaded_by: Optional[UUID] = None
    created_at: datetime
