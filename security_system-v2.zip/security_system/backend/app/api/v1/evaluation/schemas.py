# api/v1/evaluation/schemas.py
from __future__ import annotations
from typing import List, Optional
from uuid import UUID
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, conint, constr

from app.domain.value_objects.state import ProjectStateEnum


# ---------------------------
# Enums
# ---------------------------
class EvaluationResultEnum(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"


# ---------------------------
# Request Schemas
# ---------------------------
class SubmitDocumentRequest(BaseModel):
    project_version: conint(ge=1)
    file_ids: List[UUID]
    description: Optional[constr(max_length=500)] = None


class SubmitEvaluationResultRequest(BaseModel):
    project_version: conint(ge=1)
    result_status: EvaluationResultEnum
    report_file_id: Optional[UUID] = None
    comments: Optional[constr(max_length=1000)] = None


# ---------------------------
# Response Schemas
# ---------------------------
class DocumentResponse(BaseModel):
    file_id: UUID
    project_id: UUID
    project_version: conint(ge=1)
    filename: str
    uploaded_by: UUID
    created_at: datetime


class EvaluationResultResponse(BaseModel):
    project_id: UUID
    project_version: conint(ge=1)
    result_status: EvaluationResultEnum
    report_file_id: Optional[UUID] = None
    comments: Optional[str] = None
    submitted_at: datetime
