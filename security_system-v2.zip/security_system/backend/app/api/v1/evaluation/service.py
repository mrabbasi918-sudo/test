# api/v1/evaluation/service.py
from __future__ import annotations
from uuid import UUID
from typing import List
from app.application.usecases.evaluate_product import EvaluationUseCase
from app.api.v1.evaluation.schemas import SubmitDocumentRequest, SubmitEvaluationResultRequest, DocumentResponse, EvaluationResultResponse


class EvaluationService:
    """Thin API Service for product/document evaluations."""

    def __init__(self, usecase: EvaluationUseCase):
        self.usecase = usecase

    def submit_document(self, request: SubmitDocumentRequest) -> List[DocumentResponse]:
        docs = self.usecase.submit_document(
            project_version=request.project_version,
            file_ids=request.file_ids,
            description=request.description
        )
        return [DocumentResponse(**d.dict()) for d in docs]

    def submit_evaluation(self, request: SubmitEvaluationResultRequest) -> EvaluationResultResponse:
        result = self.usecase.submit_evaluation(
            project_version=request.project_version,
            result_status=request.result_status,
            report_file_id=request.report_file_id,
            comments=request.comments
        )
        return EvaluationResultResponse(**result.dict())
