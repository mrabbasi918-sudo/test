from fastapi import APIRouter, Depends
from typing import List
from app.api.v1.evaluation.schemas import SubmitDocumentRequest, SubmitEvaluationResultRequest, DocumentResponse, EvaluationResultResponse
from app.api.v1.evaluation.service import EvaluationService

router = APIRouter(prefix="/evaluation", tags=["evaluation"])

@router.post("/document", response_model=List[DocumentResponse])
def submit_document(request: SubmitDocumentRequest, service: EvaluationService = Depends()):
    return service.submit_document(request)

@router.post("/result", response_model=EvaluationResultResponse)
def submit_evaluation(request: SubmitEvaluationResultRequest, service: EvaluationService = Depends()):
    return service.submit_evaluation(request)
