# core/exceptions.py

from typing import Optional


# =========================
# Base Domain Exception
# =========================

class DomainException(Exception):
    """
    پایه‌ی همه Exceptionهای دامنه و سیستم.
    """
    def __init__(self, message: str, code: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.code = code


# =========================
# State Machine Exceptions
# =========================

class StateTransitionNotAllowed(DomainException):
    """
    پرتاب می‌شود وقتی که تغییر State توسط نقش غیرمجاز یا transition غیرمجاز اتفاق می‌افتد.
    """
    def __init__(self, project_id: str, from_state: str, to_state: str, role: str):
        message = (
            f"Project '{project_id}': transition from '{from_state}' "
            f"to '{to_state}' not allowed for role '{role}'."
        )
        super().__init__(message, code="STATE_TRANSITION_NOT_ALLOWED")
        self.project_id = project_id
        self.from_state = from_state
        self.to_state = to_state
        self.role = role


class OptimisticLockFailed(DomainException):
    """
    وقتی که نسخه پروژه (project_version) تغییر کرده و optimistic locking شکست خورده است.
    """
    def __init__(self, project_id: str, expected_version: int, actual_version: int):
        message = (
            f"Project '{project_id}': optimistic lock failed. "
            f"Expected version {expected_version}, actual {actual_version}."
        )
        super().__init__(message, code="OPTIMISTIC_LOCK_FAILED")
        self.project_id = project_id
        self.expected_version = expected_version
        self.actual_version = actual_version


# =========================
# Permission / Auth Exceptions
# =========================

class PermissionDenied(DomainException):
    """
    وقتی کاربر به منبع یا Action دسترسی ندارد.
    """
    def __init__(self, user_id: str, action: str, role: str):
        message = f"User '{user_id}' with role '{role}' cannot perform action '{action}'."
        super().__init__(message, code="PERMISSION_DENIED")
        self.user_id = user_id
        self.action = action
        self.role = role


class AuthenticationFailed(DomainException):
    """
    شکست Authentication (رمز عبور اشتباه یا OTP نامعتبر)
    """
    def __init__(self, user_id: Optional[str] = None, reason: str = "Authentication failed"):
        message = f"Authentication failed for user '{user_id}'." if user_id else reason
        super().__init__(message, code="AUTH_FAILED")
        self.user_id = user_id
        self.reason = reason


# =========================
# Validation Exceptions
# =========================

class DomainValidationError(DomainException):
    """
    وقتی داده ورودی با قوانین دامنه یا Schema همخوانی ندارد.
    """
    def __init__(self, field: str, message: str):
        full_message = f"Validation error for field '{field}': {message}"
        super().__init__(full_message, code="VALIDATION_ERROR")
        self.field = field
        self.details = message


# =========================
# OTP / Security Exceptions
# =========================

class OTPExpired(DomainException):
    """
    OTP منقضی شده است.
    """
    def __init__(self, otp_id: Optional[str] = None, user_id: Optional[str] = None):
        message = f"OTP '{otp_id}' expired for user '{user_id}'."
        super().__init__(message, code="OTP_EXPIRED")
        self.otp_id = otp_id
        self.user_id = user_id


class OTPInvalid(DomainException):
    """
    OTP نامعتبر است.
    """
    def __init__(self, otp_id: Optional[str] = None, user_id: Optional[str] = None):
        message = f"OTP '{otp_id}' is invalid for user '{user_id}'."
        super().__init__(message, code="OTP_INVALID")
        self.otp_id = otp_id
        self.user_id = user_id


class UserLocked(DomainException):
    """
    وقتی کاربر به دلیل تلاش ناموفق زیاد قفل شده باشد.
    """
    def __init__(self, user_id: str, failed_attempts: int):
        message = f"User '{user_id}' is locked after {failed_attempts} failed login attempts."
        super().__init__(message, code="USER_LOCKED")
        self.user_id = user_id
        self.failed_attempts = failed_attempts
