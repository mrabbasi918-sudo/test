from enum import Enum


# =========================
# User & Auth
# =========================

class UserRole(str, Enum):
    CUSTOMER = "CUSTOMER"
    INTERNAL_MANAGER = "INTERNAL_MANAGER"
    TECH_MANAGER = "TECH_MANAGER"
    SUPER_ADMIN = "SUPER_ADMIN"


class UserStatus(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    LOCKED = "LOCKED"


# =========================
# Project State Machine
# =========================

class ProjectState(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    INTERNAL_REVIEW = "INTERNAL_REVIEW"
    TECH_REVIEW = "TECH_REVIEW"
    REVISION_REQUIRED_INITIAL = "REVISION_REQUIRED_INITIAL"
    INVOICE_SENT = "INVOICE_SENT"
    WAITING_FOR_PREPAYMENT = "WAITING_FOR_PREPAYMENT"
    WAITING_FOR_DOCUMENTS = "WAITING_FOR_DOCUMENTS"
    DOCUMENT_EVALUATING = "DOCUMENT_EVALUATING"
    WAITING_FOR_INSTALLATION = "WAITING_FOR_INSTALLATION"
    PRODUCT_EVALUATING = "PRODUCT_EVALUATING"
    WAITING_FOR_UPDATE = "WAITING_FOR_UPDATE"
    COMPLETED = "COMPLETED"
    CANCELED = "CANCELED"
    CLOSED = "CLOSED"


# =========================
# Invoice & Payment
# =========================

class InvoiceStatus(str, Enum):
    PENDING = "PENDING"
    PAID = "PAID"
    CANCELED = "CANCELED"


# =========================
# File Management
# =========================

ALLOWED_FILE_EXTENSIONS = {"zip", "rar"}
MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024  # 100MB

MINIO_PROJECT_PATH_TEMPLATE = "/project-{project_id}/v{project_version}"


# =========================
# OTP & Security
# =========================

OTP_EXPIRATION_SECONDS = 120  # 2 minutes
OTP_RATE_LIMIT_PER_MINUTE = 5

MAX_FAILED_LOGIN_ATTEMPTS = 5


# =========================
# Headers
# =========================

HEADER_REQUEST_ID = "X-Request-Id"
HEADER_IDEMPOTENCY_KEY = "Idempotency-Key"


# =========================
# Audit & Logging
# =========================

AUDIT_ACTION_STATE_TRANSITION = "STATE_TRANSITION"
AUDIT_ACTION_LOGIN = "LOGIN"
AUDIT_ACTION_LOGOUT = "LOGOUT"
AUDIT_ACTION_FILE_UPLOAD = "FILE_UPLOAD"
AUDIT_ACTION_FILE_DELETE = "FILE_DELETE"
AUDIT_ACTION_PAYMENT = "PAYMENT"


# =========================
# Pagination Defaults
# =========================

DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100
