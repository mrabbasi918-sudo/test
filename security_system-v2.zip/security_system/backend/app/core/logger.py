import logging
import sys
from typing import Optional, Dict, Any


DEFAULT_LOG_LEVEL = logging.INFO


class ContextFilter(logging.Filter):
    """
    Inject contextual information into log records.
    """

    def __init__(
        self,
        request_id: Optional[str] = None,
        user_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ):
        super().__init__()
        self.request_id = request_id
        self.user_id = user_id
        self.project_id = project_id

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = self.request_id
        record.user_id = self.user_id
        record.project_id = self.project_id
        return True


class JsonLikeFormatter(logging.Formatter):
    """
    Structured log formatter (JSON-like, without external deps).
    """

    def format(self, record: logging.LogRecord) -> str:
        log: Dict[str, Any] = {
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "time": self.formatTime(record, self.datefmt),
        }

        if hasattr(record, "request_id") and record.request_id:
            log["request_id"] = record.request_id

        if hasattr(record, "user_id") and record.user_id:
            log["user_id"] = record.user_id

        if hasattr(record, "project_id") and record.project_id:
            log["project_id"] = record.project_id

        if record.exc_info:
            log["exception"] = self.formatException(record.exc_info)

        return str(log)


def get_logger(
    name: str,
    *,
    request_id: Optional[str] = None,
    user_id: Optional[str] = None,
    project_id: Optional[str] = None,
    level: int = DEFAULT_LOG_LEVEL,
) -> logging.Logger:
    """
    Returns a configured logger instance.
    """

    logger = logging.getLogger(name)

    if logger.handlers:
        return logger  # Prevent duplicate handlers

    logger.setLevel(level)
    logger.propagate = False

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(JsonLikeFormatter())

    handler.addFilter(
        ContextFilter(
            request_id=request_id,
            user_id=user_id,
            project_id=project_id,
        )
    )

    logger.addHandler(handler)

    return logger
