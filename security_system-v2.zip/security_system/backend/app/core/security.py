import secrets
import time
from passlib.context import CryptContext

from app.core.constants import (
    OTP_EXPIRATION_SECONDS,
    MAX_FAILED_LOGIN_ATTEMPTS,
)


# =========================
# Password Hashing
# =========================

_pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto"
)


def hash_password(password: str) -> str:
    """
    Hash plain password using bcrypt.
    """
    return _pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify plain password against stored hash.
    """
    return _pwd_context.verify(plain_password, hashed_password)


# =========================
# OTP Management
# =========================

def generate_otp() -> str:
    """
    Generate a secure 6-digit OTP.
    """
    return f"{secrets.randbelow(1_000_000):06d}"


def is_otp_expired(created_at_epoch: int) -> bool:
    """
    Check whether OTP is expired based on creation timestamp.
    """
    return (time.time() - created_at_epoch) > OTP_EXPIRATION_SECONDS


# =========================
# Login Failure / Lock Logic
# =========================

def should_lock_user(failed_login_count: int) -> bool:
    """
    Determine whether user account should be locked.
    """
    return failed_login_count >= MAX_FAILED_LOGIN_ATTEMPTS


def reset_failed_login() -> int:
    """
    Reset failed login counter after successful authentication.
    """
    return 0


def increment_failed_login(current_count: int) -> int:
    """
    Increase failed login counter safely.
    """
    return current_count + 1
