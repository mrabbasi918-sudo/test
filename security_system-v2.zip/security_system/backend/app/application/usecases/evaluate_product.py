from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError

from domain.entities.project import Project
from domain.value_objects.role import UserRole
from domain.value_objects.state import ProjectState
from core.exceptions import PermissionDenied, RepositoryError
from infrastructure.db.repositories.project_repo import ProjectRepository
from infrastructure.db.repositories.audit_repo import AuditRepository

class EvaluateProductUseCase:
    ALLOWED_ROLES = [UserRole.TECH_MANAGER, UserRole.INTERNAL_MANAGER]

    def __init__(
        self,
        project_repo: ProjectRepository,
        audit_repo: AuditRepository,
        session: AsyncSession
    ):
        self.project_repo = project_repo
        self.audit_repo = audit_repo
        self.session = session

    async def execute(self, project: Project, actor_id: str, actor_role: UserRole) -> dict:
        if actor_role not in self.ALLOWED_ROLES:
            await self.audit_repo.create(
                action="EVALUATE_PRODUCT_UNAUTHORIZED",
                user_id=actor_id,
                details=f"Unauthorized role {actor_role.name} attempted to evaluate project {project.id}"
            )
            raise PermissionDenied("Role not allowed to evaluate product")

        try:
            async with self.session.begin():
                # Set project state to COMPLETED
                project.current_state = ProjectState.COMPLETED
                await self.project_repo.save(project)

                # Audit log
                await self.audit_repo.create(
                    action="EVALUATE_PRODUCT",
                    user_id=actor_id,
                    details=f"Product evaluated, project {project.id} marked as COMPLETED"
                )

            return {
                "project_id": project.id,
                "status": "COMPLETED",
                "evaluated_at": datetime.utcnow().isoformat(),
                "evaluated_by": actor_id
            }

        except SQLAlchemyError as exc:
            await self.audit_repo.create(
                action="EVALUATE_PRODUCT_FAILED",
                user_id=actor_id,
                details=f"Failed to evaluate project {project.id}: {exc}"
            )
            raise RepositoryError(f"Failed to evaluate project {project.id}") from exc
