# application/usecases/approve_invoice.py
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError

from domain.entities.invoice import Invoice
from domain.value_objects.role import UserRole
from domain.value_objects.invoice_status import InvoiceStatus
from infrastructure.db.repositories.invoice_repo import InvoiceRepository
from application.services.audit_service import AuditService
from core.exceptions import RepositoryError, PermissionDenied, NotFound

class ApproveInvoiceUseCase:
    """
    Phase 4 hardened use case for approving invoices.
    Responsibilities:
    - RBAC enforcement
    - Audit logging
    - Atomic save
    """

    def __init__(
        self,
        invoice_repo: InvoiceRepository,
        audit_service: AuditService,
        session: AsyncSession
    ):
        self.invoice_repo = invoice_repo
        self.audit_service = audit_service
        self.session = session

    async def execute(self, invoice: Invoice, actor_id: str, actor_role: UserRole) -> dict:
        # RBAC: Only INTERNAL_MANAGER or SYSTEM can approve
        if actor_role not in [UserRole.INTERNAL_MANAGER, UserRole.SYSTEM]:
            await self.audit_service.log_security_warning({
                "event": "APPROVE_INVOICE_UNAUTHORIZED",
                "invoice_id": invoice.id,
                "actor_id": actor_id,
                "actor_role": actor_role.name
            })
            raise PermissionDenied("Role not allowed to approve invoice")

        try:
            async with self.session.begin():
                invoice.status = InvoiceStatus.APPROVED
                invoice.approved_at = datetime.utcnow()
                invoice.approved_by = actor_id

                await self.invoice_repo.save(invoice)

                await self.audit_service.log_info({
                    "event": "APPROVE_INVOICE",
                    "invoice_id": invoice.id,
                    "actor_id": actor_id
                })

            return {
                "invoice_id": invoice.id,
                "status": "APPROVED",
                "approved_at": invoice.approved_at.isoformat(),
                "approved_by": actor_id
            }

        except (SQLAlchemyError, RepositoryError) as exc:
            await self.audit_service.log_security_warning({
                "event": "APPROVE_INVOICE_FAILED",
                "invoice_id": invoice.id,
                "actor_id": actor_id,
                "details": str(exc)
            })
            raise RepositoryError(f"Failed to approve invoice {invoice.id}: {exc}") from exc
