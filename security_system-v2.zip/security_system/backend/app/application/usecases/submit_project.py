# application/usecases/submit_project.py
from datetime import datetime
import uuid
from typing import Dict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError

from domain.entities import Project, ProjectVersion
from domain.value_objects import ProjectStateEnum, UserRoleEnum
from infrastructure.db.repositories.project_repo import ProjectRepository
from infrastructure.db.repositories.project_version_repo import ProjectVersionRepository
from infrastructure.db.repositories.state_transition_repo import StateTransitionRepository
from infrastructure.db.repositories.notification_repo import NotificationRepository
from application.services.audit_service import AuditService
from core.exceptions import RepositoryError, NotFound, PermissionDenied

class SubmitProjectUseCase:
    """
    Use case for submitting a project (phase 4 hardened version).

    Responsibilities:
    - Validate actor role (RBAC)
    - Update project state and version with optimistic locking
    - Record state transition
    - Send notifications
    - Log all actions in AuditService
    """

    def __init__(
        self,
        project_repo: ProjectRepository,
        project_version_repo: ProjectVersionRepository,
        state_transition_repo: StateTransitionRepository,
        notification_repo: NotificationRepository,
        audit_service: AuditService,
        session: AsyncSession,
    ):
        self.project_repo = project_repo
        self.project_version_repo = project_version_repo
        self.state_transition_repo = state_transition_repo
        self.notification_repo = notification_repo
        self.audit_service = audit_service
        self.session = session

    async def execute(self, project_id: str, actor_id: str, actor_role: UserRoleEnum) -> Dict:
        # RBAC: Only CUSTOMER can submit project
        if actor_role != UserRoleEnum.CUSTOMER:
            await self.audit_service.log_security_warning({
                "event": "PROJECT_SUBMIT_UNAUTHORIZED",
                "project_id": project_id,
                "actor_id": actor_id,
                "actor_role": actor_role.name
            })
            raise PermissionDenied("Only CUSTOMER can submit projects")

        try:
            async with self.session.begin():
                # Fetch project with optimistic lock
                project: Project = await self.project_repo.get_by_id(project_id)
                current_version: ProjectVersion = await self.project_version_repo.get_by_project_and_version(
                    project_id, project.current_version
                )

                # Update project and version state
                project.current_state = ProjectStateEnum.SUBMITTED
                current_version.is_writable = False

                await self.project_repo.save(project)
                await self.project_version_repo.save(current_version)

                # Record state transition
                await self.state_transition_repo.save(
                    id=str(uuid.uuid4()),
                    project_id=project.id,
                    project_version=current_version.version,
                    from_state=ProjectStateEnum.DRAFT,
                    to_state=ProjectStateEnum.SUBMITTED,
                    actor_id=actor_id,
                    role=actor_role,
                    reason="Initial submission",
                    created_at=datetime.utcnow()
                )

                # Create notification
                await self.notification_repo.create(
                    user_role=UserRoleEnum.INTERNAL_MANAGER,
                    project_id=project.id,
                    type="PROJECT_SUBMITTED",
                    message=f"Project {project.id} submitted by {actor_id}"
                )

                # Audit success
                await self.audit_service.log_info({
                    "event": "PROJECT_SUBMITTED",
                    "project_id": project.id,
                    "project_version": current_version.version,
                    "actor_id": actor_id,
                    "actor_role": actor_role.name
                })

                return {
                    "project_id": project.id,
                    "project_version": current_version.version,
                    "from_state": ProjectStateEnum.DRAFT,
                    "to_state": ProjectStateEnum.SUBMITTED,
                    "status": "SUCCESS",
                    "timestamp": datetime.utcnow().isoformat()
                }

        except NotFound as nf:
            await self.audit_service.log_security_warning({
                "event": "PROJECT_SUBMIT_NOT_FOUND",
                "project_id": project_id,
                "actor_id": actor_id,
                "details": str(nf)
            })
            raise

        except RepositoryError as re:
            await self.audit_service.log_security_warning({
                "event": "PROJECT_SUBMIT_REPO_ERROR",
                "project_id": project_id,
                "actor_id": actor_id,
                "details": str(re)
            })
            raise

        except SQLAlchemyError as db_exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "PROJECT_SUBMIT_DB_ERROR",
                "project_id": project_id,
                "actor_id": actor_id,
                "details": str(db_exc)
            })
            raise RepositoryError(f"Database error during project submission {project_id}") from db_exc
