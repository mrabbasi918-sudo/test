from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError

from domain.entities.project import Project
from domain.entities.file import File
from domain.value_objects.role import UserRole
from infrastructure.db.repositories.project_repo import ProjectRepository
from infrastructure.db.repositories.file_repo import FileRepository
from application.services.audit_service import AuditService
from core.exceptions import RepositoryError, PermissionDenied

class UploadDocumentUseCase:
    """
    Phase 4 hardened use case for uploading project documents.
    Responsibilities:
    - RBAC enforcement
    - Audit logging
    - Atomic save
    - MinIO upload
    """

    ALLOWED_ROLES = [UserRole.CUSTOMER, UserRole.INTERNAL_MANAGER]

    def __init__(
        self,
        project_repo: ProjectRepository,
        file_repo: FileRepository,
        audit_service: AuditService,
        session: AsyncSession,
        storage
    ):
        self.project_repo = project_repo
        self.file_repo = file_repo
        self.audit_service = audit_service
        self.session = session
        self.storage = storage

    async def execute(self, project: Project, file: File, actor_id: str, actor_role: UserRole) -> dict:
        if actor_role not in self.ALLOWED_ROLES:
            await self.audit_service.log_security_warning({
                "event": "UPLOAD_DOCUMENT_UNAUTHORIZED",
                "project_id": project.id,
                "file_id": file.id,
                "actor_id": actor_id,
                "actor_role": actor_role.name
            })
            raise PermissionDenied("Role not allowed to upload document")

        try:
            async with self.session.begin():
                # Upload file to storage
                file_path = await self.storage.upload_file(file)
                file.path = file_path
                file.project_id = project.id
                file.uploaded_by = actor_id
                file.created_at = datetime.utcnow()

                # Persist file entity
                await self.file_repo.save(file, uploader_role=actor_role)

                # Audit log
                await self.audit_service.log_info({
                    "event": "UPLOAD_DOCUMENT",
                    "project_id": project.id,
                    "file_id": file.id,
                    "actor_id": actor_id
                })

            return {
                "project_id": project.id,
                "file_id": file.id,
                "status": "UPLOADED",
                "uploaded_at": file.created_at.isoformat(),
                "uploaded_by": actor_id
            }

        except (SQLAlchemyError, RepositoryError) as exc:
            await self.audit_service.log_security_warning({
                "event": "UPLOAD_DOCUMENT_FAILED",
                "project_id": project.id,
                "file_id": file.id,
                "actor_id": actor_id,
                "details": str(exc)
            })
            raise RepositoryError(f"Failed to upload document {file.id}") from exc
