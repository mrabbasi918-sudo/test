# application/usecases/manage_user.py
import uuid
from typing import Dict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError

from domain.entities.user import User
from domain.value_objects.role import UserRole
from domain.value_objects.status import UserStatus
from infrastructure.db.repositories.user_repo import UserRepository
from application.services.audit_service import AuditService
from core.exceptions import RepositoryError, PermissionDenied, NotFound, OptimisticLockError

class ManageUserUseCase:
    """
    Phase 4 hardened use case for managing users.
    Responsibilities:
    - RBAC checks
    - Optimistic locking
    - Audit logs on success/failure
    - Soft delete with restrictions
    """

    def __init__(self, user_repo: UserRepository, audit_service: AuditService, session: AsyncSession):
        self.user_repo = user_repo
        self.audit_service = audit_service
        self.session = session

    async def create_user(self, full_name: str, mobile: str, password: str, role: UserRole, actor_id: str, actor_role: UserRole) -> User:
        if actor_role != UserRole.SUPER_ADMIN:
            await self.audit_service.log_security_warning({
                "event": "CREATE_USER_UNAUTHORIZED",
                "actor_id": actor_id,
                "actor_role": actor_role.name,
                "target_role": role.name
            })
            raise PermissionDenied("Only SUPER_ADMIN can create users")

        try:
            async with self.session.begin():
                user = User.create(
                    id=str(uuid.uuid4()),
                    full_name=full_name,
                    mobile=mobile,
                    password=password,
                    role=role,
                    status=UserStatus.ACTIVE
                )
                await self.user_repo.save(user)
                await self.audit_service.log_info({
                    "event": "CREATE_USER",
                    "actor_id": actor_id,
                    "user_id": user.id
                })
                return user
        except (SQLAlchemyError, RepositoryError, OptimisticLockError) as exc:
            await self.audit_service.log_security_warning({
                "event": "CREATE_USER_FAILED",
                "actor_id": actor_id,
                "details": str(exc)
            })
            raise RepositoryError(f"Failed to create user: {exc}") from exc

    async def update_user(self, user: User, actor_id: str, actor_role: UserRole) -> User:
        if actor_role != UserRole.SUPER_ADMIN:
            await self.audit_service.log_security_warning({
                "event": "UPDATE_USER_UNAUTHORIZED",
                "actor_id": actor_id,
                "user_id": user.id
            })
            raise PermissionDenied("Only SUPER_ADMIN can update users")

        try:
            async with self.session.begin():
                await self.user_repo.save(user)
                await self.audit_service.log_info({
                    "event": "UPDATE_USER",
                    "actor_id": actor_id,
                    "user_id": user.id
                })
                return user
        except (SQLAlchemyError, RepositoryError, OptimisticLockError) as exc:
            await self.audit_service.log_security_warning({
                "event": "UPDATE_USER_FAILED",
                "actor_id": actor_id,
                "user_id": user.id,
                "details": str(exc)
            })
            raise RepositoryError(f"Failed to update user: {exc}") from exc

    async def soft_delete_user(self, user: User, actor_id: str, actor_role: UserRole) -> User:
        if actor_role != UserRole.SUPER_ADMIN:
            await self.audit_service.log_security_warning({
                "event": "SOFT_DELETE_USER_UNAUTHORIZED",
                "actor_id": actor_id,
                "user_id": user.id
            })
            raise PermissionDenied("Only SUPER_ADMIN can soft-delete users")

        try:
            async with self.session.begin():
                user.status = UserStatus.LOCKED
                user.is_deleted = True
                await self.user_repo.save(user)
                await self.audit_service.log_info({
                    "event": "SOFT_DELETE_USER",
                    "actor_id": actor_id,
                    "user_id": user.id
                })
                return user
        except (SQLAlchemyError, RepositoryError, OptimisticLockError) as exc:
            await self.audit_service.log_security_warning({
                "event": "SOFT_DELETE_USER_FAILED",
                "actor_id": actor_id,
                "user_id": user.id,
                "details": str(exc)
            })
            raise RepositoryError(f"Failed to soft-delete user: {exc}") from exc
