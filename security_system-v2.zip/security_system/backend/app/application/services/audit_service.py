from datetime import datetime
from typing import Optional, Dict, Any
import hashlib
from pydantic import BaseModel, constr

from app.infrastructure.db.repositories.audit_repo import AuditRepository
from app.infrastructure.db.repositories.state_transition_repo import StateTransitionRepository
from app.core.logger import logger
from app.core.security import generate_correlation_id

# -----------------------------
# Input Schemas
# -----------------------------
class SecurityEventSchema(BaseModel):
    event: constr(min_length=1)
    identifier: constr(min_length=1)
    request_id: constr(min_length=1)
    details: Optional[str] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None


class StateTransitionSchema(BaseModel):
    project_id: constr(min_length=1)
    project_version: int
    from_state: constr(min_length=1)
    to_state: constr(min_length=1)
    actor_id: constr(min_length=1)
    role: constr(min_length=1)
    reason: Optional[str] = None
    request_id: constr(min_length=1)
    ip: Optional[str] = None
    user_agent: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None

# -----------------------------
# Helpers
# -----------------------------
def mask_identifier(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


async def structured_log(data: Dict[str, Any], level: str = "INFO") -> None:
    import json
    json_data = json.dumps(data, default=str)
    if level.upper() == "INFO":
        logger.info(json_data)
    elif level.upper() == "WARNING":
        logger.warning(json_data)
    elif level.upper() == "ERROR":
        logger.error(json_data)
    else:
        logger.debug(json_data)


# -----------------------------
# Audit Service (Clean)
# -----------------------------
class AuditService:
    """
    Clean, async, append-only audit service
    """

    def __init__(
        self,
        audit_repo: AuditRepository,
        state_transition_repo: StateTransitionRepository,
    ):
        self.audit_repo = audit_repo
        self.state_transition_repo = state_transition_repo

    async def log_security_event(self, event_data: SecurityEventSchema, level: str = "INFO") -> None:
        correlation_id = generate_correlation_id(event_data.request_id)
        masked_id = mask_identifier(event_data.identifier)
        payload = {
            "event_type": "SECURITY",
            "event": event_data.event,
            "identifier": masked_id,
            "request_id": event_data.request_id,
            "details": event_data.details,
            "timestamp": datetime.utcnow(),
            "correlation_id": correlation_id,
            "ip": event_data.ip,
            "user_agent": event_data.user_agent,
            "extra": event_data.extra,
        }
        # Append-only, async save
        await self.audit_repo.create_event(**payload)
        await structured_log(payload, level=level)

    async def log_state_transition(self, transition_data: StateTransitionSchema) -> None:
        correlation_id = generate_correlation_id(transition_data.request_id)
        masked_actor = mask_identifier(transition_data.actor_id)
        payload = {
            "project_id": transition_data.project_id,
            "project_version": transition_data.project_version,
            "from_state": transition_data.from_state,
            "to_state": transition_data.to_state,
            "actor_id": masked_actor,
            "role": transition_data.role,
            "reason": transition_data.reason,
            "timestamp": datetime.utcnow(),
            "correlation_id": correlation_id,
            "ip": transition_data.ip,
            "user_agent": transition_data.user_agent,
            "extra": transition_data.extra,
        }
        await self.state_transition_repo.create_transition(**payload)
        await structured_log({**payload, "event": "STATE_TRANSITION"}, level="INFO")
