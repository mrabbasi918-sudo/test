from typing import List, Optional
from uuid import UUID, uuid4
from datetime import datetime
import asyncio

from pydantic import BaseModel

from app.infrastructure.db.repositories.project_repo import ProjectRepository
from app.infrastructure.db.repositories.state_transition_repo import StateTransitionRepository
from app.infrastructure.db.repositories.notifications_repo import NotificationRepository
from app.application.domain.entities import Project, User
from app.application.domain.enums import UserRoleEnum, ProjectStateEnum


class NotificationSchema(BaseModel):
    id: UUID
    user_id: UUID
    project_id: UUID
    type: str
    message: str
    read: bool
    created_at: datetime


class NotificationService:
    """
    Clean, async, append-only Notification Service
    """

    def __init__(
        self,
        project_repo: ProjectRepository,
        transition_repo: StateTransitionRepository,
        notification_repo: NotificationRepository,
        queue: Optional[asyncio.Queue] = None
    ):
        self.project_repo = project_repo
        self.transition_repo = transition_repo
        self.notification_repo = notification_repo
        self._queue = queue or asyncio.Queue()

    async def start_processor(self):
        while True:
            notification: NotificationSchema = await self._queue.get()
            try:
                await self.notification_repo.create(notification.dict())
            finally:
                self._queue.task_done()

    async def notify_transition(
        self,
        project_id: UUID,
        project_version: int,
        from_state: ProjectStateEnum,
        to_state: ProjectStateEnum,
        actor_id: UUID,
        actor_role: UserRoleEnum,
        reason: Optional[str] = None,
    ) -> List[NotificationSchema]:

        transition = await self.transition_repo.get_transition(
            project_id, project_version, from_state, to_state
        )

        if not transition and actor_role != UserRoleEnum.SUPER_ADMIN:
            raise PermissionError(f"Transition from {from_state} to {to_state} not allowed")

        recipients = await self._get_recipients_for_state(to_state, project_id)
        now = datetime.utcnow()

        notifications = [
            NotificationSchema(
                id=uuid4(),
                user_id=user.id,
                project_id=project_id,
                type="STATE_CHANGE",
                message=f"Project moved from {from_state} → {to_state}",
                read=False,
                created_at=now
            )
            for user in recipients
        ]

        for n in notifications:
            await self._queue.put(n)

        return notifications

    async def _get_recipients_for_state(self, state: ProjectStateEnum, project_id: UUID) -> List[User]:
        project: Project = await self.project_repo.get_by_id(project_id)
        if not project:
            raise ValueError(f"Project {project_id} not found")

        users_to_notify: List[User] = []

        # CUSTOMER notifications
        if state in [
            ProjectStateEnum.SUBMITTED,
            ProjectStateEnum.REVISION_REQUIRED_INITIAL,
            ProjectStateEnum.WAITING_FOR_UPDATE,
        ]:
            users_to_notify.append(project.owner)

        # Managers notifications
        if state in [
            ProjectStateEnum.INTERNAL_REVIEW,
            ProjectStateEnum.TECH_REVIEW,
            ProjectStateEnum.DOCUMENT_EVALUATING,
            ProjectStateEnum.WAITING_FOR_INSTALLATION,
            ProjectStateEnum.PRODUCT_EVALUATING,
            ProjectStateEnum.INVOICE_SENT,
            ProjectStateEnum.WAITING_FOR_PREPAYMENT,
            ProjectStateEnum.WAITING_FOR_DOCUMENTS,
        ]:
            users_to_notify.extend(await self.project_repo.get_managers_for_project(project_id))

        # SUPER_ADMIN always notified
        users_to_notify.extend(await self.project_repo.get_super_admins())

        # Remove duplicates
        unique_users = {u.id: u for u in users_to_notify}.values()
        return list(unique_users)

    async def mark_as_read(self, notification_id: UUID) -> Optional[NotificationSchema]:
        notification = await self.notification_repo.get_by_id(notification_id)
        if notification:
            notification.read = True
            await self.notification_repo.update(notification)
            return NotificationSchema(**notification.dict())
        return None

    async def list_notifications(self, user_id: UUID, unread_only: bool = True) -> List[NotificationSchema]:
        records = await self.notification_repo.list_by_user(user_id, unread_only=unread_only)
        return [NotificationSchema(**r.dict()) for r in records]
