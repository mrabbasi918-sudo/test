# app/application/services/auth_service.py
from datetime import datetime, timedelta
from uuid import uuid4
import hashlib
from typing import Optional

from app.core.constants import ACCESS_TOKEN_TTL_HOURS, MAX_FAILED_LOGIN, OTP_EXPIRATION_MINUTES
from app.core.exceptions import AuthError, ValidationError, ForbiddenError
from app.domain.value_objects.user_status import UserStatus

from app.application.services.audit_service import AuditService
from app.application.services.otp_service import OTPService
from app.application.services.captcha_service import CaptchaService

from app.infrastructure.jwt_adapter import JWTAdapter
from app.infrastructure.db.repositories.user_repo import UserRepository
from app.infrastructure.db.repositories.session_repo import SessionRepository


def _mask_identifier(value: str) -> str:
    """One-way mask for audit identifiers"""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


class AuthService:
    """
    Authentication Orchestration Service
    Production-grade, context-aligned, secure.

    Responsibilities:
    - Password & OTP login
    - Single-session enforcement
    - Failed login lockout
    - OTP request & verification
    - Audit & compliance hooks
    """

    def __init__(
        self,
        *,
        user_repo: UserRepository,
        session_repo: SessionRepository,
        jwt_adapter: JWTAdapter,
        audit_service: AuditService,
        otp_service: OTPService,
        captcha_service: CaptchaService,
    ):
        self.user_repo = user_repo
        self.session_repo = session_repo
        self.jwt_adapter = jwt_adapter
        self.audit = audit_service
        self.otp = otp_service
        self.captcha = captcha_service

    # ------------------------------------------------
    # Password-based Login
    # ------------------------------------------------
    def login(
        self,
        *,
        username: str,
        password: str,
        captcha: str,
        request_id: str,
        ip: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> str:
        masked = _mask_identifier(username)

        # 1️⃣ CAPTCHA verification
        if not self.captcha.verify(captcha):
            self.audit.log_failed_login_attempt(
                username=masked,
                request_id=request_id,
                reason="CAPTCHA_FAILED",
                ip=ip,
                user_agent=user_agent,
            )
            raise ValidationError("CAPTCHA_INVALID")

        user = self.user_repo.get_by_mobile(username)

        # 2️⃣ Prevent enumeration
        if not user:
            self._audit_invalid_login(masked, request_id, ip, user_agent)
            raise AuthError("INVALID_CREDENTIALS")

        # 3️⃣ User state validation
        if user.status == UserStatus.LOCKED:
            self.audit.log_security_warning(
                event="ACCOUNT_LOCKED_LOGIN_ATTEMPT",
                identifier=str(user.id),
                request_id=request_id,
                ip=ip,
                user_agent=user_agent,
            )
            raise ForbiddenError("ACCOUNT_LOCKED")

        # 4️⃣ Password verification
        if not self.user_repo.verify_password(user.id, password):
            failed_count = self.user_repo.increment_failed_login(user.id)

            if failed_count >= MAX_FAILED_LOGIN:
                self.user_repo.lock_user(user.id)
                self.audit.log_security_warning(
                    event="ACCOUNT_LOCKED",
                    identifier=str(user.id),
                    request_id=request_id,
                    ip=ip,
                    user_agent=user_agent,
                )

            self._audit_invalid_login(masked, request_id, ip, user_agent)
            raise AuthError("INVALID_CREDENTIALS")

        # 5️⃣ Successful authentication
        self.user_repo.reset_failed_login(user.id)

        # 6️⃣ Enforce single active session
        self._invalidate_all_sessions(user.id)

        # 7️⃣ JWT issuance
        jwt_id = str(uuid4())
        token = self.jwt_adapter.create_access_token(
            user_id=user.id,
            role=user.role,
            jwt_id=jwt_id,
        )

        self.session_repo.create(
            user_id=user.id,
            jwt_id=jwt_id,
            expires_at=datetime.utcnow() + timedelta(hours=ACCESS_TOKEN_TTL_HOURS),
        )

        # 8️⃣ Audit success
        self.audit.log_login(
            user_id=user.id,
            role=user.role,
            request_id=request_id,
            ip=ip,
            user_agent=user_agent,
        )

        return token

    # ------------------------------------------------
    # Logout
    # ------------------------------------------------
    def logout(
        self,
        *,
        user_id: str,
        jwt_id: str,
        request_id: str,
        ip: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        self.session_repo.safe_invalidate(jwt_id)
        self.audit.log_logout(
            user_id=user_id,
            request_id=request_id,
            ip=ip,
            user_agent=user_agent,
        )

    # ------------------------------------------------
    # OTP Request
    # ------------------------------------------------
    def request_otp(
        self,
        *,
        mobile: str,
        captcha: str,
        request_id: str,
        ip: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        masked = _mask_identifier(mobile)

        if not self.captcha.verify(captcha):
            self.audit.log_security_warning(
                event="OTP_CAPTCHA_FAILED",
                identifier=masked,
                request_id=request_id,
                ip=ip,
                user_agent=user_agent,
            )
            raise ValidationError("CAPTCHA_INVALID")

        user = self.user_repo.get_by_mobile(mobile)
        if not user:
            return  # silent by design

        # OTP generation, rate-limit, expiration, SMS, and audit handled inside OTPService
        self.otp.generate_and_send(
            mobile=mobile,
            request_id=request_id,
            ip=ip,
            user_agent=user_agent
        )

    # ------------------------------------------------
    # OTP Verify & Password Reset
    # ------------------------------------------------
    def verify_otp_and_reset_password(
        self,
        *,
        mobile: str,
        otp: str,
        new_password: str,
        request_id: str,
        ip: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        # OTP verification & consume
        self.otp.verify_and_consume(
            mobile=mobile,
            otp=otp,
            request_id=request_id,
            ip=ip,
            user_agent=user_agent
        )

        user = self.user_repo.get_by_mobile(mobile)
        if not user:
            raise ValidationError("USER_NOT_FOUND")

        # Update password
        self.user_repo.update_password(user.id, new_password)
        self._invalidate_all_sessions(user.id)

        # Audit password reset
        self.audit.log_password_reset(
            user_id=user.id,
            request_id=request_id,
            ip=ip,
            user_agent=user_agent,
        )

    # ------------------------------------------------
    # Internal helpers
    # ------------------------------------------------
    def _invalidate_all_sessions(self, user_id: str) -> None:
        self.session_repo.invalidate_all_for_user(user_id)

    def _audit_invalid_login(
        self,
        masked_identifier: str,
        request_id: str,
        ip: Optional[str],
        user_agent: Optional[str],
    ) -> None:
        self.audit.log_failed_login_attempt(
            username=masked_identifier,
            request_id=request_id,
            ip=ip,
            user_agent=user_agent,
        )
