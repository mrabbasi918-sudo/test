# app/application/services/otp_service.py
from datetime import datetime, timedelta
import hashlib
import secrets

from app.infrastructure.db.repositories.otp_repo import OTPRepository
from app.application.services.audit_service import AuditService
from app.infrastructure.sms_adapter import SMSAdapter
from app.core.constants import (
    OTP_EXPIRATION_MINUTES,
    OTP_RATE_LIMIT_COUNT,
    OTP_RATE_LIMIT_INTERVAL_SEC,
)
from app.core.exceptions import ValidationError, RepositoryError


def _hash_otp(otp: str) -> str:
    """Hash OTP for secure storage and verification."""
    return hashlib.sha256(otp.encode("utf-8")).hexdigest()


def _mask_mobile(mobile: str) -> str:
    """Mask mobile number for audit logs."""
    return hashlib.sha256(mobile.encode("utf-8")).hexdigest()


class OTPService:
    """
    OTP lifecycle management service.
    Production-grade, context-aligned, audit & rate-limit enforced.
    """

    def __init__(self, otp_repo: OTPRepository, audit: AuditService, sms_adapter: SMSAdapter):
        self.otp_repo = otp_repo
        self.audit = audit
        self.sms_adapter = sms_adapter

    # ------------------------------------------------------------------
    # Generate and send OTP
    # ------------------------------------------------------------------
    def generate_and_send_otp(self, *, mobile: str, request_id: str) -> None:
        """
        Generate OTP, enforce rate-limit, store hashed OTP, audit, and send via SMS.
        """
        now = datetime.utcnow()
        masked = _mask_mobile(mobile)

        # Rate Limit Check
        recent_otps = self.otp_repo.get_recent_by_mobile(
            mobile=mobile,
            since=now - timedelta(seconds=OTP_RATE_LIMIT_INTERVAL_SEC)
        )
        if len(recent_otps) >= OTP_RATE_LIMIT_COUNT:
            self.audit.log_security_event(
                event="OTP_RATE_LIMIT_EXCEEDED",
                identifier=masked,
                request_id=request_id,
                details=f"{len(recent_otps)} OTPs sent in last {OTP_RATE_LIMIT_INTERVAL_SEC}s"
            )
            raise ValidationError("OTP_RATE_LIMIT_EXCEEDED")

        # Generate OTP
        otp = f"{secrets.randbelow(1000000):06d}"
        otp_hash = _hash_otp(otp)
        expires_at = now + timedelta(minutes=OTP_EXPIRATION_MINUTES)

        # Store OTP in DB
        try:
            self.otp_repo.create(
                mobile=mobile,
                otp_hash=otp_hash,
                expires_at=expires_at,
                created_at=now
            )
        except RepositoryError as e:
            self.audit.log_security_event(
                event="OTP_STORE_FAILED",
                identifier=masked,
                request_id=request_id,
                details=str(e)
            )
            raise ValidationError("OTP_GENERATION_FAILED")

        # Audit OTP request
        self.audit.log_otp_requested(
            mobile=masked,
            request_id=request_id
        )

        # Send SMS asynchronously
        self.sms_adapter.send_otp(mobile=mobile, otp=otp)

    # ------------------------------------------------------------------
    # Verify and consume OTP
    # ------------------------------------------------------------------
    def verify_and_consume_otp(self, *, mobile: str, otp: str, request_id: str) -> None:
        """
        Verify OTP, consume it, audit all actions.
        """
        now = datetime.utcnow()
        masked = _mask_mobile(mobile)

        # Get latest valid OTP
        record = self.otp_repo.get_valid(mobile=mobile)
        if not record:
            self.audit.log_security_event(
                event="OTP_VERIFY_FAILED",
                identifier=masked,
                request_id=request_id,
                details="OTP not found or expired"
            )
            raise ValidationError("OTP_EXPIRED_OR_NOT_FOUND")

        # Check expiration
        if record.expires_at < now:
            self.otp_repo.invalidate(record.id)
            self.audit.log_security_event(
                event="OTP_EXPIRED",
                identifier=masked,
                request_id=request_id
            )
            raise ValidationError("OTP_EXPIRED")

        # Check OTP match
        if _hash_otp(otp) != record.otp_hash:
            self.otp_repo.invalidate(record.id)
            self.audit.log_security_event(
                event="OTP_INVALID",
                identifier=masked,
                request_id=request_id
            )
            raise ValidationError("OTP_INVALID")

        # Consume OTP
        try:
            self.otp_repo.consume(record.id)
        except RepositoryError as e:
            self.audit.log_security_event(
                event="OTP_CONSUME_FAILED",
                identifier=masked,
                request_id=request_id,
                details=str(e)
            )
            raise ValidationError("OTP_CONSUME_FAILED")

        # Audit success
        self.audit.log_security_event(
            event="OTP_CONSUMED",
            identifier=masked,
            request_id=request_id
        )

    # ------------------------------------------------------------------
    # Invalidate all OTPs for a mobile
    # ------------------------------------------------------------------
    def invalidate_all_otps(self, *, mobile: str, request_id: str) -> None:
        """
        Invalidate all OTPs for a mobile number and audit the action.
        """
        masked = _mask_mobile(mobile)
        self.otp_repo.invalidate_by_mobile(mobile)
        self.audit.log_security_event(
            event="OTP_INVALIDATED",
            identifier=masked,
            request_id=request_id
        )
