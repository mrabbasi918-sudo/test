import logging
from datetime import datetime
from app.infrastructure.db.repositories.project_repo import ProjectRepository
from app.infrastructure.db.repositories.payment_repo import PaymentRepository
from app.infrastructure.db.repositories.report_job_repo import ReportJobRepository
from app.infrastructure.db.repositories.state_transition_repo import StateTransitionRepository
from app.core.exceptions import ReportGenerationError
from app.utils.excel_generator import generate_excel_report
from app.utils.pdf_generator import generate_pdf_report
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

class ReportService:
    """
    Service برای تولید گزارش‌های مختلف سیستم
    """

    def __init__(
        self,
        project_repo: ProjectRepository,
        payment_repo: PaymentRepository,
        report_job_repo: ReportJobRepository,
        state_transition_repo: StateTransitionRepository,
        session: AsyncSession
    ):
        self.project_repo = project_repo
        self.payment_repo = payment_repo
        self.report_job_repo = report_job_repo
        self.state_transition_repo = state_transition_repo
        self.session = session

    async def generate_report(self, report_type: str, start_date: datetime, end_date: datetime, user_id: str):
        """
        تولید گزارش‌ها بر اساس نوع و تاریخ‌ها
        """

        try:
            # شروع تراکنش
            async with self.session.begin():
                
                # ذخیره درخواست گزارش در جدول report_jobs
                report_job = await self.report_job_repo.create(
                    report_type=report_type,
                    status="PROCESSING",
                    parameters={
                        "start_date": start_date.isoformat(),
                        "end_date": end_date.isoformat(),
                        "user_id": user_id,
                    },
                )

                # ثبت Transition برای گزارش (به عنوان مثال از وضعیت "DRAFT" به "REPORT_GENERATED")
                await self.state_transition_repo.create_transition(
                    project_id=None,  # برای گزارش خاص به پروژه خاص نیازی نیست
                    from_state="DRAFT",  # وضعیت فرضی که باید به آن منتقل شود
                    to_state="REPORT_GENERATED",  # وضعیت فرضی که به آن می‌رویم
                    actor_id=user_id,
                    role="SUPER_ADMIN",  # بسته به نقش
                    reason="Report generation initiated"
                )

                # بسته به نوع گزارش، داده‌ها جمع‌آوری می‌شوند و گزارش ساخته می‌شود.
                if report_type == "FINANCIAL":
                    # گزارش مالی: پرداخت‌ها
                    payments = await self.payment_repo.get_payments_by_date_range(start_date, end_date)

                    # تولید گزارش Excel و ذخیره‌سازی در MinIO
                    report_file_path = await generate_excel_report(payments)

                elif report_type == "PROJECT_STATUS":
                    # گزارش وضعیت پروژه‌ها
                    projects = await self.project_repo.get_projects_by_date_range(start_date, end_date)

                    # تولید گزارش PDF و ذخیره‌سازی در MinIO
                    report_file_path = await generate_pdf_report(projects)

                else:
                    raise ReportGenerationError(f"Unsupported report type: {report_type}")

                # ثبت فایل در MinIO و دریافت مسیر فایل
                # فرض بر این است که `minio_adapter.upload_file` برای آپلود فایل‌ها در MinIO پیاده‌سازی شده است.
                # اینجا مسیر فایل‌ها ثبت می‌شود.
                file_url = await self.minio_adapter.upload_file(report_file_path)

                # به‌روزرسانی وضعیت گزارش به DONE و ذخیره لینک دانلود
                await self.report_job_repo.update_status(
                    report_job_id=report_job.id,
                    status="DONE",
                    download_url=file_url,
                )

                logger.info(f"Report generated successfully for {report_type}")

                return report_job

        except Exception as e:
            logger.error(f"Error generating report: {str(e)}")
            raise ReportGenerationError("Failed to generate the report.")

    async def get_report_status(self, report_job_id: str):
        """
        دریافت وضعیت یک گزارش در حال پردازش
        """
        report_job = await self.report_job_repo.get_by_id(report_job_id)
        if not report_job:
            raise HTTPException(status_code=404, detail="Report job not found")
        return {
            "status": report_job.status,
            "download_url": report_job.download_url,
        }

