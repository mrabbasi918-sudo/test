from datetime import datetime
import logging
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.infrastructure.db.repositories.invoice_repo import InvoiceRepository
from app.infrastructure.db.repositories.payment_repo import PaymentRepository
from app.infrastructure.db.repositories.state_transition_repo import StateTransitionRepository
from app.domain.value_objects import InvoiceStatusEnum, PaymentStatusEnum
from app.core.exceptions import PaymentError
from app.infrastructure.db.repositories.idempotency_repo import IdempotencyRepository  # فرض می‌کنیم این repo برای Idempotency ایجاد شده باشد.

logger = logging.getLogger(__name__)

class PaymentService:
    """
    Service برای مدیریت پرداخت‌ها
    - ثبت، تأیید و بررسی وضعیت پرداخت‌ها
    """

    def __init__(
        self,
        payment_repo: PaymentRepository,
        invoice_repo: InvoiceRepository,
        state_transition_repo: StateTransitionRepository,
        idempotency_repo: IdempotencyRepository,  
        session: AsyncSession
    ):
        self.payment_repo = payment_repo
        self.invoice_repo = invoice_repo
        self.state_transition_repo = state_transition_repo
        self.idempotency_repo = idempotency_repo  
        self.session = session

    async def _get_invoice_or_404(self, invoice_id: str):
        """بارگذاری فاکتور یا ارجاع به خطای 404"""
        invoice = await self.invoice_repo.get_by_id(invoice_id)
        if not invoice:
            logger.warning(f"Invoice {invoice_id} not found")
            raise HTTPException(status_code=404, detail="Invoice not found")
        return invoice

    async def _get_payment_or_404(self, payment_id: str):
        """بارگذاری پرداخت یا ارجاع به خطای 404"""
        payment = await self.payment_repo.get_by_id(payment_id)
        if not payment:
            logger.warning(f"Payment {payment_id} not found")
            raise HTTPException(status_code=404, detail="Payment not found")
        return payment

    async def _create_transition(self, invoice, user_id: str, from_state: InvoiceStatusEnum, to_state: InvoiceStatusEnum, reason: str):
        """ثبت انتقال وضعیت فاکتور در جدول State Transitions"""
        transition = {
            "project_id": invoice.project_id,
            "project_version": invoice.project_version,
            "from_state": from_state,
            "to_state": to_state,
            "actor_id": user_id,
            "role": "CUSTOMER",  
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat()
        }
        await self.state_transition_repo.save(transition)

    async def create_payment(self, invoice_id: str, amount: float, user_id: str, idempotency_key: str):
        """ایجاد پرداخت جدید برای یک فاکتور"""
        if await self.idempotency_repo.exists(idempotency_key):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Payment request already processed.")

        async with self.session.begin():  # Start a transaction
            invoice = await self._get_invoice_or_404(invoice_id)

            if invoice.status != InvoiceStatusEnum.UNPAID:
                raise PaymentError(f"Invoice {invoice_id} is not in an unpaid state")

            # ثبت پرداخت
            payment = await self.payment_repo.create(
                invoice_id=invoice_id,
                amount=amount,
                user_id=user_id,
                created_at=datetime.utcnow()
            )

            # به‌روزرسانی وضعیت فاکتور
            if amount >= invoice.amount:
                invoice.status = InvoiceStatusEnum.PAID
                await self.invoice_repo.save(invoice)

            # ذخیره‌سازی پرداخت در پایگاه داده
            await self.payment_repo.save(payment)

            # ثبت انتقال وضعیت فاکتور در جدول State Transitions
            await self._create_transition(invoice, user_id, InvoiceStatusEnum.UNPAID, InvoiceStatusEnum.PAID, "Payment created")

            # ذخیره‌سازی Idempotency Key
            await self.idempotency_repo.save(idempotency_key)

            logger.info(f"Payment created for invoice {invoice_id} with amount {amount}")
            return payment

    async def verify_payment(self, payment_id: str, user_id: str, idempotency_key: str):
        """تأیید پرداخت"""
        if await self.idempotency_repo.exists(idempotency_key):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Payment verification already processed.")

        async with self.session.begin():  # Start a transaction
            payment = await self._get_payment_or_404(payment_id)

            if payment.status != PaymentStatusEnum.PENDING:
                raise PaymentError(f"Payment {payment_id} is already in status {payment.status}, cannot verify")

            # تغییر وضعیت پرداخت
            payment.status = PaymentStatusEnum.VERIFIED
            await self.payment_repo.save(payment)

            invoice = await self._get_invoice_or_404(payment.invoice_id)

            invoice.status = InvoiceStatusEnum.PAID
            await self.invoice_repo.save(invoice)

            # ثبت انتقال وضعیت فاکتور در جدول State Transitions
            await self._create_transition(invoice, user_id, InvoiceStatusEnum.UNPAID, InvoiceStatusEnum.PAID, "Payment verified")

            # ذخیره‌سازی Idempotency Key
            await self.idempotency_repo.save(idempotency_key)

            logger.info(f"Payment {payment_id} verified by user {user_id}")
            return payment

    async def get_payment_status(self, payment_id: str):
        """دریافت وضعیت پرداخت"""
        payment = await self._get_payment_or_404(payment_id)
        return {
            "payment_id": payment.id,
            "status": payment.status,
            "amount": payment.amount,
            "created_at": payment.created_at.isoformat(),
        }

    async def get_payments_by_invoice(self, invoice_id: str):
        """دریافت تمامی پرداخت‌ها برای یک فاکتور خاص"""
        invoice = await self._get_invoice_or_404(invoice_id)
        payments = await self.payment_repo.get_by_invoice_id(invoice.id)
        return payments
