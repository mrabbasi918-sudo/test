from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

import jwt

from core.logger import logger
from core.exceptions import InfrastructureError
from app.config.settings import settings


class JWTAdapter:
    """
    JWT Infrastructure Adapter (Production-grade)

    Responsibilities (STRICT):
    - Generate JWT tokens
    - Decode & verify JWT tokens
    - Enforce cryptographic validity
    - NO session logic
    - NO role validation
    - NO business rules
    """

    def __init__(self) -> None:
        self._secret = settings.JWT_SECRET_KEY
        self._algorithm = settings.JWT_ALGORITHM
        self._issuer = settings.JWT_ISSUER
        self._audience = settings.JWT_AUDIENCE
        self._access_token_ttl = settings.JWT_ACCESS_TOKEN_TTL_MINUTES

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_access_token(
        self,
        *,
        user_id: str,
        role: str,
        correlation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Generates signed JWT access token.
        """
        now = datetime.now(tz=timezone.utc)
        jti = str(uuid.uuid4())

        payload = {
            "sub": user_id,
            "role": role,
            "jti": jti,
            "iat": int(now.timestamp()),
            "exp": int((now + timedelta(minutes=self._access_token_ttl)).timestamp()),
            "iss": self._issuer,
            "aud": self._audience,
        }

        try:
            token = jwt.encode(
                payload=payload,
                key=self._secret,
                algorithm=self._algorithm,
            )

            logger.info(
                "JWT access token generated",
                extra={
                    "user_id": user_id,
                    "role": role,
                    "jti": jti,
                    "correlation_id": correlation_id,
                },
            )

            return {
                "access_token": token,
                "jti": jti,
                "expires_at": payload["exp"],
            }

        except jwt.PyJWTError as exc:
            logger.exception(
                "JWT generation failed",
                extra={"correlation_id": correlation_id},
            )
            raise InfrastructureError("JWT generation failed") from exc

    def decode_and_verify(
        self,
        *,
        token: str,
        correlation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Decodes and validates JWT token.
        """
        try:
            payload = jwt.decode(
                jwt=token,
                key=self._secret,
                algorithms=[self._algorithm],
                audience=self._audience,
                issuer=self._issuer,
            )

            logger.debug(
                "JWT verified successfully",
                extra={
                    "sub": payload.get("sub"),
                    "jti": payload.get("jti"),
                    "correlation_id": correlation_id,
                },
            )

            return payload

        except jwt.ExpiredSignatureError:
            logger.warning(
                "JWT expired",
                extra={"correlation_id": correlation_id},
            )
            raise InfrastructureError("JWT expired")

        except jwt.InvalidTokenError as exc:
            logger.warning(
                "Invalid JWT token",
                extra={"correlation_id": correlation_id},
            )
            raise InfrastructureError("Invalid JWT token") from exc
