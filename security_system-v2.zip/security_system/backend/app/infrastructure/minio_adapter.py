from __future__ import annotations

import io
import uuid
import hashlib
from typing import BinaryIO, Optional, Iterator

from minio import Minio
from minio.error import S3Error, NoSuchKey

from core.logger import logger
from core.exceptions import InfrastructureError
from app.config.settings import settings


ALLOWED_EXTENSIONS = {"zip", "rar"}
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB
CHUNK_SIZE = 1024 * 1024  # 1MB


class MinIOAdapter:
    """
    MinIO Infrastructure Adapter (Production-grade)

    Responsibilities (STRICT):
    - Store immutable binary objects
    - Stream upload (no full in-memory buffering)
    - Enforce storage-level constraints (size, extension)
    - Generate deterministic object paths (checksum-based)
    - Handle MinIO-specific failures
    - NO domain logic
    - NO state machine
    - NO authorization logic
    """

    def __init__(self) -> None:
        self._client = Minio(
            endpoint=settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=settings.MINIO_SECURE,
        )

        self._bucket = settings.MINIO_BUCKET
        self._ensure_bucket_exists()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upload_project_file(
        self,
        *,
        project_id: str,
        project_version: int,
        filename: str,
        file: BinaryIO,
        content_type: Optional[str] = None,
    ) -> dict:
        """
        Uploads an immutable project file using streaming.

        Returns metadata required for DB persistence.
        """
        extension = self._extract_extension(filename)
        self._validate_extension(extension)

        checksum, size, stream = self._prepare_stream(file)
        self._validate_size(size)

        object_name = self._build_object_path(
            project_id=project_id,
            project_version=project_version,
            checksum=checksum,
            extension=extension,
        )

        try:
            self._client.put_object(
                bucket_name=self._bucket,
                object_name=object_name,
                data=stream,
                length=size,
                content_type=content_type or "application/octet-stream",
            )

            logger.info(
                "File uploaded to MinIO",
                extra={
                    "bucket": self._bucket,
                    "object_name": object_name,
                    "size": size,
                    "checksum": checksum,
                },
            )

            return {
                "object_name": object_name,
                "size": size,
                "extension": extension,
                "checksum": checksum,
            }

        except S3Error as exc:
            logger.exception(
                "MinIO upload failed",
                extra={
                    "bucket": self._bucket,
                    "object_name": object_name,
                    "error": str(exc),
                },
            )
            raise InfrastructureError("File storage failed") from exc

    def get_presigned_download_url(
        self,
        *,
        object_name: str,
        expires_in_seconds: int = 3600,
    ) -> str:
        try:
            return self._client.presigned_get_object(
                bucket_name=self._bucket,
                object_name=object_name,
                expires=expires_in_seconds,
            )
        except S3Error as exc:
            logger.exception(
                "Failed to generate presigned URL",
                extra={"object_name": object_name},
            )
            raise InfrastructureError("Failed to generate download URL") from exc

    def object_exists(self, object_name: str) -> bool:
        try:
            self._client.stat_object(self._bucket, object_name)
            return True
        except NoSuchKey:
            return False
        except S3Error as exc:
            logger.exception(
                "MinIO stat_object failed",
                extra={"object_name": object_name},
            )
            raise InfrastructureError("Storage check failed") from exc

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_bucket_exists(self) -> None:
        if not self._client.bucket_exists(self._bucket):
            self._client.make_bucket(self._bucket)
            logger.info("MinIO bucket created", extra={"bucket": self._bucket})

    @staticmethod
    def _prepare_stream(file: BinaryIO) -> tuple[str, int, io.BytesIO]:
        """
        Reads file in chunks, calculates checksum and size,
        and returns a rewindable stream.
        """
        hasher = hashlib.sha256()
        buffer = io.BytesIO()
        size = 0

        while True:
            chunk = file.read(CHUNK_SIZE)
            if not chunk:
                break
            size += len(chunk)
            hasher.update(chunk)
            buffer.write(chunk)

        buffer.seek(0)
        return hasher.hexdigest(), size, buffer

    @staticmethod
    def _build_object_path(
        *,
        project_id: str,
        project_version: int,
        checksum: str,
        extension: str,
    ) -> str:
        """
        Deterministic path based on content checksum.
        Prevents duplicate storage.
        """
        return f"project-{project_id}/v{project_version}/{checksum}.{extension}"

    @staticmethod
    def _extract_extension(filename: str) -> str:
        if "." not in filename:
            return ""
        return filename.rsplit(".", 1)[-1].lower()

    @staticmethod
    def _validate_extension(extension: str) -> None:
        if extension not in ALLOWED_EXTENSIONS:
            raise InfrastructureError("Invalid file extension")

    @staticmethod
    def _validate_size(size: int) -> None:
        if size > MAX_FILE_SIZE:
            raise InfrastructureError("File size exceeds allowed limit")
