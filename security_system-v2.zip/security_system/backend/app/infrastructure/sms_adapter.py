from __future__ import annotations

import uuid
from typing import Optional

import requests

from core.logger import logger
from core.exceptions import InfrastructureError
from app.config.settings import settings


class SMSAdapter:
    """
    SMS Infrastructure Adapter (Production-grade)

    Responsibilities (STRICT):
    - Send SMS via external provider
    - Provider-level error handling
    - Structured logging (correlation-aware)
    - NO business rules
    - NO OTP validation
    - NO rate limiting
    """

    def __init__(self) -> None:
        self._base_url = settings.SMS_PROVIDER_BASE_URL
        self._api_key = settings.SMS_PROVIDER_API_KEY
        self._sender = settings.SMS_PROVIDER_SENDER

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def send_sms(
        self,
        *,
        mobile: str,
        message: str,
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Sends SMS message via configured provider.
        """
        correlation_id = correlation_id or str(uuid.uuid4())

        payload = {
            "to": mobile,
            "message": message,
            "sender": self._sender,
        }

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "X-Correlation-Id": correlation_id,
        }

        try:
            response = requests.post(
                url=self._base_url,
                json=payload,
                headers=headers,
                timeout=5,
            )

            self._validate_response(response)

            logger.info(
                "SMS sent successfully",
                extra={
                    "correlation_id": correlation_id,
                    "mobile": mobile,
                },
            )

        except requests.RequestException as exc:
            logger.exception(
                "SMS provider request failed",
                extra={
                    "correlation_id": correlation_id,
                    "mobile": mobile,
                },
            )
            raise InfrastructureError("SMS provider unreachable") from exc

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_response(response: requests.Response) -> None:
        if response.status_code >= 500:
            raise InfrastructureError("SMS provider internal error")

        if response.status_code >= 400:
            raise InfrastructureError(
                f"SMS rejected by provider (status={response.status_code})"
            )

        # Optional minimal schema check
        if response.headers.get("Content-Type", "").startswith("application/json"):
            data = response.json()
            if "status" in data and data["status"] not in {"success", "queued"}:
                raise InfrastructureError("SMS provider returned failure status")
