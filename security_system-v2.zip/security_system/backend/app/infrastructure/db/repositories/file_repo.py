from typing import List, Optional
from uuid import UUID
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import update

from core.exceptions import RepositoryError, NotFound, PermissionDenied, OptimisticLockError
from core.logger import logger
from domain.entities.file import File
from domain.entities.project_version import ProjectVersion
from domain.value_objects.role import UserRole
from application.services.audit_service import AuditService  # سرویس Audit فاز ۴


class FileRepository:
    """
    Async repository for File entity with Phase 4 enhancements.
    - Optimistic locking
    - RBAC
    - Audit
    - Transaction safety
    """

    MAX_FILE_SIZE = 104_857_600  # 100MB
    ALLOWED_EXTENSIONS = {"zip", "rar"}

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    # -------------------------
    # Fetch Operations
    # -------------------------
    async def get_by_id(self, file_id: UUID) -> File:
        try:
            result = await self.session.execute(select(File).where(File.id == file_id))
            file = result.scalar_one_or_none()
            if not file:
                raise NotFound(f"File {file_id} not found")
            return file
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "FILE_FETCH_FAILED",
                "file_id": str(file_id)
            })
            logger.exception("Failed to fetch file by id", extra={"file_id": str(file_id)})
            raise RepositoryError(f"Failed to fetch file {file_id}") from exc

    async def list_by_project(
        self,
        project_id: UUID,
        project_version: Optional[int] = None,
        include_deleted: bool = False,
        limit: int = 100,
        offset: int = 0
    ) -> List[File]:
        try:
            query = select(File).where(File.project_id == project_id)
            if project_version:
                query = query.where(File.project_version == project_version)
            if not include_deleted:
                query = query.where(File.deleted_at.is_(None))
            query = query.order_by(File.created_at.desc()).limit(limit).offset(offset)
            result = await self.session.execute(query)
            return result.scalars().all()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "FILE_LIST_FAILED",
                "project_id": str(project_id),
                "project_version": project_version
            })
            logger.exception(
                "Failed to list files for project",
                extra={"project_id": str(project_id), "project_version": project_version}
            )
            raise RepositoryError(f"Failed to list files for project {project_id}") from exc

    # -------------------------
    # Save / Upload
    # -------------------------
    async def save(self, file: File, actor_id: UUID, uploader_role: UserRole) -> None:
        """Save a new file with RBAC, version check, audit, and optimistic locking"""
        if file.extension not in self.ALLOWED_EXTENSIONS:
            raise RepositoryError(f"Invalid file extension: {file.extension}")
        if file.size > self.MAX_FILE_SIZE:
            raise RepositoryError(f"File size exceeds {self.MAX_FILE_SIZE} bytes")
        if uploader_role not in [UserRole.SUPER_ADMIN, UserRole.INTERNAL_MANAGER]:
            raise PermissionDenied("Role not allowed to upload files")

        try:
            # Fetch project version
            result = await self.session.execute(
                select(ProjectVersion).where(
                    ProjectVersion.project_id == file.project_id,
                    ProjectVersion.version == file.project_version
                )
            )
            version = result.scalar_one_or_none()
            if not version:
                raise NotFound(f"ProjectVersion {file.project_version} not found for project {file.project_id}")
            if not version.is_writable:
                raise RepositoryError(f"Cannot upload to read-only version {file.project_version}")

            self.session.add(file)
            await self.session.commit()

            await self.audit_service.log_security_event({
                "event": "FILE_SAVED",
                "file_id": str(file.id),
                "project_id": str(file.project_id),
                "actor_id": str(actor_id),
                "role": uploader_role.name
            })

        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "FILE_SAVE_FAILED",
                "file_id": str(file.id),
                "project_id": str(file.project_id),
                "actor_id": str(actor_id),
                "role": uploader_role.name
            })
            logger.exception(
                "Failed to save file",
                extra={"file_id": str(file.id), "project_id": str(file.project_id)}
            )
            raise RepositoryError(f"Failed to save file {file.id}") from exc

    # -------------------------
    # Soft Delete
    # -------------------------
    async def soft_delete(self, file: File, actor_id: UUID, actor_role: UserRole) -> None:
        """Soft delete a file with RBAC, optimistic lock, audit"""
        if actor_role != UserRole.SUPER_ADMIN:
            await self.audit_service.log_security_warning({
                "event": "FILE_DELETE_UNAUTHORIZED",
                "file_id": str(file.id),
                "actor_role": actor_role.name
            })
            raise PermissionDenied("Only SUPER_ADMIN can delete files")

        try:
            # Optimistic Lock check
            stmt = update(File).where(File.id == file.id, File.version == file.version).values(
                deleted_at=datetime.utcnow(),
                version=file.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for file {file.id}")

            await self.session.commit()
            await self.audit_service.log_security_event({
                "event": "FILE_DELETED",
                "file_id": str(file.id),
                "project_id": str(file.project_id),
                "actor_id": str(actor_id),
                "role": actor_role.name
            })
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "FILE_DELETE_FAILED",
                "file_id": str(file.id),
                "actor_id": str(actor_id)
            })
            logger.exception(
                "Failed to soft delete file",
                extra={"file_id": str(file.id), "project_id": str(file.project_id)}
            )
            raise RepositoryError(f"Failed to soft delete file {file.id}") from exc
