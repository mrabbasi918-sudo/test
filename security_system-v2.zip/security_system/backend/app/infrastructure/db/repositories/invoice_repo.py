from typing import List, Optional
from uuid import UUID
from datetime import datetime
from functools import lru_cache

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import update

from core.exceptions import RepositoryError, NotFound, InvalidOperation, PermissionDenied, OptimisticLockError
from core.logger import logger
from domain.entities.invoice import Invoice
from domain.value_objects.invoice_status import InvoiceStatus
from domain.entities.project import Project
from domain.value_objects.role import UserRole
from domain.value_objects.state import ProjectState
from infrastructure.db.repositories.project_repo import ProjectRepository
from application.services.audit_service import AuditService


class InvoiceRepository:
    """Async repository for Invoice entity with full Phase 4 compliance."""

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    @lru_cache(maxsize=100)
    async def get_by_id_cached(self, invoice_id: UUID) -> Invoice:
        return await self.get_by_id(invoice_id)

    async def get_by_id(self, invoice_id: UUID) -> Invoice:
        try:
            result = await self.session.execute(select(Invoice).where(Invoice.id == invoice_id))
            invoice = result.scalar_one_or_none()
            if not invoice:
                raise NotFound(f"Invoice {invoice_id} not found")
            return invoice
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_FETCH_FAILED",
                "invoice_id": str(invoice_id),
                "details": str(exc)
            })
            logger.exception("Failed to fetch invoice by id", extra={"invoice_id": str(invoice_id)})
            raise RepositoryError(f"Failed to fetch invoice {invoice_id}") from exc

    async def list_all(self, status: Optional[InvoiceStatus] = None, limit: int = 100, offset: int = 0) -> List[Invoice]:
        try:
            query = select(Invoice)
            if status:
                query = query.where(Invoice.status == status)
            query = query.order_by(Invoice.created_at.desc()).offset(offset).limit(limit)
            result = await self.session.execute(query)
            return result.scalars().all()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_LIST_FAILED",
                "details": str(exc)
            })
            logger.exception("Failed to list invoices")
            raise RepositoryError("Failed to list invoices") from exc

    async def save(self, invoice: Invoice) -> None:
        """Save with optimistic locking on version"""
        try:
            stmt = update(Invoice).where(
                Invoice.id == invoice.id, Invoice.version == invoice.version
            ).values(
                **invoice.dict(exclude={"version"}),
                version=invoice.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for invoice {invoice.id}")
            await self.session.commit()
            await self.audit_service.log_security_event({
                "event": "INVOICE_SAVED",
                "invoice_id": str(invoice.id),
                "actor_id": str(invoice.actor_id) if hasattr(invoice, "actor_id") else None
            })
        except IntegrityError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "INVOICE_SAVE_CONSTRAINT_FAILED",
                "invoice_id": str(invoice.id)
            })
            logger.exception("Unique constraint violation on invoice", extra={"invoice_id": str(invoice.id)})
            raise RepositoryError(f"Constraint violation for invoice {invoice.id}") from exc
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "INVOICE_SAVE_FAILED",
                "invoice_id": str(invoice.id),
                "details": str(exc)
            })
            logger.exception("Failed to save invoice", extra={"invoice_id": str(invoice.id)})
            raise RepositoryError(f"Failed to save invoice {invoice.id}") from exc

    async def cancel_invoice(self, invoice: Invoice, actor_id: UUID, actor_role: UserRole) -> Invoice:
        """Soft delete / cancel invoice with RBAC and optimistic locking"""
        if actor_role not in [UserRole.SUPER_ADMIN, UserRole.INTERNAL_MANAGER]:
            raise PermissionDenied("Role not allowed to cancel invoice")

        try:
            stmt = update(Invoice).where(
                Invoice.id == invoice.id,
                Invoice.version == invoice.version
            ).values(
                status=InvoiceStatus.CANCELED,
                version=invoice.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for invoice {invoice.id}")
            await self.session.commit()
            await self.audit_service.log_security_event({
                "event": "INVOICE_CANCELED",
                "invoice_id": str(invoice.id),
                "actor_id": str(actor_id)
            })
            return await self.get_by_id(invoice.id)
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "INVOICE_CANCEL_FAILED",
                "invoice_id": str(invoice.id),
                "actor_id": str(actor_id),
                "actor_role": actor_role.name,
                "details": str(exc)
            })
            logger.exception("Failed to cancel invoice", extra={"invoice_id": str(invoice.id)})
            raise RepositoryError(f"Failed to cancel invoice {invoice.id}") from exc

    async def mark_invoice_paid(self, invoice: Invoice, actor_id: UUID, actor_role: UserRole, payment_type: str = "prepayment") -> Invoice:
        """Mark as PAID and trigger Project state transitions with RBAC and optimistic locking"""
        if actor_role not in [UserRole.SUPER_ADMIN, UserRole.INTERNAL_MANAGER, UserRole.TECH_MANAGER]:
            raise PermissionDenied("Role not allowed to mark invoice as PAID")

        try:
            # Fetch Project
            result = await self.session.execute(select(Project).where(Project.id == invoice.project_id))
            project = result.scalar_one_or_none()
            if not project:
                raise NotFound(f"Project {invoice.project_id} not found")

            # Optimistic Lock on Invoice
            stmt = update(Invoice).where(
                Invoice.id == invoice.id,
                Invoice.version == invoice.version
            ).values(
                status=InvoiceStatus.PAID,
                version=invoice.version + 1
            )
            result_update = await self.session.execute(stmt)
            if result_update.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for invoice {invoice.id}")

            # Project State Transition
            project_repo = ProjectRepository(self.session, self.audit_service)
            if payment_type == "prepayment":
                if project.current_state == ProjectState.INVOICE_SENT:
                    await project_repo.set_state(
                        project, ProjectState.WAITING_FOR_PREPAYMENT, actor_id, actor_role, reason="Prepayment marked as PAID"
                    )
                if project.current_state == ProjectState.WAITING_FOR_PREPAYMENT:
                    await project_repo.set_state(
                        project, ProjectState.WAITING_FOR_DOCUMENTS, actor_id, actor_role, reason="Prepayment verified"
                    )
            elif payment_type == "final":
                if project.current_state != ProjectState.WAITING_FOR_INSTALLATION:
                    raise InvalidOperation(f"Cannot apply final payment: Project {project.id} in state {project.current_state}")
                await project_repo.set_state(
                    project, ProjectState.PRODUCT_EVALUATING, actor_id, actor_role, reason="Final payment marked as PAID"
                )
            else:
                raise InvalidOperation(f"Unknown payment_type: {payment_type}")

            await self.session.commit()
            await self.audit_service.log_security_event({
                "event": "INVOICE_MARK_PAID",
                "invoice_id": str(invoice.id),
                "actor_id": str(actor_id),
                "payment_type": payment_type
            })
            return await self.get_by_id(invoice.id)
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning({
                "event": "INVOICE_MARK_PAID_FAILED",
                "invoice_id": str(invoice.id),
                "actor_id": str(actor_id),
                "payment_type": payment_type,
                "details": str(exc)
            })
            logger.exception("Failed to mark invoice as PAID", extra={"invoice_id": str(invoice.id), "payment_type": payment_type})
            raise RepositoryError(f"Failed to mark invoice {invoice.id} as PAID") from exc

    async def get_invoice_for_project(self, project_id: UUID) -> Optional[Invoice]:
        try:
            result = await self.session.execute(
                select(Invoice).where(Invoice.project_id == project_id).order_by(Invoice.created_at.desc())
            )
            return result.scalars().first()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_FETCH_PROJECT_FAILED",
                "project_id": str(project_id),
                "details": str(exc)
            })
            logger.exception("Failed to fetch invoice for project", extra={"project_id": str(project_id)})
            raise RepositoryError(f"Failed to fetch invoice for project {project_id}") from exc
