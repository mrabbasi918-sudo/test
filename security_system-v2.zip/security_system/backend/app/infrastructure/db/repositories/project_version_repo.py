from typing import List
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import update

from core.exceptions import RepositoryError, NotFound, OptimisticLockError
from core.logger import logger
from domain.entities.project_version import ProjectVersion
from application.services.audit_service import AuditService  # فرض بر وجود AuditService


class ProjectVersionRepository:
    """Async repository for ProjectVersion entity with Optimistic Locking and Audit."""

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    async def get_by_id(self, version_id: UUID) -> ProjectVersion:
        try:
            result = await self.session.execute(select(ProjectVersion).where(ProjectVersion.id == version_id))
            version = result.scalar_one_or_none()
            if not version:
                raise NotFound(f"ProjectVersion {version_id} not found")
            return version
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_VERSION_FETCH_FAILED", "identifier": str(version_id), "details": str(exc)}
            )
            logger.exception("Failed to fetch project version by id", extra={"version_id": str(version_id)})
            raise RepositoryError(f"Failed to fetch project version {version_id}") from exc

    async def list_by_project(self, project_id: UUID, limit: int = 100, offset: int = 0) -> List[ProjectVersion]:
        try:
            query = select(ProjectVersion).where(ProjectVersion.project_id == project_id).order_by(ProjectVersion.version.asc()).offset(offset).limit(limit)
            result = await self.session.execute(query)
            return result.scalars().all()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_VERSION_LIST_FAILED", "project_id": str(project_id), "details": str(exc)}
            )
            logger.exception("Failed to list project versions", extra={"project_id": str(project_id)})
            raise RepositoryError(f"Failed to list versions for project {project_id}") from exc

    async def get_latest(self, project_id: UUID) -> ProjectVersion:
        try:
            query = select(ProjectVersion).where(ProjectVersion.project_id == project_id, ProjectVersion.is_writable.is_(True))
            result = await self.session.execute(query)
            version = result.scalar_one_or_none()
            if not version:
                raise NotFound(f"No writable version found for project {project_id}")
            return version
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_VERSION_LATEST_FETCH_FAILED", "project_id": str(project_id), "details": str(exc)}
            )
            logger.exception("Failed to fetch latest project version", extra={"project_id": str(project_id)})
            raise RepositoryError(f"Failed to fetch latest version for project {project_id}") from exc

    async def save(self, version: ProjectVersion) -> None:
        """Save with optimistic locking on version"""
        try:
            self.session.add(version)
            await self.session.commit()
        except IntegrityError as exc:
            await self.session.rollback()
            logger.exception("Unique constraint violated for project version", extra={"project_id": str(version.project_id), "version": version.version})
            raise RepositoryError(f"Unique constraint violated for project version {version.id}") from exc
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_VERSION_SAVE_FAILED", "project_id": str(version.project_id), "details": str(exc)}
            )
            logger.exception("Failed to save project version", extra={"project_id": str(version.project_id), "version": version.version})
            raise RepositoryError(f"Failed to save project version {version.id}") from exc

    async def delete(self, version: ProjectVersion) -> None:
        raise RepositoryError("ProjectVersion entities are immutable and cannot be deleted")

    async def increment_version(self, project_id: UUID) -> ProjectVersion:
        try:
            latest = await self.get_latest(project_id)
            latest.is_writable = False
            self.session.add(latest)

            new_version = ProjectVersion(
                project_id=project_id,
                version=latest.version + 1,
                state=latest.state,
                is_writable=True
            )
            self.session.add(new_version)
            await self.session.commit()
            return new_version
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_VERSION_INCREMENT_FAILED", "project_id": str(project_id), "details": str(exc)}
            )
            logger.exception("Failed to increment project version", extra={"project_id": str(project_id)})
            raise RepositoryError(f"Failed to increment project version for project {project_id}") from exc
