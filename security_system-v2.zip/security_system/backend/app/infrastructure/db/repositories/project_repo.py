from typing import List, Optional
from uuid import UUID
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import update

from core.exceptions import RepositoryError, NotFound, OptimisticLockError, PermissionDenied
from core.logger import logger
from domain.entities.project import Project
from domain.entities.project_version import ProjectVersion
from domain.entities.state_transition import StateTransition
from domain.value_objects.state import ProjectState
from domain.value_objects.role import UserRole
from infrastructure.db.repositories.project_version_repo import ProjectVersionRepository
from application.services.audit_service import AuditService  # فرض بر وجود AuditService


class ProjectRepository:
    """Async repository for Project entity with Optimistic Locking, RBAC, and Audit."""

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    async def get_by_id(self, project_id: UUID) -> Project:
        try:
            result = await self.session.execute(select(Project).where(Project.id == project_id))
            project = result.scalar_one_or_none()
            if not project:
                raise NotFound(f"Project {project_id} not found")
            return project
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_FETCH_FAILED", "identifier": str(project_id), "details": str(exc)}
            )
            logger.exception("Failed to fetch project by id", extra={"project_id": str(project_id)})
            raise RepositoryError(f"Failed to fetch project {project_id}") from exc

    async def list_all(self, state: Optional[ProjectState] = None, limit: int = 100, offset: int = 0) -> List[Project]:
        try:
            query = select(Project)
            if state:
                query = query.where(Project.current_state == state)
            query = query.offset(offset).limit(limit)
            result = await self.session.execute(query)
            return result.scalars().all()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_LIST_FAILED", "state": state.name if state else "ALL", "details": str(exc)}
            )
            logger.exception("Failed to list projects", extra={"state": state.name if state else "ALL"})
            raise RepositoryError("Failed to list projects") from exc

    async def save(self, project: Project) -> None:
        """Save with optimistic locking"""
        try:
            stmt = update(Project).where(Project.id == project.id, Project.version == project.version).values(
                **project.dict(exclude={"version"}), version=project.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for project {project.id}")
            await self.session.commit()
        except IntegrityError as exc:
            await self.session.rollback()
            logger.exception("Unique constraint violated for project", extra={"project_id": str(project.id)})
            raise RepositoryError(f"Unique constraint violated for project {project.id}") from exc
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_SAVE_FAILED", "identifier": str(project.id), "details": str(exc)}
            )
            logger.exception("Failed to save project", extra={"project_id": str(project.id)})
            raise RepositoryError(f"Failed to save project {project.id}") from exc

    async def delete(self, project: Project) -> None:
        raise RepositoryError("Projects cannot be deleted directly. Use domain-approved soft delete if needed.")

    async def get_latest_version(self, project_id: UUID) -> ProjectVersion:
        repo = ProjectVersionRepository(session=self.session, audit_service=self.audit_service)
        return await repo.get_latest(project_id)

    async def set_state(
        self,
        project: Project,
        new_state: ProjectState,
        actor_id: UUID,
        role: UserRole,
        reason: Optional[str] = None
    ) -> None:
        """Set project state with audit, optimistic lock, and RBAC."""
        # Example RBAC check: Only INTERNAL_MANAGER or SYSTEM can move to TECH_REVIEW
        if new_state == ProjectState.TECH_REVIEW and role not in [UserRole.INTERNAL_MANAGER, UserRole.SYSTEM]:
            raise PermissionDenied("Role not allowed to set this state")

        try:
            latest_version = await self.get_latest_version(project.id)

            stmt = update(Project).where(Project.id == project.id, Project.version == project.version).values(
                current_state=new_state,
                version=project.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for project {project.id}")

            transition = StateTransition(
                project_id=project.id,
                project_version=latest_version.version,
                from_state=latest_version.state,
                to_state=new_state,
                actor_id=actor_id,
                role=role,
                reason=reason,
                created_at=datetime.utcnow()
            )
            self.session.add(transition)
            await self.session.commit()
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning(
                {"event": "PROJECT_SET_STATE_FAILED", "project_id": str(project.id), "details": str(exc)}
            )
            logger.exception("Failed to update project state", extra={
                "project_id": str(project.id),
                "new_state": new_state.name,
                "actor_id": str(actor_id),
                "role": role.name
            })
            raise RepositoryError(f"Failed to update state for project {project.id}") from exc
