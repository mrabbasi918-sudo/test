from typing import List, Optional
from uuid import UUID
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError

from core.exceptions import RepositoryError, NotFound
from core.logger import logger
from domain.entities.state_transition import StateTransition
from application.services.audit_service import AuditService  # سرویس Audit فاز ۴


class StateTransitionRepository:
    """
    Async repository for StateTransition entity with hardened production rules.

    Responsibilities:
    - Append-only logging of project state transitions
    - Fetch transitions per project/version
    - Audit on failure
    - Return domain entities
    """

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    # -------------------------
    # Fetch Operations
    # -------------------------
    async def get_by_id(self, transition_id: UUID) -> StateTransition:
        try:
            result = await self.session.execute(
                select(StateTransition).where(StateTransition.id == transition_id)
            )
            transition = result.scalar_one_or_none()
            if not transition:
                raise NotFound(f"StateTransition {transition_id} not found")
            return transition
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "STATE_TRANSITION_FETCH_FAILED",
                "transition_id": str(transition_id)
            })
            logger.exception(
                "Failed to fetch state transition by id",
                extra={"transition_id": str(transition_id)}
            )
            raise RepositoryError(f"Failed to fetch state transition {transition_id}") from exc

    async def list_by_project(
        self,
        project_id: UUID,
        project_version: Optional[int] = None
    ) -> List[StateTransition]:
        """Fetch all transitions for a project, optionally filtered by version"""
        try:
            query = select(StateTransition).where(StateTransition.project_id == project_id)
            if project_version is not None:
                query = query.where(StateTransition.project_version == project_version)
            query = query.order_by(StateTransition.created_at.asc())
            result = await self.session.execute(query)
            return result.scalars().all()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "STATE_TRANSITION_LIST_FAILED",
                "project_id": str(project_id),
                "project_version": project_version
            })
            logger.exception(
                "Failed to list state transitions",
                extra={"project_id": str(project_id), "project_version": project_version}
            )
            raise RepositoryError(
                f"Failed to list state transitions for project {project_id}"
            ) from exc

    # -------------------------
    # Save / Append
    # -------------------------
    async def save(self, transition: StateTransition) -> None:
        """
        Append-only save for state transitions.
        No update/delete allowed.
        """
        try:
            self.session.add(transition)
            await self.session.flush()  # Ensure constraints & timestamps
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "STATE_TRANSITION_SAVE_FAILED",
                "project_id": str(transition.project_id),
                "project_version": transition.project_version,
                "from_state": transition.from_state.name,
                "to_state": transition.to_state.name,
                "actor_id": str(transition.actor_id),
                "role": transition.role.name
            })
            logger.exception(
                "Failed to save state transition",
                extra={
                    "project_id": str(transition.project_id),
                    "project_version": transition.project_version,
                    "from_state": transition.from_state.name,
                    "to_state": transition.to_state.name,
                    "actor_id": str(transition.actor_id),
                    "role": transition.role.name
                }
            )
            raise RepositoryError(
                f"Failed to save state transition for project {transition.project_id}"
            ) from exc

    # -------------------------
    # Delete (Not Allowed)
    # -------------------------
    async def delete(self, transition: StateTransition) -> None:
        """
        StateTransitions are immutable and append-only.
        Deletion is strictly prohibited.
        """
        await self.audit_service.log_security_warning({
            "event": "STATE_TRANSITION_DELETE_ATTEMPT",
            "transition_id": str(transition.id)
        })
        raise RepositoryError("StateTransition entities are immutable and cannot be deleted")
