from typing import List, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import update

from core.exceptions import RepositoryError, NotFound, PermissionDenied, OptimisticLockError
from core.logger import logger
from domain.entities.user import User
from domain.value_objects.role import UserRole
from domain.value_objects.state import UserStatus
from application.services.audit_service import AuditService  # فرض بر وجود AuditService


class UserRepository:
    """Async Repository for User entity with Optimistic Locking and Audit."""

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    async def get_by_id(self, user_id: UUID) -> User:
        try:
            result = await self.session.execute(select(User).where(User.id == user_id))
            user = result.scalar_one_or_none()
            if not user:
                raise NotFound(f"User {user_id} not found")
            return user
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "USER_FETCH_FAILED", "identifier": str(user_id), "details": str(exc)}
            )
            logger.exception("Failed to fetch user by id", extra={"user_id": str(user_id)})
            raise RepositoryError(f"Failed to fetch user {user_id}") from exc

    async def get_by_mobile(self, mobile: str) -> User:
        try:
            result = await self.session.execute(select(User).where(User.mobile == mobile))
            user = result.scalar_one_or_none()
            if not user:
                raise NotFound(f"User with mobile {mobile} not found")
            return user
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "USER_FETCH_FAILED", "identifier": mobile, "details": str(exc)}
            )
            logger.exception("Failed to fetch user by mobile", extra={"mobile": mobile})
            raise RepositoryError(f"Failed to fetch user by mobile {mobile}") from exc

    async def list_all(
        self, role: Optional[UserRole] = None, status: Optional[UserStatus] = None, limit: int = 100, offset: int = 0
    ) -> List[User]:
        try:
            query = select(User)
            if role:
                query = query.where(User.role == role)
            if status:
                query = query.where(User.status == status)
            query = query.offset(offset).limit(limit)
            result = await self.session.execute(query)
            return result.scalars().all()
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning(
                {"event": "USER_LIST_FAILED", "details": str(exc)}
            )
            logger.exception("Failed to list users")
            raise RepositoryError("Failed to list users") from exc

    async def save(self, user: User) -> None:
        """
        Save with optimistic locking.
        Raises OptimisticLockError if version mismatch.
        """
        try:
            # Optimistic Lock check
            stmt = update(User).where(User.id == user.id, User.version == user.version).values(
                **user.dict(exclude={"version"}), version=user.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for user {user.id}")

            await self.session.commit()
        except IntegrityError as exc:
            await self.session.rollback()
            logger.exception("Unique constraint violated for user", extra={"user_id": str(user.id)})
            raise RepositoryError(f"Unique constraint violated for user {user.id}") from exc
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning(
                {"event": "USER_SAVE_FAILED", "identifier": str(user.id), "details": str(exc)}
            )
            logger.exception("Failed to save user", extra={"user_id": str(user.id)})
            raise RepositoryError(f"Failed to save user {user.id}") from exc

    async def soft_delete(self, user: User, actor_role: UserRole) -> None:
        """Soft delete implementation with RBAC."""
        if actor_role != UserRole.SUPER_ADMIN:
            raise PermissionDenied("Only SUPER_ADMIN can delete users")

        try:
            stmt = update(User).where(User.id == user.id, User.version == user.version).values(
                status=UserStatus.INACTIVE,
                version=user.version + 1
            )
            result = await self.session.execute(stmt)
            if result.rowcount == 0:
                raise OptimisticLockError(f"Version conflict for user {user.id}")

            await self.session.commit()
        except SQLAlchemyError as exc:
            await self.session.rollback()
            await self.audit_service.log_security_warning(
                {"event": "USER_DELETE_FAILED", "identifier": str(user.id), "details": str(exc)}
            )
            logger.exception("Failed to soft delete user", extra={"user_id": str(user.id)})
            raise RepositoryError(f"Failed to soft delete user {user.id}") from exc
