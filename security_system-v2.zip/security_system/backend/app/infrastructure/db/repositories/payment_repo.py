from typing import Optional
from uuid import UUID
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from core.logger import logger
from core.exceptions import RepositoryError, NotFound, InvalidOperation
from domain.entities.invoice import Invoice
from domain.entities.project import Project
from domain.value_objects.state import ProjectState
from domain.value_objects.role import UserRole
from infrastructure.db.repositories.project_repo import ProjectRepository
from application.services.audit_service import AuditService  # سرویس Audit برای فاز ۴


class InvoiceRepository:
    """
    Async repository for Invoice entity with hardened State Machine integration.
    """

    def __init__(self, session: AsyncSession, audit_service: AuditService):
        self.session = session
        self.audit_service = audit_service

    # -------------------------
    # Invoice Operations
    # -------------------------
    async def create_invoice(self, project: Project, amount: float, actor_id: UUID) -> Invoice:
        """Create a new invoice. Initial status: PENDING"""
        try:
            invoice = Invoice(
                project_id=project.id,
                project_version=project.current_version,
                amount=amount,
                status="PENDING",
                created_at=datetime.utcnow()
            )
            self.session.add(invoice)
            await self.session.flush()
            return invoice
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_CREATE_FAILED",
                "project_id": str(project.id),
                "amount": amount
            })
            logger.exception("Failed to create invoice", extra={"project_id": str(project.id), "amount": amount})
            raise RepositoryError(f"Failed to create invoice for project {project.id}") from exc

    async def mark_invoice_paid(self, invoice: Invoice, actor_id: UUID, payment_type: str = "prepayment") -> Invoice:
        """Mark an invoice as PAID and trigger Project state transitions"""
        try:
            result = await self.session.execute(select(Project).where(Project.id == invoice.project_id))
            project = result.scalar_one_or_none()
            if not project:
                raise NotFound(f"Project {invoice.project_id} not found")

            invoice.status = "PAID"
            self.session.add(invoice)

            project_repo = ProjectRepository(session=self.session, audit_service=self.audit_service)

            if payment_type == "prepayment":
                if project.current_state == ProjectState.INVOICE_SENT:
                    await project_repo.set_state(
                        project=project,
                        new_state=ProjectState.WAITING_FOR_PREPAYMENT,
                        actor_id=actor_id,
                        role=UserRole.SYSTEM,
                        reason="Prepayment marked as PAID"
                    )
                if project.current_state == ProjectState.WAITING_FOR_PREPAYMENT:
                    await project_repo.set_state(
                        project=project,
                        new_state=ProjectState.WAITING_FOR_DOCUMENTS,
                        actor_id=actor_id,
                        role=UserRole.INTERNAL_MANAGER,
                        reason="Prepayment verified"
                    )
            elif payment_type == "final":
                if project.current_state != ProjectState.WAITING_FOR_INSTALLATION:
                    raise InvalidOperation(
                        f"Cannot apply final payment: Project {project.id} in state {project.current_state}"
                    )
                await project_repo.set_state(
                    project=project,
                    new_state=ProjectState.PRODUCT_EVALUATING,
                    actor_id=actor_id,
                    role=UserRole.INTERNAL_MANAGER,
                    reason="Final payment marked as PAID"
                )
            else:
                raise InvalidOperation(f"Unknown payment_type: {payment_type}")

            await self.session.flush()
            return invoice
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_MARK_PAID_FAILED",
                "invoice_id": str(invoice.id),
                "payment_type": payment_type
            })
            logger.exception("Failed to mark invoice as PAID", extra={"invoice_id": str(invoice.id), "payment_type": payment_type})
            raise RepositoryError(f"Failed to mark invoice {invoice.id} as PAID") from exc

    async def cancel_invoice(self, invoice: Invoice, actor_role: UserRole) -> Invoice:
        """Cancel an invoice. Soft delete with RBAC enforcement"""
        if actor_role not in {UserRole.SUPER_ADMIN, UserRole.INTERNAL_MANAGER}:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_CANCEL_UNAUTHORIZED",
                "invoice_id": str(invoice.id),
                "actor_role": actor_role.name
            })
            raise InvalidOperation("User not authorized to cancel invoice")

        try:
            invoice.status = "CANCELED"
            self.session.add(invoice)
            await self.session.flush()
            return invoice
        except SQLAlchemyError as exc:
            await self.audit_service.log_security_warning({
                "event": "INVOICE_CANCEL_FAILED",
                "invoice_id": str(invoice.id),
                "actor_role": actor_role.name
            })
            logger.exception("Failed to cancel invoice", extra={"invoice_id": str(invoice.id)})
            raise RepositoryError(f"Failed to cancel invoice {invoice.id}") from exc
