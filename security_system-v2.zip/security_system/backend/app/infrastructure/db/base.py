# infrastructure/db/base.py

from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import MetaData

# ---------------------------------------------------------
# Naming Convention for Alembic & Deterministic Migrations
# ---------------------------------------------------------
# This ensures stable constraint/index names across environments
# Required for audit-safe, rollback-safe migrations
# ---------------------------------------------------------

NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

metadata = MetaData(naming_convention=NAMING_CONVENTION)


class Base(DeclarativeBase):
    """
    Declarative Base for all SQLAlchemy models.

    Rules:
    - All ORM models MUST inherit from this Base
    - No business logic allowed here
    - Used by Alembic for schema generation
    """
    metadata = metadata
