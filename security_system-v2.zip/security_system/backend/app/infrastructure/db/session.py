from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError

from core.exceptions import RepositoryError
from core.logger import logger
from infrastructure.db.base import Base
from app.config.settings import settings

# ---------------------------------------------------------
# Database Engine
# ---------------------------------------------------------
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    future=True,
)

# ---------------------------------------------------------
# Session Factory
# ---------------------------------------------------------
SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
    future=True,
)

# ---------------------------------------------------------
# Session Dependency (FastAPI-friendly)
# ---------------------------------------------------------
@contextmanager
def get_db_session() -> Generator[Session, None, None]:
    """
    Provides a transactional database session.

    Rules:
    - Commit on success
    - Rollback on SQLAlchemyError
    - Raise RepositoryError for infra-level failures
    """
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as exc:
        session.rollback()
        # اضافه کردن db_url به لاگ
        logger.exception(
            "Database transaction failed",
            extra={"db_url": settings.DATABASE_URL.split('@')[-1]}
        )
        raise RepositoryError("Database transaction failed") from exc
    finally:
        session.close()
