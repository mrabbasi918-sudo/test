from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config.settings import settings
from config.logging_config import setup_logging

# Import all routers
from app.api.v1.auth.routes import router as auth_router
from app.api.v1.users.routes import router as users_router
from app.api.v1.projects.routes import router as projects_router
from app.api.v1.transition.routes import router as transition_router
from app.api.v1.files.routes import router as files_router
from app.api.v1.payments.routes import router as payments_router
from app.api.v1.evaluation.routes import router as evaluation_router
from app.api.v1.reports.routes import router as reports_router
from app.api.v1.audit.routes import router as audit_router

# Initialize logging
setup_logging()

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    debug=settings.DEBUG
)

# ---------------------------
# CORS
# ---------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify allowed origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------
# Include Routers
# ---------------------------
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(projects_router)
app.include_router(transition_router)
app.include_router(files_router)
app.include_router(payments_router)
app.include_router(evaluation_router)
app.include_router(reports_router)
app.include_router(audit_router)

# ---------------------------
# Root Endpoint
# ---------------------------
@app.get("/", tags=["root"])
def root():
    return {"message": f"{settings.APP_NAME} is running", "version": settings.VERSION}
