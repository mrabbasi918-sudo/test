from typing import Optional, List
from datetime import datetime
from app.domain.value_objects.state import ProjectState
from app.domain.value_objects.role import UserRole
from app.domain.state_machine.transitions import TRANSITIONS, Transition
from app.infrastructure.db.repositories.state_transition_repo import StateTransitionRepo


class TransitionResult:
    """
    خروجی یک تلاش برای تغییر State
    """
    def __init__(
        self,
        success: bool,
        from_state: ProjectState,
        to_state: ProjectState,
        actor_role: UserRole,
        timestamp: Optional[datetime] = None,
        reason: str = "",
        message: str = "",
    ):
        self.success = success
        self.from_state = from_state
        self.to_state = to_state
        self.actor_role = actor_role
        self.timestamp = timestamp or datetime.utcnow()
        self.reason = reason
        self.message = message

    def to_dict(self):
        return {
            "success": self.success,
            "from_state": self.from_state.value,
            "to_state": self.to_state.value,
            "actor_role": self.actor_role.value,
            "timestamp": self.timestamp.isoformat(),
            "reason": self.reason,
            "message": self.message,
        }


class ProjectStateMachine:
    """
    کلاس مرکزی مدیریت State پروژه
    """

    def __init__(self, current_state: ProjectState, repo: Optional[StateTransitionRepo] = None):
        self.current_state = current_state
        self.repo = repo  # Repository برای ذخیره تاریخچه

    def get_allowed_transitions(self, role: UserRole) -> List[Transition]:
        """
        لیست Transitionهایی که نقش فعلی می‌تواند انجام دهد
        """
        allowed = [
            t for t in TRANSITIONS
            if t["from_state"] == self.current_state and role in t["allowed_roles"]
        ]
        return allowed

    def validate_transition(self, to_state: ProjectState, role: UserRole) -> Optional[str]:
        """
        بررسی اعتبار تغییر State
        بازگشت پیام خطا در صورت غیرمجاز بودن، یا None اگر مجاز است
        """
        if role == UserRole.SUPER_ADMIN:
            # مدیر کل می‌تواند همه را Override کند
            return None

        allowed_transitions = self.get_allowed_transitions(role)
        for t in allowed_transitions:
            if t["to_state"] == to_state:
                return None

        return f"Transition from {self.current_state.value} to {to_state.value} not allowed for role {role.value}"

    async def perform_transition(
        self,
        to_state: ProjectState,
        role: UserRole,
        actor_id: Optional[str] = None,
        reason: str = ""
    ) -> TransitionResult:
        """
        اجرای Transition
        - بررسی اعتبار
        - ثبت در Repository (audit)
        - بازگشت TransitionResult
        """
        error = self.validate_transition(to_state, role)
        if error:
            return TransitionResult(
                success=False,
                from_state=self.current_state,
                to_state=to_state,
                actor_role=role,
                reason=reason,
                message=error
            )

        # Transition معتبر است
        transition = next(
            t for t in TRANSITIONS
            if t["from_state"] == self.current_state and t["to_state"] == to_state
        )

        old_state = self.current_state
        self.current_state = to_state  # تغییر State داخلی (Single Source of Truth)

        result_message = f"Transition executed. Preconditions: {transition.get('preconditions')}. Side Effects: {transition.get('side_effects')}"

        # Persist در DB برای audit
        if self.repo:
            await self.repo.save_transition(
                entity_id=actor_id,  # می‌توانید Entity ID پروژه را جایگزین کنید
                entity_type="Project",
                from_state=old_state,
                to_state=to_state,
                actor_id=actor_id,
                timestamp=datetime.utcnow()
            )

        # می‌توانید در اینجا event emit کنید
        # await event_bus.emit(ProjectStateChanged(...))

        return TransitionResult(
            success=True,
            from_state=old_state,
            to_state=to_state,
            actor_role=role,
            reason=reason,
            message=result_message
        )
