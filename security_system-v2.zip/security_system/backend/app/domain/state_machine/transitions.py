from typing import List, TypedDict, Optional
from app.domain.value_objects.state import ProjectState
from app.domain.value_objects.role import UserRole

class Transition(TypedDict):
    from_state: ProjectState
    to_state: ProjectState
    allowed_roles: List[UserRole]
    preconditions: Optional[str]
    side_effects: Optional[str]

# --- همه Workflowها ---
initial_transitions: List[Transition] = [
    {
        "from_state": ProjectState.DRAFT,
        "to_state": ProjectState.SUBMITTED,
        "allowed_roles": [UserRole.CUSTOMER],
        "preconditions": "تمام فیلدهای مرحله اول تکمیل و کاتالوگ محصول آپلود شده",
        "side_effects": "پروژه قفل و قابل بررسی، اعلان به مدیر داخلی"
    }
]

internal_review_transitions: List[Transition] = [
    {
        "from_state": ProjectState.SUBMITTED,
        "to_state": ProjectState.INTERNAL_REVIEW,
        "allowed_roles": [UserRole.SYSTEM],
        "preconditions": None,
        "side_effects": "ورود به صف بررسی"
    },
    {
        "from_state": ProjectState.INTERNAL_REVIEW,
        "to_state": ProjectState.TECH_REVIEW,
        "allowed_roles": [UserRole.INTERNAL_MANAGER],
        "preconditions": "صحت اطلاعات و فایل‌ها",
        "side_effects": "ارجاع به مدیر فنی"
    },
    {
        "from_state": ProjectState.INTERNAL_REVIEW,
        "to_state": ProjectState.REVISION_REQUIRED_INITIAL,
        "allowed_roles": [UserRole.INTERNAL_MANAGER],
        "preconditions": "نقص اطلاعات یا فایل",
        "side_effects": "ارسال دلیل اصلاح به مشتری"
    }
]

technical_review_transitions: List[Transition] = [
    {
        "from_state": ProjectState.TECH_REVIEW,
        "to_state": ProjectState.INVOICE_SENT,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "تعیین هزینه و پروفایل حفاظتی",
        "side_effects": "صدور فاکتور"
    },
    {
        "from_state": ProjectState.TECH_REVIEW,
        "to_state": ProjectState.REVISION_REQUIRED_INITIAL,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "نیاز به اصلاح اطلاعات",
        "side_effects": "بازگشت به مشتری با توضیح فنی"
    }
]

customer_revision_transitions: List[Transition] = [
    {
        "from_state": ProjectState.REVISION_REQUIRED_INITIAL,
        "to_state": ProjectState.SUBMITTED,
        "allowed_roles": [UserRole.CUSTOMER],
        "preconditions": "اصلاح اطلاعات",
        "side_effects": "project_version++، نسخه قبلی Read-Only، شروع چرخه از ابتدا"
    }
]

payment_transitions: List[Transition] = [
    {
        "from_state": ProjectState.INVOICE_SENT,
        "to_state": ProjectState.WAITING_FOR_PREPAYMENT,
        "allowed_roles": [UserRole.SYSTEM],
        "preconditions": None,
        "side_effects": None
    },
    {
        "from_state": ProjectState.WAITING_FOR_PREPAYMENT,
        "to_state": ProjectState.WAITING_FOR_DOCUMENTS,
        "allowed_roles": [UserRole.INTERNAL_MANAGER],
        "preconditions": "پرداخت ≥ 50٪، تأیید پرداخت",
        "side_effects": "ارسال چک‌لیست اسناد"
    }
]

document_transitions: List[Transition] = [
    {
        "from_state": ProjectState.WAITING_FOR_DOCUMENTS,
        "to_state": ProjectState.DOCUMENT_EVALUATING,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "اسناد آپلود شده",
        "side_effects": None
    },
    {
        "from_state": ProjectState.DOCUMENT_EVALUATING,
        "to_state": ProjectState.WAITING_FOR_INSTALLATION,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "اسناد تأیید شده",
        "side_effects": "اعلام نصب محصول"
    },
    {
        "from_state": ProjectState.DOCUMENT_EVALUATING,
        "to_state": ProjectState.REVISION_REQUIRED_INITIAL,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "نقص اسناد",
        "side_effects": "بارگذاری گزارش نقص"
    }
]

final_review_transitions: List[Transition] = [
    {
        "from_state": ProjectState.WAITING_FOR_INSTALLATION,
        "to_state": ProjectState.PRODUCT_EVALUATING,
        "allowed_roles": [UserRole.INTERNAL_MANAGER],
        "preconditions": "پرداخت کامل",
        "side_effects": "مجوز ارزیابی محصول"
    },
    {
        "from_state": ProjectState.PRODUCT_EVALUATING,
        "to_state": ProjectState.COMPLETED,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "ارزیابی موفق و آپلود نتیجه نهایی",
        "side_effects": "ارسال به افتا، اعلان نهایی"
    },
    {
        "from_state": ProjectState.PRODUCT_EVALUATING,
        "to_state": ProjectState.WAITING_FOR_UPDATE,
        "allowed_roles": [UserRole.TECH_MANAGER],
        "preconditions": "عدم تأیید محصول",
        "side_effects": "گزارش اشکالات"
    },
    {
        "from_state": ProjectState.WAITING_FOR_UPDATE,
        "to_state": ProjectState.SUBMITTED,
        "allowed_roles": [UserRole.CUSTOMER],
        "preconditions": "بروزرسانی محصول",
        "side_effects": "project_version++، نسخه قبلی Immutable، فرآیند از ابتدا"
    }
]

cancel_transitions: List[Transition] = [
    # ANY_STATE → CANCELED
    *[
        {
            "from_state": state,
            "to_state": ProjectState.CANCELED,
            "allowed_roles": [UserRole.CUSTOMER, UserRole.SUPER_ADMIN],
            "preconditions": None,
            "side_effects": None
        }
        for state in [
            ProjectState.DRAFT,
            ProjectState.SUBMITTED,
            ProjectState.INTERNAL_REVIEW,
            ProjectState.TECH_REVIEW,
            ProjectState.REVISION_REQUIRED_INITIAL,
            ProjectState.INVOICE_SENT,
            ProjectState.WAITING_FOR_PREPAYMENT,
            ProjectState.WAITING_FOR_DOCUMENTS,
            ProjectState.DOCUMENT_EVALUATING,
            ProjectState.WAITING_FOR_INSTALLATION,
            ProjectState.PRODUCT_EVALUATING,
            ProjectState.WAITING_FOR_UPDATE
        ]
    ],
    # COMPLETED → CLOSED
    {
        "from_state": ProjectState.COMPLETED,
        "to_state": ProjectState.CLOSED,
        "allowed_roles": [UserRole.SYSTEM, UserRole.SUPER_ADMIN],
        "preconditions": None,
        "side_effects": "پروژه فقط خواندنی"
    }
]

# --- جمع‌آوری همه Transitionها ---
TRANSITIONS: List[Transition] = (
    initial_transitions
    + internal_review_transitions
    + technical_review_transitions
    + customer_revision_transitions
    + payment_transitions
    + document_transitions
    + final_review_transitions
    + cancel_transitions
)

# --- دیکشنری lookup سریع ---
TRANSITIONS_DICT = {
    f"{t['from_state'].value}_{i}": t
    for i, t in enumerate(TRANSITIONS)
}
