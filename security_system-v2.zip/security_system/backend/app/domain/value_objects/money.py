from decimal import Decimal, ROUND_HALF_UP
from typing import Union


class Money:
    """
    Immutable Value Object for monetary values
    """

    __slots__ = ("__amount",)

    def __init__(self, amount: Union[Decimal, int, float, str]):
        value = Decimal(str(amount))

        if value <= 0:
            raise ValueError("Money amount must be greater than zero")

        self.__amount = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def amount(self) -> Decimal:
        return self.__amount

    # ---------- Domain Operations ----------

    def add(self, other: "Money") -> "Money":
        self._assert_money(other)
        return Money(self.amount + other.amount)

    def subtract(self, other: "Money") -> "Money":
        self._assert_money(other)

        result = self.amount - other.amount
        if result <= 0:
            raise ValueError("Resulting Money amount must be greater than zero")

        return Money(result)

    def multiply(self, factor: Union[int, float, Decimal]) -> "Money":
        factor = Decimal(str(factor))
        if factor <= 0:
            raise ValueError("Multiplication factor must be greater than zero")

        return Money(self.amount * factor)

    # ---------- Comparisons ----------

    def is_zero(self) -> bool:
        return self.amount == Decimal("0.00")

    def is_greater_than(self, other: "Money") -> bool:
        self._assert_money(other)
        return self.amount > other.amount

    def is_greater_or_equal(self, other: "Money") -> bool:
        self._assert_money(other)
        return self.amount >= other.amount

    # ---------- Helpers ----------

    def _assert_money(self, other):
        if not isinstance(other, Money):
            raise TypeError("Operation allowed only between Money objects")

    # ---------- Magic Methods ----------

    def __eq__(self, other):
        return isinstance(other, Money) and self.amount == other.amount

    def __repr__(self):
        return f"Money({self.amount})"
