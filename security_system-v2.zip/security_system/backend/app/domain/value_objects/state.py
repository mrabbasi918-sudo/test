# domain/value_objects/state.py

from enum import Enum
from app.core.constants import ProjectState as CoreProjectState

class ProjectState(str, Enum):
    """
    Value Object برای Stateهای پروژه.
    فقط mapping ساده بر اساس core/constants.py
    """
    DRAFT = CoreProjectState.DRAFT
    SUBMITTED = CoreProjectState.SUBMITTED
    INTERNAL_REVIEW = CoreProjectState.INTERNAL_REVIEW
    TECH_REVIEW = CoreProjectState.TECH_REVIEW
    REVISION_REQUIRED_INITIAL = CoreProjectState.REVISION_REQUIRED_INITIAL
    INVOICE_SENT = CoreProjectState.INVOICE_SENT
    WAITING_FOR_PREPAYMENT = CoreProjectState.WAITING_FOR_PREPAYMENT
    WAITING_FOR_DOCUMENTS = CoreProjectState.WAITING_FOR_DOCUMENTS
    DOCUMENT_EVALUATING = CoreProjectState.DOCUMENT_EVALUATING
    WAITING_FOR_INSTALLATION = CoreProjectState.WAITING_FOR_INSTALLATION
    PRODUCT_EVALUATING = CoreProjectState.PRODUCT_EVALUATING
    WAITING_FOR_UPDATE = CoreProjectState.WAITING_FOR_UPDATE
    COMPLETED = CoreProjectState.COMPLETED
    CANCELED = CoreProjectState.CANCELED
    CLOSED = CoreProjectState.CLOSED

    @classmethod
    def list_states(cls):
        """
        لیست تمام Stateهای معتبر پروژه
        """
        return [state.value for state in cls]

    @classmethod
    def is_valid(cls, state: str) -> bool:
        """
        بررسی اینکه State معتبر است یا نه
        """
        return state in cls.list_states()
