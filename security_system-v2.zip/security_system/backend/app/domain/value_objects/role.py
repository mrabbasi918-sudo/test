# domain/value_objects/role.py

from enum import Enum
from app.core.constants import UserRole as CoreUserRole

class UserRole(str, Enum):
    """
    Value Object برای نقش‌های کاربر.
    فقط mapping ساده بر اساس core/constants.py
    """
    CUSTOMER = CoreUserRole.CUSTOMER
    INTERNAL_MANAGER = CoreUserRole.INTERNAL_MANAGER
    TECH_MANAGER = CoreUserRole.TECH_MANAGER
    SUPER_ADMIN = CoreUserRole.SUPER_ADMIN

    @classmethod
    def list_roles(cls):
        """
        لیست تمام نقش‌های معتبر.
        """
        return [role.value for role in cls]
    
    @classmethod
    def is_valid(cls, role: str) -> bool:
        """
        بررسی اینکه یک نقش معتبر است یا نه.
        """
        return role in cls.list_roles()
