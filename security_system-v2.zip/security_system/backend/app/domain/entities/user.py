# domain/entities/user.py

from uuid import UUID
from datetime import datetime
from typing import Optional
from app.domain.value_objects.role import UserRole
from app.domain.value_objects.status import UserStatus


class User:
    """
    Entity نماینده یک کاربر سامانه
    """
    def __init__(
        self,
        user_id: UUID,
        full_name: str,
        mobile: str,
        password_hash: str,
        role: UserRole,
        status: UserStatus = UserStatus.ACTIVE,
        failed_login_count: int = 0,
        last_login_at: Optional[datetime] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None
    ):
        self.id = user_id
        self.full_name = full_name
        self.mobile = mobile
        self.password_hash = password_hash
        self.role = role
        self.status = status
        self.failed_login_count = failed_login_count
        self.last_login_at = last_login_at
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def increment_failed_login(self):
        self.failed_login_count += 1

    def reset_failed_login(self):
        self.failed_login_count = 0

    def lock(self):
        self.status = UserStatus.LOCKED

    def unlock(self):
        self.status = UserStatus.ACTIVE

    def update_role(self, new_role: UserRole):
        self.role = new_role
        self.updated_at = datetime.utcnow()

    def update_last_login(self):
        self.last_login_at = datetime.utcnow()

    def __repr__(self):
        return f"<User id={self.id} mobile={self.mobile} role={self.role} status={self.status}>"
