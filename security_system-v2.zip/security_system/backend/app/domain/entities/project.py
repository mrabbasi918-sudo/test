from typing import List, Optional
from uuid import UUID
from datetime import datetime
from app.domain.value_objects.state import ProjectState
from app.domain.value_objects.role import UserRole
from app.domain.state_machine.state_machine import ProjectStateMachine, TransitionResult
from app.domain.exceptions import DomainError

class InvalidProjectTransition(DomainError):
    pass


class Project:
    """
    Entity اصلی پروژه - کاملاً Domain-Driven
    """
    def __init__(
        self,
        project_id: UUID,
        owner_id: UUID,
        current_state: ProjectState,
        current_version: int = 1,
        timeline: Optional[List[TransitionResult]] = None
    ):
        self.id = project_id
        self.owner_id = owner_id
        self._current_state = current_state
        self.current_version = current_version
        self.timeline = timeline or []

        # StateMachine محلی
        self._state_machine = ProjectStateMachine(current_state=self._current_state)

        # Tracking actors
        self.submitted_by: Optional[UUID] = None
        self.submitted_at: Optional[datetime] = None
        self.started_by: Optional[UUID] = None
        self.started_at: Optional[datetime] = None

    # ---------- Properties ----------

    @property
    def current_state(self) -> ProjectState:
        return self._current_state

    # ---------- Domain Behaviors ----------

    def submit(self, actor_id: UUID):
        if self._current_state != ProjectState.DRAFT:
            raise InvalidProjectTransition("Only draft projects can be submitted")

        result = self._state_machine.perform_transition(ProjectState.SUBMITTED, actor_role=None, reason="submit")
        if not result.success:
            raise InvalidProjectTransition("Transition to SUBMITTED failed")

        self._current_state = result.to_state
        self.timeline.append(result)
        self.submitted_by = actor_id
        self.submitted_at = datetime.utcnow()

    def start(self, actor_id: UUID):
        if self._current_state != ProjectState.SUBMITTED:
            raise InvalidProjectTransition("Only submitted projects can be started")

        result = self._state_machine.perform_transition(ProjectState.IN_PROGRESS, actor_role=None, reason="start")
        if not result.success:
            raise InvalidProjectTransition("Transition to IN_PROGRESS failed")

        self._current_state = result.to_state
        self.timeline.append(result)
        self.started_by = actor_id
        self.started_at = datetime.utcnow()

    def apply_transition(self, to_state: ProjectState, actor_role: UserRole, reason: str = "") -> TransitionResult:
        """
        General transition via StateMachine
        """
        result = self._state_machine.perform_transition(to_state, actor_role, reason)
        if result.success:
            self._current_state = result.to_state
            self.timeline.append(result)
        else:
            raise InvalidProjectTransition(f"Cannot transition to {to_state}")
        return result

    # ---------- Read Models ----------

    def get_allowed_transitions(self, role: UserRole):
        return self._state_machine.get_allowed_transitions(role)

    def __repr__(self):
        return f"<Project id={self.id} state={self._current_state} version={self.current_version}>"
