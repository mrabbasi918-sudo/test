from uuid import UUID
from datetime import datetime
from typing import Optional
from enum import Enum


class FileStatus(str, Enum):
    PENDING = "PENDING"
    VALIDATED = "VALIDATED"
    REJECTED = "REJECTED"


class File:
    """
    Entity نماینده یک فایل پروژه
    """

    def __init__(
        self,
        file_id: UUID,
        project_id: UUID,
        project_version: int,
        filename: str,
        file_type: str,
        uploaded_by: UUID,
        uploaded_at: Optional[datetime] = None,
        status: FileStatus = FileStatus.PENDING,
        rejection_reason: Optional[str] = None,
        is_writable: bool = True
    ):
        if project_version <= 0:
            raise ValueError("Project version must be greater than zero")

        self.id = file_id
        self.project_id = project_id
        self.project_version = project_version
        self.filename = filename
        self.file_type = file_type
        self.uploaded_by = uploaded_by
        self.uploaded_at = uploaded_at or datetime.utcnow()
        self.status = status
        self.rejection_reason = rejection_reason
        self.is_writable = is_writable

    # ---------- Domain Behaviors ----------

    def mark_validated(self):
        self._assert_writable()
        self.status = FileStatus.VALIDATED
        self.rejection_reason = None

    def mark_rejected(self, reason: str):
        self._assert_writable()
        self.status = FileStatus.REJECTED
        self.rejection_reason = reason

    def _assert_writable(self):
        if not self.is_writable:
            raise ValueError("Cannot modify a read-only file")

    def mark_readonly(self):
        self.is_writable = False

    def is_valid(self) -> bool:
        return self.status == FileStatus.VALIDATED

    # ---------- Read Models ----------

    def __repr__(self):
        return (
            f"<File id={self.id} project_id={self.project_id} "
            f"version={self.project_version} filename={self.filename} "
            f"status={self.status} writable={self.is_writable}>"
        )
