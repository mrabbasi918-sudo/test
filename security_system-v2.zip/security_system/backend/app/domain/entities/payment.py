from uuid import UUID
from datetime import datetime
from typing import Optional
from app.domain.value_objects.money import Money
from app.domain.exceptions import DomainError

class InvalidPaymentTransition(DomainError):
    pass


class Payment:
    """
    Entity نماینده پرداخت برای یک فاکتور - کاملاً Domain-Driven
    """
    def __init__(
        self,
        payment_id: UUID,
        invoice_id: UUID,
        amount: Money,
        verified: bool = False,
        created_at: Optional[datetime] = None,
        verified_at: Optional[datetime] = None,
    ):
        if verified and not verified_at:
            verified_at = datetime.utcnow()
        if not verified and verified_at:
            raise ValueError("Unverified payment cannot have verified_at")

        self.id = payment_id
        self.invoice_id = invoice_id
        self.amount = amount  # Money
        self._verified = verified
        self.created_at = created_at or datetime.utcnow()
        self._verified_at = verified_at

    # ---------- Properties ----------

    @property
    def verified(self) -> bool:
        return self._verified

    @property
    def verified_at(self) -> Optional[datetime]:
        return self._verified_at

    # ---------- Domain Behaviors ----------

    def verify(self):
        """
        تأیید پرداخت (idempotent)
        """
        if self._verified:
            raise InvalidPaymentTransition("Payment already verified")

        self._verified = True
        self._verified_at = datetime.utcnow()

    # ---------- Read Models ----------

    def is_verified(self) -> bool:
        return self._verified

    def __repr__(self):
        status = "VERIFIED" if self._verified else "PENDING"
        return (
            f"<Payment id={self.id} "
            f"invoice_id={self.invoice_id} "
            f"amount={self.amount} "
            f"status={status}>"
        )
