from uuid import UUID
from datetime import datetime
from typing import Optional
from app.domain.value_objects.state import ProjectState
from app.domain.exceptions import DomainError

class InvalidProjectVersionTransition(DomainError):
    pass


class ProjectVersion:
    """
    نماینده یک نسخه از پروژه - کاملاً Domain-Driven
    """
    def __init__(
        self,
        project_id: UUID,
        version: int,
        state: ProjectState,
        is_writable: bool = True,
        created_at: Optional[datetime] = None
    ):
        self.project_id = project_id
        self.version = version
        self._state = state
        self._is_writable = is_writable
        self.created_at = created_at or datetime.utcnow()

    # ---------- Properties ----------

    @property
    def state(self) -> ProjectState:
        return self._state

    @property
    def is_writable(self) -> bool:
        return self._is_writable

    # ---------- Domain Behaviors ----------

    def mark_readonly(self):
        """
        علامت گذاری این نسخه به عنوان Read-Only
        """
        if not self._is_writable:
            return  # idempotent
        self._is_writable = False

    def update_state(self, new_state: ProjectState):
        """
        بروزرسانی State نسخه
        - فقط اگر Writable باشد مجاز است
        """
        if not self._is_writable:
            raise InvalidProjectVersionTransition("Cannot update state of a read-only version")
        self._state = new_state

    # ---------- Read Models ----------

    def __repr__(self):
        status = "Writable" if self._is_writable else "Read-Only"
        return f"<ProjectVersion project_id={self.project_id} version={self.version} state={self._state} {status}>"
