from uuid import UUID
from datetime import datetime
from typing import Optional
from app.domain.value_objects.money import Money
from app.domain.value_objects.invoice_status import InvoiceStatus
from app.domain.exceptions import DomainError

class InvalidInvoiceTransition(DomainError):
    pass


class Invoice:
    """
    Entity نماینده فاکتور پروژه - کاملاً Domain-Driven
    """

    def __init__(
        self,
        invoice_id: UUID,
        project_id: UUID,
        project_version: int,
        amount: Money,
        status: InvoiceStatus = InvoiceStatus.PENDING,
        created_at: Optional[datetime] = None,
    ):
        if project_version <= 0:
            raise ValueError("Project version must be greater than zero")

        self.id = invoice_id
        self.project_id = project_id
        self.project_version = project_version
        self.amount = amount  # Money
        self._status = status
        self.created_at = created_at or datetime.utcnow()

        # Tracking who approved/rejected
        self.approved_at: Optional[datetime] = None
        self.approved_by: Optional[UUID] = None
        self.rejected_at: Optional[datetime] = None
        self.rejected_by: Optional[UUID] = None

    # ---------- Properties ----------

    @property
    def status(self) -> InvoiceStatus:
        return self._status

    # ---------- Domain Behaviors ----------

    def approve(self, actor_id: UUID):
        if self._status == InvoiceStatus.APPROVED:
            raise InvalidInvoiceTransition("Invoice already approved")
        if self._status == InvoiceStatus.REJECTED:
            raise InvalidInvoiceTransition("Rejected invoice cannot be approved")
        if self._status == InvoiceStatus.CANCELED:
            raise InvalidInvoiceTransition("Canceled invoice cannot be approved")

        self._status = InvoiceStatus.APPROVED
        self.approved_at = datetime.utcnow()
        self.approved_by = actor_id

    def reject(self, actor_id: UUID):
        if self._status == InvoiceStatus.REJECTED:
            raise InvalidInvoiceTransition("Invoice already rejected")
        if self._status == InvoiceStatus.APPROVED:
            raise InvalidInvoiceTransition("Approved invoice cannot be rejected")
        if self._status == InvoiceStatus.CANCELED:
            raise InvalidInvoiceTransition("Canceled invoice cannot be rejected")

        self._status = InvoiceStatus.REJECTED
        self.rejected_at = datetime.utcnow()
        self.rejected_by = actor_id

    def cancel(self):
        if self._status == InvoiceStatus.PAID:
            raise InvalidInvoiceTransition("Paid invoice cannot be canceled")
        if self._status == InvoiceStatus.CANCELED:
            raise InvalidInvoiceTransition("Invoice already canceled")

        self._status = InvoiceStatus.CANCELED

    # ---------- Read Models ----------

    def is_payable(self) -> bool:
        return self._status == InvoiceStatus.PENDING

    def __repr__(self):
        return (
            f"<Invoice id={self.id} "
            f"project_id={self.project_id} "
            f"version={self.project_version} "
            f"amount={self.amount} "
            f"status={self._status}>"
        )
