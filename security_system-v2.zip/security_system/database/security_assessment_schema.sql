-- =====================================
-- Security Assessment Database Schema
-- File: security_assessment_schema.sql
-- =====================================

-- ========================
-- 1️⃣ ENUM Definitions
-- ========================

-- User roles
CREATE TYPE USER_ROLE_ENUM AS ENUM ('CUSTOMER', 'INTERNAL_MANAGER', 'TECH_MANAGER', 'SUPER_ADMIN');

-- User status
CREATE TYPE USER_STATUS_ENUM AS ENUM ('ACTIVE', 'INACTIVE', 'LOCKED');

-- Project states
CREATE TYPE PROJECT_STATE_ENUM AS ENUM (
  'DRAFT', 'SUBMITTED', 'INTERNAL_REVIEW', 'TECH_REVIEW',
  'REVISION_REQUIRED_INITIAL', 'INVOICE_SENT', 'WAITING_FOR_PREPAYMENT',
  'WAITING_FOR_DOCUMENTS', 'DOCUMENT_EVALUATING', 'WAITING_FOR_INSTALLATION',
  'PRODUCT_EVALUATING', 'WAITING_FOR_UPDATE', 'COMPLETED', 'CANCELED', 'CLOSED'
);

-- Invoice status
CREATE TYPE INVOICE_STATUS_ENUM AS ENUM ('PENDING', 'PAID', 'CANCELED');

-- ========================
-- 2️⃣ Users Table
-- ========================
CREATE TABLE users (
  id UUID PRIMARY KEY,
  full_name VARCHAR(200) NOT NULL,
  mobile VARCHAR(15) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role USER_ROLE_ENUM NOT NULL,
  status USER_STATUS_ENUM NOT NULL DEFAULT 'ACTIVE',
  failed_login_count INT NOT NULL DEFAULT 0 CHECK (failed_login_count >= 0),
  last_login_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);

-- ========================
-- 3️⃣ Projects & Project Versions
-- ========================

-- Projects table
CREATE TABLE projects (
  id UUID PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES users(id),
  current_state PROJECT_STATE_ENUM NOT NULL,
  current_version INT NOT NULL CHECK (current_version > 0),
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_projects_owner ON projects(owner_id);
CREATE INDEX idx_projects_state ON projects(current_state);

-- Project Versions table
CREATE TABLE project_versions (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  version INT NOT NULL CHECK (version > 0),
  state PROJECT_STATE_ENUM NOT NULL,
  is_writable BOOLEAN NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  UNIQUE(project_id, version),
  CHECK (
    (is_writable = true AND version = (
      SELECT current_version FROM projects WHERE projects.id = project_id
    )) OR is_writable = false
  )
);

CREATE INDEX idx_project_versions_project ON project_versions(project_id);

-- ========================
-- 4️⃣ Files & State Transitions
-- ========================

-- Files table
CREATE TABLE files (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  project_version INT NOT NULL REFERENCES project_versions(version) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  extension VARCHAR(5) NOT NULL CHECK (extension IN ('zip','rar')),
  size BIGINT NOT NULL CHECK (size <= 104857600),
  path TEXT NOT NULL,
  deleted_at TIMESTAMP,
  uploaded_by UUID REFERENCES users(id),
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_files_project ON files(project_id, project_version);

-- State Transitions table (append-only)
CREATE TABLE state_transitions (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  project_version INT NOT NULL REFERENCES project_versions(version) ON DELETE CASCADE,
  from_state PROJECT_STATE_ENUM NOT NULL,
  to_state PROJECT_STATE_ENUM NOT NULL,
  actor_id UUID NOT NULL REFERENCES users(id),
  role USER_ROLE_ENUM NOT NULL,
  reason TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  CHECK (from_state != to_state)
);

CREATE INDEX idx_state_transitions_project ON state_transitions(project_id, project_version);

-- ========================
-- 5️⃣ Financial Tables: Invoices & Payments
-- ========================

-- Invoices table
CREATE TABLE invoices (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  project_version INT NOT NULL REFERENCES project_versions(version),
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  status INVOICE_STATUS_ENUM NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_invoices_project ON invoices(project_id, project_version);

-- Payments table
CREATE TABLE payments (
  id UUID PRIMARY KEY,
  invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_payments_invoice ON payments(invoice_id);

-- ========================
-- 6️⃣ Security: User Sessions & OTP
-- ========================

-- User Sessions
CREATE TABLE user_sessions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  jwt_id TEXT NOT NULL,
  expired_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_user_sessions_user ON user_sessions(user_id);

-- OTP Requests
CREATE TABLE otp_requests (
  id UUID PRIMARY KEY,
  mobile VARCHAR(15) NOT NULL,
  otp_hash TEXT NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_otp_requests_mobile ON otp_requests(mobile);

-- ========================
-- 7️⃣ Optional: Notifications & Report Jobs
-- ========================

-- Notifications table
CREATE TABLE notifications (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  project_id UUID REFERENCES projects(id),
  type VARCHAR(50) NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_project ON notifications(project_id);

-- Report Jobs table
CREATE TABLE report_jobs (
  id UUID PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  parameters JSONB NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('PROCESSING','DONE','FAILED')),
  download_url TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  completed_at TIMESTAMP
);

CREATE INDEX idx_report_jobs_status ON report_jobs(status);
