
State Machine
1. اصول حاکم (Domain Rules)
•	هر Project دقیقاً یک State فعال دارد
•	State فقط از طریق Transition معتبر تغییر می‌کند
•	State Machine در Domain Layer است
•	Repository فقط persist(state, events) می‌کند
•	هر Transition شامل:
o	from_state
o	to_state
o	allowed_roles
o	preconditions
o	side_effects
•	مدیر کل (SUPER_ADMIN) می‌تواند همه Transitionها را Override کند
•	تمام Transitionها:
o	append-only
o	immutable
o	audit-friendly
________________________________________
2. Stateهای رسمی (Canonical States)
DRAFT
SUBMITTED
INTERNAL_REVIEW
TECH_REVIEW
REVISION_REQUIRED_INITIAL
INVOICE_SENT
WAITING_FOR_PREPAYMENT
WAITING_FOR_DOCUMENTS
DOCUMENT_EVALUATING
WAITING_FOR_INSTALLATION
PRODUCT_EVALUATING
WAITING_FOR_UPDATE
COMPLETED
CANCELED
CLOSED
________________________________________
3. Transitionها (State → State → Role)
🔹 3.1 ایجاد و ارسال اولیه پروژه
DRAFT → SUBMITTED
•	نقش: CUSTOMER
•	پیش‌شرط:
o	تمام فیلدهای مرحله اول تکمیل
o	کاتالوگ محصول آپلود شده
•	نتیجه:
o	پروژه قفل و قابل بررسی می‌شود
o	اعلان به مدیر داخلی
🔹 3.2 بررسی مدیر داخلی
SUBMITTED → INTERNAL_REVIEW
•	نقش: SYSTEM
•	نتیجه:
o	ورود به صف بررسی
INTERNAL_REVIEW → TECH_REVIEW
•	نقش: INTERNAL_MANAGER
•	پیش‌شرط:
o	صحت اطلاعات
o	صحت فایل‌ها
•	نتیجه:
o	ارجاع به مدیر فنی
INTERNAL_REVIEW → REVISION_REQUIRED_INITIAL
•	نقش: INTERNAL_MANAGER
•	پیش‌شرط:
o	نقص اطلاعات یا فایل
•	نتیجه:
o	ارسال دلیل اصلاح به مشتری

🔹 3.3 بررسی فنی اولیه
TECH_REVIEW → INVOICE_SENT
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	تعیین هزینه
o	تعیین پروفایل حفاظتی
•	نتیجه:
o	صدور فاکتور
TECH_REVIEW → REVISION_REQUIRED_INITIAL
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	نیاز به اصلاح اطلاعات
•	نتیجه:
o	بازگشت به مشتری با توضیح فنی

🔹 3.4 اصلاح اطلاعات توسط مشتری (Versioned)
REVISION_REQUIRED_INITIAL → SUBMITTED
•	نقش: CUSTOMER
•	پیش‌شرط:
o	اصلاح اطلاعات
•	نتیجه:
o	project_version++
o	نسخه قبلی Read-Only
o	شروع چرخه از ابتدا

🔹 3.5 فاکتور و پرداخت اولیه
INVOICE_SENT → WAITING_FOR_PREPAYMENT
•	نقش: SYSTEM
WAITING_FOR_PREPAYMENT → WAITING_FOR_DOCUMENTS
•	نقش: INTERNAL_MANAGER
•	پیش‌شرط:
o	پرداخت ≥ 50٪
o	تأیید پرداخت
•	نتیجه:
o	ارسال چک‌لیست اسناد

🔹 3.6 دریافت و بررسی اسناد
WAITING_FOR_DOCUMENTS → DOCUMENT_EVALUATING
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	اسناد آپلود شده
DOCUMENT_EVALUATING → WAITING_FOR_INSTALLATION
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	اسناد تأیید شده
•	نتیجه:
o	اعلام نصب محصول
DOCUMENT_EVALUATING → REVISION_REQUIRED_INITIAL
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	نقص اسناد
•	نتیجه:
o	بارگذاری گزارش نقص

🔹 3.7 پرداخت نهایی و ارزیابی محصول
WAITING_FOR_INSTALLATION → PRODUCT_EVALUATING
•	نقش: INTERNAL_MANAGER
•	پیش‌شرط:
o	پرداخت کامل
•	نتیجه:
o	مجوز ارزیابی محصول

🔹 3.8 نتیجه نهایی ارزیابی
PRODUCT_EVALUATING → COMPLETED
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	ارزیابی موفق
o	آپلود نتیجه نهایی
•	نتیجه:
o	ارسال به افتا
o	اعلان نهایی
PRODUCT_EVALUATING → WAITING_FOR_UPDATE
•	نقش: TECH_MANAGER
•	پیش‌شرط:
o	عدم تأیید محصول
•	نتیجه:
o	گزارش اشکالات

🔹 3.9 بازگشت چرخه‌ای (Loop رسمی)
WAITING_FOR_UPDATE → SUBMITTED
•	نقش: CUSTOMER
•	پیش‌شرط:
o	بروزرسانی محصول
•	نتیجه:
o	project_version++
o	نسخه قبلی Immutable
o	فرآیند از ابتدا

🔹 3.10 انصراف و خاتمه
ANY_STATE → CANCELED
•	نقش: CUSTOMER | SUPER_ADMIN
COMPLETED → CLOSED
•	نقش: SYSTEM | SUPER_ADMIN
•	نتیجه:
o	پروژه فقط خواندنی

4. قوانین کنترلی سخت (Non-Negotiable)
•	مشتری فقط در این Stateها Action دارد:
•  DRAFT
REVISION_REQUIRED_INITIAL
WAITING_FOR_UPDATE
•  فایل‌ها:
•	Immutable
•	Versioned
•	Soft Delete فقط توسط مدیر کل
•  هر Transition شامل:
•	{
•	  "project_id",
•	  "project_version",
•	  "from_state",
•	  "to_state",
•	  "actor_id",
•	  "role",
•	  "timestamp",
•	  "reason"
•	}
•	
