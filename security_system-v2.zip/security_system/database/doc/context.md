# Security Assessment (مکانیزه‌سازی ارزیابی امنیتی افتا)

این سند **Context مرجع، دقیق و حرفه‌ای** برای پیاده‌سازی Backend، Frontend، Database و ساختار فایل سامانه ارزیابی امنیتی افتا است و به‌گونه‌ای طراحی شده که **مبنای مستقیم توسعه، طراحی معماری، تخمین، و قرارداد فنی** قرار گیرد.

---
## 1. هدف سامانه (System Purpose)
سامانه Security Assessment با هدف **مکانیزه‌سازی کامل چرخه ارزیابی امنیتی افتا** طراحی می‌شود؛ از ثبت درخواست مشتری تا بررسی‌های مدیریتی و فنی، پرداخت‌ها، ارزیابی محصول، مدیریت نسخه‌ها و ارسال نتیجه نهایی به افتا، با تمرکز ویژه بر:
- کنترل دقیق فرآیند (Process Governance)
- ردگیری کامل تصمیمات (Auditability)
- امنیت، تغییرناپذیری داده‌ها و فایل‌ها
- شفافیت وضعیت پروژه برای همه نقش‌ها

---
## 2. اصول معماری کلان (Architecture Principles)

### 2.1 Backend
- زبان: **Python**
- فریم‌ورک: **FastAPI**
- معماری: **Clean Architecture / Clean Repository**
- الگوی دامنه: **Domain-Driven Design (DDD-lite)**

#### لایه‌ها:
- **Domain Layer**
  - Entities (Project, ProjectVersion, User, File, Invoice, Payment)
  - Value Objects (State, Role, Money, FileMeta)
  - State Machine (منبع حقیقت وضعیت پروژه)
  - Domain Rules & Invariants
- **Application Layer**
  - UseCases (SubmitProject, ApproveInvoice, UploadDocument, etc.)
  - Orchestration of Domain Logic
- **Infrastructure Layer**
  - PostgreSQL Repositories
  - MinIO Adapter
  - SMS Provider Adapter
  - Auth/JWT Provider
- **API Layer**
  - RESTful APIs
  - Role-based Access Control (RBAC)

> نکته کلیدی: **State Machine فقط در Domain Layer قرار دارد** و Repositoryها فقط عملیات Persist انجام می‌دهند.

---
## 3. مدیریت وضعیت (State Machine – Core of System)

### 3.1 اصول حاکم (Domain Rules)
- هر Project دقیقاً در هر لحظه **فقط یک State فعال** دارد
- تغییر State فقط از طریق **Transitionهای تعریف‌شده** مجاز است
- هر Transition شامل:
  - from_state
  - to_state
  - allowed_roles
  - preconditions
  - side_effects
- **SUPER_ADMIN** مجاز به Override همه Transitionها است
- تمام Transitionها:
  - append-only
  - immutable
  - audit-friendly

---
### 3.2 Stateهای رسمی (Canonical Project States)
```
DRAFT
SUBMITTED
INTERNAL_REVIEW
TECH_REVIEW
REVISION_REQUIRED_INITIAL
INVOICE_SENT
WAITING_FOR_PREPAYMENT
WAITING_FOR_DOCUMENTS
DOCUMENT_EVALUATING
WAITING_FOR_INSTALLATION
PRODUCT_EVALUATING
WAITING_FOR_UPDATE
COMPLETED
CANCELED
CLOSED
```

---
### 3.3 Transitionهای رسمی (State → State → Role)

#### ایجاد و ارسال اولیه
- `DRAFT → SUBMITTED` (CUSTOMER)

#### بررسی مدیر داخلی
- `SUBMITTED → INTERNAL_REVIEW` (SYSTEM)
- `INTERNAL_REVIEW → TECH_REVIEW` (INTERNAL_MANAGER)
- `INTERNAL_REVIEW → REVISION_REQUIRED_INITIAL` (INTERNAL_MANAGER)

#### بررسی فنی اولیه
- `TECH_REVIEW → INVOICE_SENT` (TECH_MANAGER)
- `TECH_REVIEW → REVISION_REQUIRED_INITIAL` (TECH_MANAGER)

#### اصلاح اطلاعات (نسخه‌بندی)
- `REVISION_REQUIRED_INITIAL → SUBMITTED` (CUSTOMER)
  - project_version++
  - نسخه قبلی Read-Only

#### پرداخت اولیه
- `INVOICE_SENT → WAITING_FOR_PREPAYMENT` (SYSTEM)
- `WAITING_FOR_PREPAYMENT → WAITING_FOR_DOCUMENTS` (INTERNAL_MANAGER)

#### بررسی اسناد
- `WAITING_FOR_DOCUMENTS → DOCUMENT_EVALUATING` (TECH_MANAGER)
- `DOCUMENT_EVALUATING → WAITING_FOR_INSTALLATION` (TECH_MANAGER)
- `DOCUMENT_EVALUATING → REVISION_REQUIRED_INITIAL` (TECH_MANAGER)

#### پرداخت نهایی و ارزیابی محصول
- `WAITING_FOR_INSTALLATION → PRODUCT_EVALUATING` (INTERNAL_MANAGER)

#### نتیجه نهایی
- `PRODUCT_EVALUATING → COMPLETED` (TECH_MANAGER)
- `PRODUCT_EVALUATING → WAITING_FOR_UPDATE` (TECH_MANAGER)

#### بازگشت چرخه‌ای
- `WAITING_FOR_UPDATE → SUBMITTED` (CUSTOMER)
  - project_version++

#### انصراف و بایگانی
- `ANY_STATE → CANCELED` (CUSTOMER | SUPER_ADMIN)
- `COMPLETED → CLOSED` (SYSTEM | SUPER_ADMIN)

---
## 4. مدیریت نسخه پروژه (Project Versioning)
- `project_id` ثابت است
- `project_version` افزایشی (1,2,3,...)
- فقط آخرین نسخه **Writable** است
- نسخه‌های قبلی:
  - Read-Only
  - Immutable
  - قابل Audit

---
## 5. مدیریت فایل‌ها (File Management – MinIO)

- Storage: **MinIO**
- Bucket Versioning: **Enabled**
- Object Lock: **Governance Mode**
- Structure:
```
/project-{project_id}/v{project_version}/
```
- قوانین:
  - فایل‌ها Immutable (No overwrite)
  - فرمت مجاز: zip / rar
  - حداکثر حجم: 100MB
  - Soft Delete فقط توسط SUPER_ADMIN
  - دسترسی فقط برای Owner و Role مجاز

---
## 6. احراز هویت و امنیت (Authentication & Security)

- Authentication: JWT (در Cookie)
- Password Hashing: bcrypt
- Single Active Session per User
  - نشست جدید → نشست قبلی invalidate
- Login Protection:
  - Captcha داخلی تصویری (حروف + نویز)
  - Lock User پس از تلاش ناموفق
- OTP:
  - اعتبار: 2 دقیقه
  - Rate Limit

---
## 7. نقش‌ها (Roles)
- CUSTOMER
- INTERNAL_MANAGER
- TECH_MANAGER
- SUPER_ADMIN

SUPER_ADMIN:
- مدیریت کامل کاربران
- Override State Machine
- Soft Delete فایل‌ها
- مشاهده و دانلود همه لاگ‌ها

---
## 8. گزارش‌ها و BI

- گزارش‌ها از **Database Views**
- خروجی Excel به‌صورت **Async**
- گزارش‌ها شامل:
  - مالی (ماهانه/سالانه/کلی)
  - وضعیت پروژه‌ها
  - نرخ جذب پروژه
  - گزارش جامع پروژه

---
## 9. لاگ و Audit

- Append-only Logs
- شامل:
  - Login / Logout
  - State Transitions
  - Upload / Download
  - Role & User Changes

ساختار لاگ Transition:
```json
{
  "project_id": "UUID",
  "project_version": 3,
  "from_state": "TECH_REVIEW",
  "to_state": "INVOICE_SENT",
  "actor_id": "UUID",
  "role": "TECH_MANAGER",
  "timestamp": "ISO-8601",
  "reason": "Invoice approved"
}
```

---
## 10. Frontend (UI/UX)

- Framework: **Vue 3 + Vuetify 3**
- Features:
  - Stepper فرایند
  - Timeline وضعیت پروژه
  - Progress Bar
  - Validation پیشرفته
  - Notification Center
  - Dashboard مدیریتی

---
## 11. نتیجه‌گیری
این Context سند **منبع حقیقت (Single Source of Truth)** پروژه است و می‌تواند مستقیماً برای:
- طراحی دیتابیس
- پیاده‌سازی Backend
- پیاده‌سازی Frontend
- طراحی API Contracts
- مستندسازی رسمی پروژه
استفاده شود.

