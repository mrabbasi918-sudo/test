# 🗂 Security Assessment – Backend Kanban Checklist

> همه موارد منطبق بر ساختار فایل `backend/app/…` و مستندات شما است.

---

## 1️⃣ app/main.py
- [✔] FastAPI entrypoint
- [✔] Include routers for all v1 APIs
- [✔] Include middleware (CORS, Logging, etc.)

## 2️⃣ config/
### 2.1 settings.py
- [✔] DB config (PostgreSQL)
- [✔] JWT settings
- [✔] MinIO settings
- [✔] Rate limiter settings

### 2.2 logging_config.py
- [✔] Setup Logger
- [✔] File + Console handlers
- [✔] JSON log format
- [✔] Level configuration

---

## 3️⃣ api/v1/
### 3.1 auth/
- [✔] routes.py → /login, /logout, /otp
- [✔] schemas.py → LoginRequest, OTPRequest, OTPVerify, UserSessionResponse
- [✔] service.py → JWT, OTP, Login protection

### 3.2 users/
- [✔] routes.py → SUPER_ADMIN CRUD
- [✔] schemas.py → UserCreate, UserUpdate, UserRead
- [✔] service.py → manage users, hash password, lock/unlock

### 3.3 projects/
- [✔] routes.py → CRUD + Stepper endpoints
- [✔] schemas.py → ProjectCreate, ProjectRead, ProjectUpdate
- [✔] service.py → orchestrate usecases (submit_project, update_data)

### 3.4 transition/
- [✔] routes.py → State Machine API
- [✔] schemas.py → TransitionRequest, TransitionResponse
- [✔] service.py → apply domain rules, optimistic locking, audit

### 3.5 files/
- [✔] routes.py → Upload, Delete
- [✔] schemas.py → FileUploadRequest, FileResponse
- [✔] service.py → MinIO adapter wrapper, versioned storage, soft delete

### 3.6 payments/
- [✔] routes.py → Prepayment, Final Payment
- [✔] schemas.py → PaymentRequest, PaymentResponse
- [✔] service.py → Payment verification, trigger state transitions

### 3.7 evaluation/
- [✔] routes.py → Submit document, submit evaluation
- [✔] schemas.py → EvaluationRequest, EvaluationResponse
- [✔] service.py → Process evaluation, update project state

### 3.8 reports/
- [✔] routes.py → Async export
- [✔] schemas.py → ReportJobRequest, ReportJobStatus
- [✔] service.py → Background task management, generate Excel

### 3.9 audit/
- [✔] routes.py → Get logs, filters
- [✔] schemas.py → AuditLogResponse
- [✔] service.py → Append-only logging, serialize events

---

## 4️⃣ domain/
### 4.1 entities/
- [✔] user.py → User entity
- [✔] project.py → Project entity
- [✔] project_version.py → Versioning
- [✔] file.py → File entity
- [✔] invoice.py → Invoice entity
- [✔] payment.py → Payment entity

### 4.2 value_objects/
- [✔] state.py → ProjectState
- [✔] role.py → USER_ROLE_ENUM
- [✔] money.py → Money value object

### 4.3 state_machine/
- [✔] transitions.py → Define all Transition objects
- [✔] state_machine.py → Apply domain rules, validate, append-only

---

## 5️⃣ application/
### 5.1 usecases/
- [✔] submit_project.py
- [✔] approve_invoice.py
- [✔] upload_document.py
- [✔] evaluate_product.py
- [✔] manage_user.py

### 5.2 services/
- [✔] auth_service.py → login, logout, OTP, JWT
- [✔] otp_service.py → generate, verify OTP, rate limit
- [✔] notification_service.py → Push + email notifications
- [✔] payment_service.py → process payments, trigger state
- [✔] report_service.py → async report generation
- [✔] audit_service.py → log all transitions, actions

---

## 6️⃣ infrastructure/
### 6.1 db/
- [✔] base.py → BaseModel
- [✔] session.py → SQLAlchemy Session
- [ ] repositories/
  - [✔] user_repo.py
  - [✔] project_repo.py
  - [✔] project_version_repo.py
  - [✔] file_repo.py
  - [✔] invoice_repo.py
  - [✔] payment_repo.py
  - [✔] state_transition_repo.py

### 6.2 minio_adapter.py
- [✔] Upload, Versioning, Immutable, Soft Delete

### 6.3 sms_adapter.py
- [✔] Send OTP, SMS templates

### 6.4 jwt_adapter.py
- [✔] Encode/Decode JWT

---

## 7️⃣ core/
- [✔] security.py → Password hashing, session check
- [✔] exceptions.py → Custom exceptions
- [✔] logger.py → Central logger
- [✔] constants.py → ENUMs, messages, hard-coded constants

---

## 8️⃣ tests/
### 8.1 unit/
- [] Test each UseCase
- [] Test Service logic
- [] Test Value Objects

### 8.2 integration/
- [] Test API endpoints
- [] Test DB + Repository integration
- [] Test State Machine transitions

---

## 9️⃣ requirements.txt
- [] FastAPI
- [] SQLAlchemy / Alembic
- [] Pydantic
- [] MinIO SDK
- [] bcrypt, jwt, uvicorn
- [] pytest / httpx

---

## 10️⃣ alembic/
- [ ] Initial migration scripts
- [ ] Revisions for tables (users, projects, files, invoices, payments, transitions)
