State → UI → Actions
DRAFT

Editable Stepper

Actions: Save Draft, Submit

INTERNAL_REVIEW

Read-only

INTERNAL_MANAGER:

Approve

Reject (mandatory reason)

TECH_REVIEW

TECH_MANAGER:

Set Price

Select Security Profile

Approve / Reject

WAITING_FOR_PREPAYMENT

CUSTOMER:

Upload Payment Receipt

Countdown + Auto Reminder

PRODUCT_EVALUATING

Progress Bar

No user actions

WAITING_FOR_UPDATE

Editable (new version)

Warning Banner (Version Increment)

COMPLETED

Timeline locked

Download Result