API Contract (v1) – Security Assessment (Dev/QA-ready)
API Foundations (Non-Negotiable)

Base URL:

/api/v1


Authentication:

JWT در HttpOnly Cookie

CSRF Token برای mutationها

General Rules:

❌ No direct state mutation

✅ State change only via Transition API

✅ Every mutation is audited

✅ Idempotent where applicable

Headers:

Header	Required for	Description
X-Request-Id	All requests	Tracing & correlation بین لاگ‌ها
Idempotency-Key	POST /projects, /transition, /payments	جلوگیری از اجرای دوباره عملیات حساس
OpenAPI-Schema	Reference	لینک به schema auto-generated
1. Error Contract (Unified)
{
  "error_code": "STATE_TRANSITION_NOT_ALLOWED",
  "message": "Transition from TECH_REVIEW to COMPLETED is not allowed",
  "details": {
    "current_state": "TECH_REVIEW",
    "requested_state": "COMPLETED"
  }
}


HTTP Codes

Code	Meaning
400	Validation error
401	Unauthorized
403	Forbidden
409	State conflict
422	Domain rule violation
500	Internal error
2. Authentication & Session

POST /auth/login

{
  "username": "string",
  "password": "string",
  "captcha": "string"
}


Responses:

200 OK → success

423 Locked → account locked

POST /auth/logout → Invalidate active session

POST /auth/otp/request

{
  "mobile": "string",
  "captcha": "string"
}


Rate limited: 5/min

POST /auth/otp/verify

{
  "mobile": "string",
  "otp": "string",
  "new_password": "string"
}

3. User Management (SUPER_ADMIN)

GET /admin/users
Query: ?role=&status=&page=&size=

POST /admin/users

{
  "full_name": "string",
  "mobile": "string",
  "role": "CUSTOMER",
  "password": "string"
}


PATCH /admin/users/{id} → Partial update

4. Project Core

POST /projects

Role: CUSTOMER

State: DRAFT

Requires Idempotency-Key header

{
  "project_id": "UUID",
  "project_version": 1,
  "state": "DRAFT"
}


GET /projects → Role-based visibility, Supports pagination

GET /projects/{project_id}

{
  "project_id": "UUID",
  "current_version": 3,
  "state": "TECH_REVIEW",
  "allowed_transitions": [
    {
      "to_state": "INVOICE_SENT",
      "action": "APPROVE"
    }
  ],
  "timeline": []
}

5. Project Data (Stepper)

PUT /projects/{project_id}/data/company
PUT /projects/{project_id}/data/product

Allowed States: DRAFT, REVISION_REQUIRED_INITIAL, WAITING_FOR_UPDATE

Requires X-Request-Id header

6. 🔥 State Machine API (Critical)

POST /projects/{project_id}/transition

Requires Idempotency-Key header

Requires project_version field (optimistic locking)

{
  "to_state": "SUBMITTED",
  "reason": "Initial submission",
  "expected_version": 3
}


Response Example:

{
  "project_id": "UUID",
  "project_version": 3,
  "from_state": "DRAFT",
  "to_state": "SUBMITTED",
  "status": "SUCCESS",
  "timestamp": "ISO-8601"
}


Rules:

Optimistic locking

Domain validation

Audit log

Notification

7. File Management (MinIO)

POST /projects/{project_id}/files

zip | rar, ≤ 100MB, Immutable

Path: /project-{id}/v{version}

Requires X-Request-Id header

DELETE /projects/{project_id}/files/{file_id}

Role: SUPER_ADMIN

Action: Soft delete

Sample Response:

{
  "file_id": "UUID",
  "status": "UPLOADED",
  "path": "/project-123/v3/file.zip"
}

8. Payments & Invoices

POST /projects/{project_id}/invoice → Creates invoice

POST /projects/{project_id}/payments/prepayment

Triggers: WAITING_FOR_PREPAYMENT → WAITING_FOR_DOCUMENTS

Requires Idempotency-Key header

POST /projects/{project_id}/payments/final

Triggers: WAITING_FOR_INSTALLATION → PRODUCT_EVALUATING

Requires Idempotency-Key header

Sample Response:

{
  "payment_id": "UUID",
  "amount": 5000,
  "status": "SUCCESS",
  "timestamp": "ISO-8601"
}

9. Evaluation

POST /projects/{project_id}/documents/submit
POST /projects/{project_id}/evaluation/result

Requires project_version

Requires X-Request-Id header

10. Reports (Async)

POST /reports/export

{
  "type": "FINANCIAL",
  "from": "2024-01-01",
  "to": "2024-12-31"
}


Response:

{
  "job_id": "UUID"
}


GET /reports/export/{job_id}

{
  "status": "PROCESSING | DONE",
  "download_url": "..."
}

11. Audit Logs

GET /audit/logs
Filters: project_id, user_id, action_type, date_from, date_to

Requires X-Request-Id header

12. Guarantees (Contractual)

✅ Backend-safe

✅ Frontend-safe

✅ State Machine enforced

✅ Fully auditable

❌ No implicit behavior

❌ No magic