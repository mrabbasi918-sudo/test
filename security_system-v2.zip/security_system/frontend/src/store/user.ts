import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

interface UserState {
  id: string | null
  fullName: string | null
  role: string | null
  isAuthenticated: boolean
}

export const useUserStore = defineStore('user', () => {
  const id = ref<string | null>(null)
  const fullName = ref<string | null>(null)
  const role = ref<string | null>(null)
  const isAuthenticated = ref<boolean>(false)

  const userInfo = computed(() => ({ id: id.value, fullName: fullName.value, role: role.value }))
  const isAdmin = computed(() => role.value === 'SUPER_ADMIN')

  const loadFromStorage = () => {
    const stored = localStorage.getItem('user')
    if (stored) {
      const data = JSON.parse(stored)
      id.value = data.id
      fullName.value = data.fullName
      role.value = data.role
      isAuthenticated.value = true
    }
  }

  const login = (user: { id: string; fullName: string; role: string }) => {
    id.value = user.id
    fullName.value = user.fullName
    role.value = user.role
    isAuthenticated.value = true
    localStorage.setItem('user', JSON.stringify(user))
  }

  const logout = () => {
    id.value = null
    fullName.value = null
    role.value = null
    isAuthenticated.value = false
    localStorage.removeItem('user')
  }

  return { id, fullName, role, isAuthenticated, userInfo, isAdmin, loadFromStorage, login, logout }
})
