// frontend/src/store/project.ts
import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { Project } from '@/shared/types/api'

export const useProjectStore = defineStore('project', () => {
  const projects = ref<Record<number, Project>>({}) // project_id -> project

  // Set یا update پروژه
  const setProject = (project: Project) => {
    projects.value[project.project_id] = project
  }

  const updateState = (projectId: number, newState: string) => {
    if (projects.value[projectId]) {
      projects.value[projectId].state = newState
    }
  }

  const getState = (projectId: number) => {
    return projects.value[projectId]?.state
  }

  return { projects, setProject, updateState, getState }
})
