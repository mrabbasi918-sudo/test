<template>
  <div class="transition-buttons">
    <v-btn
      v-for="action in allowedActions"
      :key="action"
      color="primary"
      @click="handleClick(action)"
    >
      {{ action }}
    </v-btn>

    <!-- Snackbar برای نمایش پیام‌ها -->
    <v-snackbar
      v-model="snackbar.show"
      :color="snackbar.color"
      timeout="3000"
      top
      right
    >
      {{ snackbar.message }}
    </v-snackbar>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive } from 'vue'
import { useUserStore } from '@/store/user'
import { useProjectStore } from '@/store/project'
import { permissions } from '@/shared/constants/permissions'
import client from '@/shared/api/client'
import type { Project } from '@/shared/types/api'

interface Props {
  project: Project
}

const props = defineProps<Props>()
const userStore = useUserStore()
const projectStore = useProjectStore()

const snackbar = reactive({
  show: false,
  message: '',
  color: 'success'
})

// محاسبه‌ی اکشن‌های مجاز بر اساس state فعلی و نقش کاربر
const allowedActions = computed(() => {
  const state = projectStore.getState(props.project.project_id) ?? props.project.state
  const role = userStore.role
  return permissions.actions[state]?.[role] ?? []
})

// Mapping Action → State بعدی
const actionToNextState: Record<string, string> = {
  'Submit': 'SUBMITTED',
  'Save Draft': 'DRAFT',
  'Approve': 'APPROVED',
  'Reject': 'REJECTED',
  'Set Price': 'TECH_REVIEW',
  'Select Security Profile': 'TECH_REVIEW',
}

// Handler کلیک روی دکمه
const handleClick = async (action: string) => {
  const projectId = props.project.project_id
  const prevState = projectStore.getState(projectId) ?? props.project.state
  const nextState = actionToNextState[action]

  if (!nextState) {
    snackbar.message = `Action "${action}" has no mapping`
    snackbar.color = 'error'
    snackbar.show = true
    return
  }

  // Optimistic UI: تغییر فوری state
  projectStore.updateState(projectId, nextState)

  try {
    await client.post(`/projects/${projectId}/transition`, { action })
    snackbar.message = `Action "${action}" performed successfully`
    snackbar.color = 'success'
    snackbar.show = true
  } catch (err) {
    // rollback در صورت خطا
    projectStore.updateState(projectId, prevState)
    snackbar.message = `Failed to perform "${action}"`
    snackbar.color = 'error'
    snackbar.show = true
  }
}
</script>

<style scoped>
.transition-buttons {
  display: flex;
  gap: 0.5rem;
}
</style>
