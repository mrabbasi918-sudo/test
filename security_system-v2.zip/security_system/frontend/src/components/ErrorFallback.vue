<template>
  <v-container class="text-center py-16">
    <v-icon size="64" color="error">mdi-alert-circle</v-icon>
    <h2 class="mt-4">مشکلی رخ داده است</h2>
    <p class="text-medium-emphasis">
      لطفاً صفحه را رفرش کنید یا با پشتیبانی تماس بگیرید
    </p>
  </v-container>
</template>
