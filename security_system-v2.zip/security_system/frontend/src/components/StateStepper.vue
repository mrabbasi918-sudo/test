<template>
  <v-stepper :model-value="activeIndex">
    <v-stepper-header>
      <v-stepper-item
        v-for="(state, index) in projectStates"
        :key="state"
        :value="index"
        :complete="index < activeIndex"
      >
        {{ state }}
      </v-stepper-item>
    </v-stepper-header>

    <v-stepper-items>
      <v-stepper-content
        v-for="(state, index) in projectStates"
        :key="state"
        :value="index"
      >
        <slot :state="state" />
        <!-- دکمه‌های transition مخصوص این پروژه -->
        <TransitionButton :project="props.project" />
      </v-stepper-content>
    </v-stepper-items>
  </v-stepper>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { projectStates } from '@/shared/constants/projectStates'
import { useProjectStore } from '@/store/project'
import TransitionButton from './TransitionButton.vue'
import type { Project } from '@/shared/types/api'

const props = defineProps<{ project: Project }>()
const projectStore = useProjectStore()

// محاسبه activeIndex بر اساس state فعلی پروژه
const activeIndex = computed(() => {
  const state = projectStore.getState(props.project.project_id) ?? props.project.state
  return projectStates.indexOf(state)
})
</script>

<style scoped>
/* می‌توانید styling اضافی اضافه کنید */
</style>
