<script setup lang="ts">
import { computed } from 'vue'
import { useUserStore } from '@/store/user'

const props = defineProps<{
  roles: string[]
}>()

const userStore = useUserStore()

const allowed = computed(() =>
  props.roles.includes(userStore.role!) ||
  userStore.role === 'SUPER_ADMIN'
)
</script>

<template>
  <slot v-if="allowed" />
</template>
