<script setup lang="ts">
import type { TimelineEvent } from '@/shared/types/timeline'

defineProps<{
  events: TimelineEvent[]
}>()
</script>

<template>
  <v-timeline>
    <v-timeline-item
      v-for="event in events"
      :key="event.timestamp"
      dot-color="primary"
    >
      <strong>{{ event.from_state }} → {{ event.to_state }}</strong>
      <div>{{ event.role }} | {{ event.timestamp }}</div>
      <small>{{ event.reason }}</small>
    </v-timeline-item>
  </v-timeline>
</template>
