<template>
  <v-snackbar
    v-for="n in notifications"
    :key="n.id"
    v-model="visible[n.id]"
    :color="colorMap[n.severity]"
    :timeout="n.timeout"
    location="top right"
    @update:model-value="onVisibilityChange(n.id, $event)"
  >
    {{ n.message }}
    <template #actions>
      <v-btn icon="mdi-close" @click="dismiss(n.id)" />
    </template>
  </v-snackbar>
</template>

<script setup lang="ts">
import { computed, reactive, watchEffect } from 'vue'
import { useNotificationStore } from '@/shared/notifications/store'

const store = useNotificationStore()
const notifications = computed(() => store.queue)

// reactive map برای کنترل visibility
const visible = reactive<Record<string, boolean>>({})

// هر notification که اضافه شد، visible آن true شود
watchEffect(() => {
  notifications.value.forEach(n => {
    if (!(n.id in visible)) visible[n.id] = true
  })
})

const colorMap = {
  success: 'green',
  info: 'blue',
  warning: 'orange',
  error: 'red',
}

function dismiss(id: string) {
  store.remove(id)
  delete visible[id]
}

function onVisibilityChange(id: string, value: boolean) {
  if (!value) dismiss(id)
}
</script>
