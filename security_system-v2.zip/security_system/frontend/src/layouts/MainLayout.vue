<template>
  <v-app>
    <!-- App Bar -->
    <v-app-bar app color="primary" dark>
      <v-toolbar-title>Security Assessment Dashboard</v-toolbar-title>
      <v-spacer></v-spacer>

      <div v-if="userStore.isAuthenticated">
        <v-btn text disabled>
          {{ userStore.fullName }} ({{ userStore.role }})
        </v-btn>
        <v-btn text @click="logout">Logout</v-btn>
      </div>
    </v-app-bar>

    <!-- Navigation Drawer -->
    <v-navigation-drawer app permanent>
      <v-list nav>
        <v-list-item
          v-for="item in navItems"
          :key="item.name"
          :to="item.to"
          router
        >
          <v-list-item-title>{{ item.label }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <!-- Main Content -->
    <v-main>
      <v-container fluid>
        <router-view />
      </v-container>
    </v-main>

    <!-- Footer -->
    <v-footer app color="primary" dark>
      <span class="white--text">&copy; 2025 Security Assessment System</span>
    </v-footer>
  </v-app>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useUserStore } from '@/store/user'
import { permissions } from '@/shared/constants/permissions'

const userStore = useUserStore()

const logout = () => {
  userStore.logout()
  // Redirect به login بعد از logout
  window.location.href = '/login'
}

// Navigation Items با استفاده از permissions
const navItems = computed(() => {
  return permissions.nav[userStore.role] ?? []
})
</script>

<style scoped>
/* می‌توان styling اختصاصی اضافه کرد */
</style>
