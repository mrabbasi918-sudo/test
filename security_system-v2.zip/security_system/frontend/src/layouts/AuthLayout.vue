<template>
  <v-app>
    <v-main class="d-flex justify-center align-center" style="height: 100vh;">
      <v-card elevation="12" class="pa-6" max-width="400">
        <v-card-title class="justify-center">
          Security Assessment System
        </v-card-title>

        <v-card-text>
          <router-view />
        </v-card-text>

        <v-card-actions class="justify-center">
          <span>&copy; 2025</span>
        </v-card-actions>
      </v-card>
    </v-main>
  </v-app>
</template>

<script setup lang="ts">
// AuthLayout نیازی به store ندارد چون فقط wrapper برای صفحات Login و OTP است
</script>

<style scoped>
/* می‌توان custom styles اضافه کرد */
</style>
