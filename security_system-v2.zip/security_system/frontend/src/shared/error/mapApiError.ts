import axios from 'axios'

export function mapApiError(error: unknown): string {
  if (axios.isAxiosError(error)) {
    return (
      error.response?.data?.message ||
      error.response?.statusText ||
      'خطای ارتباط با سرور'
    )
  }

  if (error instanceof Error) {
    return error.message
  }

  return 'خطای ناشناخته'
}
