import type { App } from 'vue'
import { useNotifier } from '@/shared/notifications/useNotifier'
import { mapApiError } from './mapApiError'

export function registerErrorBoundary(app: App) {
  app.config.errorHandler = (err, _instance, info) => {
    const notifier = useNotifier()
    notifier.error(mapApiError(err))

    console.error('[Global Error]', err, info)
  }
}
