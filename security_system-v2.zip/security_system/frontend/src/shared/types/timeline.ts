export interface TimelineEvent {
  timestamp: string // ISO-8601
  fromState: string
  toState: string
  actorId: string
  role: string
  reason?: string
}
