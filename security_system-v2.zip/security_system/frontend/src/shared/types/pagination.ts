export interface Pagination {
  page: number
  size: number
  total: number
}
