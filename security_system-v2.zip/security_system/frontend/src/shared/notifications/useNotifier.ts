import { nanoid } from 'nanoid'
import { useNotificationStore } from './store'
import type { NotificationSeverity } from './types'

const DEFAULT_TIMEOUT = 4000

function notify(
  severity: NotificationSeverity,
  message: string,
  options?: Partial<{ timeout: number; dismissible: boolean; meta: object }>
) {
  const store = useNotificationStore()

  store.push({
    id: nanoid(),
    severity,
    message,
    timeout: options?.timeout ?? DEFAULT_TIMEOUT,
    dismissible: options?.dismissible ?? true,
    meta: options?.meta,
  })
}

export function useNotifier() {
  return {
    success: (msg: string, opts?: object) => notify('success', msg, opts),
    info: (msg: string, opts?: object) => notify('info', msg, opts),
    warning: (msg: string, opts?: object) => notify('warning', msg, opts),
    error: (msg: string, opts?: object) => notify('error', msg, opts),
  }
}
