import { defineStore } from 'pinia'
import { reactive } from 'vue'
import type { NotificationPayload } from './types'

const MAX_QUEUE_LENGTH = 50

export const useNotificationStore = defineStore('notifications', () => {
  const queue = reactive<NotificationPayload[]>([])

  const push = (notification: NotificationPayload) => {
    if (queue.length >= MAX_QUEUE_LENGTH) {
      queue.shift() // حذف قدیمی‌ترین پیام
    }
    queue.push(notification)
  }

  const remove = (id: string) => {
    const index = queue.findIndex(n => n.id === id)
    if (index !== -1) queue.splice(index, 1)
  }

  const clear = () => queue.splice(0)

  return { queue, push, remove, clear }
})
