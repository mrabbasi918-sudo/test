export type NotificationSeverity = 'success' | 'info' | 'warning' | 'error'

export interface NotificationPayload {
  id: string
  message: string
  severity: NotificationSeverity
  timeout?: number
  dismissible?: boolean
  meta?: Record<string, unknown>
}
