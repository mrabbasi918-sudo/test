import axios, { AxiosInstance } from 'axios'
import { getCSRFToken } from './csrf'
import { generateRequestId } from '../utils/requestId'
import { generateIdempotencyKey } from '../utils/idempotency'
import { mapApiError } from '@/shared/error/mapApiError'

const client: AxiosInstance = axios.create({
  baseURL: '/api/v1',
  timeout: 15000,
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor
client.interceptors.request.use(config => {
  config.headers ||= {}
  config.headers['X-Request-Id'] = generateRequestId()
  config.headers['X-CSRF-Token'] = getCSRFToken()

  if (['post', 'put', 'patch'].includes(config.method ?? '')) {
    config.headers['Idempotency-Key'] = generateIdempotencyKey()
  }

  return config
})

// Response interceptor
client.interceptors.response.use(
  response => response,
  error => Promise.reject(mapApiError(error))
)

export default client
