import { AxiosError } from 'axios'

export function mapBackendError(error: AxiosError): { code: string, message: string } {
  if (error.response) {
    const { status, data } = error.response
    switch (status) {
      case 400: return { code: 'VALIDATION_ERROR', message: data.message || 'Validation Error' }
      case 401: return { code: 'UNAUTHORIZED', message: 'Unauthorized' }
      case 403: return { code: 'FORBIDDEN', message: 'Access Denied' }
      case 409: return { code: 'STATE_CONFLICT', message: data.message || 'State Conflict' }
      case 422: return { code: 'DOMAIN_RULE', message: data.message || 'Domain Rule Violation' }
      case 500: return { code: 'INTERNAL_ERROR', message: 'Internal Server Error' }
      default: return { code: 'UNKNOWN_ERROR', message: data?.message || 'Unknown Error' }
    }
  } else if (error.request) {
    return { code: 'NO_RESPONSE', message: 'No response from server' }
  } else {
    return { code: 'REQUEST_ERROR', message: error.message }
  }
}
