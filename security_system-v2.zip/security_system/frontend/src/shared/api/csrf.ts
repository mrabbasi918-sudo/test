const CSRF_STORAGE_KEY = 'csrf-token'

export function setCSRFToken(token: string) {
  localStorage.setItem(CSRF_STORAGE_KEY, token)
}

export function getCSRFToken(): string {
  return localStorage.getItem(CSRF_STORAGE_KEY) || ''
}
