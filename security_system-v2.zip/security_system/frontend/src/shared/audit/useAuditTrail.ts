import type { TimelineItem } from '@/shared/types/timeline'

export interface RawAuditLog {
  id: string
  action: string
  actor: string
  createdAt: string
  meta?: Record<string, unknown>
}

export function useAuditTrail(logs: RawAuditLog[]) {
  const timeline: TimelineItem[] = logs.map(log => ({
    id: log.id,
    title: log.action,
    subtitle: log.actor,
    timestamp: log.createdAt,
    meta: log.meta,
  }))

  return { timeline }
}
