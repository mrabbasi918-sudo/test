export const projectStates = [
  'DRAFT',
  'SUBMITTED',
  'INTERNAL_REVIEW',
  'TECH_REVIEW',
  'REVISION_REQUIRED_INITIAL',
  'INVOICE_SENT',
  'WAITING_FOR_PREPAYMENT',
  'WAITING_FOR_DOCUMENTS',
  'DOCUMENT_EVALUATING',
  'WAITING_FOR_INSTALLATION',
  'PRODUCT_EVALUATING',
  'WAITING_FOR_UPDATE',
  'COMPLETED',
  'CANCELED',
  'CLOSED'
] as const

export type ProjectState = typeof projectStates[number]
