export const roles = [
  'CUSTOMER',
  'INTERNAL_MANAGER',
  'TECH_MANAGER',
  'SUPER_ADMIN'
] as const

export type Role = typeof roles[number]
