import type { NavItem } from '@/shared/types/api'

// نوع برای Actions هر نقش در یک State
export type StateActions = {
  [state: string]: {
    [role: string]: string[]
  }
}

export const permissions: {
  nav: Record<string, NavItem[]>
  routes: Record<string, string[]>
  actions: StateActions
} = {
  // Navigation menu per role
  nav: {
    SUPER_ADMIN: [
      { label: 'Dashboard', to: '/' },
      { label: 'Projects', to: '/projects' },
      { label: 'Reports', to: '/reports' },
      { label: 'Audit Logs', to: '/audit-logs' },
    ],
    CUSTOMER: [
      { label: 'Dashboard', to: '/' },
      { label: 'Projects', to: '/projects' },
    ],
    INTERNAL_MANAGER: [
      { label: 'Dashboard', to: '/' },
      { label: 'Projects', to: '/projects' },
      { label: 'Reports', to: '/reports' },
    ],
    TECH_MANAGER: [
      { label: 'Dashboard', to: '/' },
      { label: 'Projects', to: '/projects' },
    ],
  },

  // Route access per role
  routes: {
    '/': ['SUPER_ADMIN', 'CUSTOMER', 'INTERNAL_MANAGER', 'TECH_MANAGER'],
    '/projects': ['SUPER_ADMIN', 'CUSTOMER', 'INTERNAL_MANAGER', 'TECH_MANAGER'],
    '/reports': ['SUPER_ADMIN', 'INTERNAL_MANAGER'],
    '/audit-logs': ['SUPER_ADMIN'],
  },

  // Actions / buttons per state
  actions: {
    DRAFT: {
      CUSTOMER: ['Submit', 'Save Draft'],
    },
    SUBMITTED: {
      INTERNAL_MANAGER: ['Approve', 'Reject'],
    },
    TECH_REVIEW: {
      TECH_MANAGER: ['Set Price', 'Select Security Profile', 'Approve', 'Reject'],
    },
    REVISION_REQUIRED_INITIAL: {
      CUSTOMER: ['Resubmit'],
    },
    INVOICE_SENT: {
      SYSTEM: ['Generate Invoice'],
    },
    WAITING_FOR_PREPAYMENT: {
      CUSTOMER: ['Upload Payment Receipt'],
      INTERNAL_MANAGER: ['Confirm Payment'],
    },
    DOCUMENT_EVALUATING: {
      TECH_MANAGER: ['Approve Documents', 'Request Revision'],
    },
    WAITING_FOR_INSTALLATION: {
      INTERNAL_MANAGER: ['Schedule Installation'],
    },
    PRODUCT_EVALUATING: {
      TECH_MANAGER: ['Finalize Evaluation', 'Request Update'],
    },
    WAITING_FOR_UPDATE: {
      CUSTOMER: ['Upload Updated Product'],
    },
    COMPLETED: {},
    CANCELED: {},
    CLOSED: {},
  },
}
