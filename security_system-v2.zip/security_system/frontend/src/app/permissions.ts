// Canonical Project States
export const projectStates = [
  'DRAFT',
  'SUBMITTED',
  'INTERNAL_REVIEW',
  'TECH_REVIEW',
  'REVISION_REQUIRED_INITIAL',
  'INVOICE_SENT',
  'WAITING_FOR_PREPAYMENT',
  'WAITING_FOR_DOCUMENTS',
  'DOCUMENT_EVALUATING',
  'WAITING_FOR_INSTALLATION',
  'PRODUCT_EVALUATING',
  'WAITING_FOR_UPDATE',
  'COMPLETED',
  'CANCELED',
  'CLOSED'
] as const
export type ProjectState = typeof projectStates[number]

// Roles
export const roles = [
  'CUSTOMER',
  'INTERNAL_MANAGER',
  'TECH_MANAGER',
  'SUPER_ADMIN'
] as const
export type Role = typeof roles[number]

// State Map (State → Role → Actions)
export const stateMap: Record<ProjectState, Record<Role, string[]>> = {
  DRAFT: {
    CUSTOMER: ['Save Draft', 'Submit'],
    INTERNAL_MANAGER: [],
    TECH_MANAGER: [],
    SUPER_ADMIN: ['Override']
  },
  SUBMITTED: {
    CUSTOMER: ['Revise'],
    INTERNAL_MANAGER: ['Approve'],
    TECH_MANAGER: ['Review'],
    SUPER_ADMIN: ['Override']
  },
  INTERNAL_REVIEW: {
    CUSTOMER: [],
    INTERNAL_MANAGER: ['Review'],
    TECH_MANAGER: ['Review'],
    SUPER_ADMIN: ['Override']
  },
  TECH_REVIEW: {
    CUSTOMER: [],
    INTERNAL_MANAGER: ['Review'],
    TECH_MANAGER: ['Approve'],
    SUPER_ADMIN: ['Override']
  },
  REVISION_REQUIRED_INITIAL: {
    CUSTOMER: ['Submit Revision'],
    INTERNAL_MANAGER: ['Approve Revision'],
    TECH_MANAGER: ['Review Revision'],
    SUPER_ADMIN: ['Override']
  },
  INVOICE_SENT: {
    CUSTOMER: ['Pay Invoice'],
    INTERNAL_MANAGER: [],
    TECH_MANAGER: ['Verify Payment'],
    SUPER_ADMIN: ['Override']
  },
  WAITING_FOR_PREPAYMENT: {
    CUSTOMER: ['Make Prepayment'],
    INTERNAL_MANAGER: ['Verify Prepayment'],
    TECH_MANAGER: [],
    SUPER_ADMIN: ['Override']
  },
  WAITING_FOR_DOCUMENTS: {
    CUSTOMER: ['Upload Documents'],
    INTERNAL_MANAGER: ['Review Documents'],
    TECH_MANAGER: [],
    SUPER_ADMIN: ['Override']
  },
  DOCUMENT_EVALUATING: {
    CUSTOMER: [],
    INTERNAL_MANAGER: [],
    TECH_MANAGER: ['Evaluate Documents'],
    SUPER_ADMIN: ['Override']
  },
  WAITING_FOR_INSTALLATION: {
    CUSTOMER: [],
    INTERNAL_MANAGER: ['Approve Installation'],
    TECH_MANAGER: ['Install'],
    SUPER_ADMIN: ['Override']
  },
  PRODUCT_EVALUATING: {
    CUSTOMER: [],
    INTERNAL_MANAGER: ['Approve Product'],
    TECH_MANAGER: ['Evaluate Product'],
    SUPER_ADMIN: ['Override']
  },
  WAITING_FOR_UPDATE: {
    CUSTOMER: ['Submit Update'],
    INTERNAL_MANAGER: [],
    TECH_MANAGER: [],
    SUPER_ADMIN: ['Override']
  },
  COMPLETED: {
    CUSTOMER: ['View Results'],
    INTERNAL_MANAGER: ['Close Project'],
    TECH_MANAGER: ['Finalize'],
    SUPER_ADMIN: ['Override']
  },
  CANCELED: {
    CUSTOMER: ['Reopen Project'],
    INTERNAL_MANAGER: [],
    TECH_MANAGER: [],
    SUPER_ADMIN: ['Override']
  },
  CLOSED: {
    CUSTOMER: [],
    INTERNAL_MANAGER: [],
    TECH_MANAGER: [],
    SUPER_ADMIN: ['Override']
  }
}

// Role Permissions
export const rolePermissions: Record<Role, string[]> = {
  CUSTOMER: ['Create Project', 'Submit Project', 'View Project', 'Revise Project'],
  INTERNAL_MANAGER: ['Approve Project', 'Review Documents', 'Manage Installation'],
  TECH_MANAGER: ['Review Documents', 'Approve Product', 'Install Product'],
  SUPER_ADMIN: ['Manage Users', 'Override State Transitions', 'View All Projects', 'Delete Files']
}
