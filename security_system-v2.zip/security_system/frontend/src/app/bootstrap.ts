// frontend/src/app/bootstrap.ts
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { createRouter, createWebHistory } from 'vue-router'

import App from '@/layouts/MainLayout.vue'
import routes from './router'
import vuetify from '@/styles/vuetify'
import { installGuards } from './guards'
import { registerErrorBoundary } from '@/shared/error/error-boundary'

import { useUserStore } from '@/store/user'

// 1️⃣ Create app
const app = createApp(App)

// 2️⃣ Pinia
const pinia = createPinia()
app.use(pinia)

// 3️⃣ Load persisted user AFTER pinia install
const userStore = useUserStore(pinia)
userStore.loadFromStorage()

// 4️⃣ Router
const router = createRouter({
  history: createWebHistory(),
  routes,
})
app.use(router)

// 5️⃣ Guards (depends on router + store)
installGuards(router)

// 6️⃣ Vuetify
app.use(vuetify)

// 7️⃣ Global error boundary
registerErrorBoundary(app)

// 8️⃣ Mount
app.mount('#app')
