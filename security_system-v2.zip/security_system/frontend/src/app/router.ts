import type { RouteRecordRaw } from 'vue-router'

// --------------------
// Lazy-loaded Views
// --------------------

// Auth
const Login = () => import('@/modules/auth/views/Login.vue')
const OtpReset = () => import('@/modules/auth/views/OtpReset.vue')

// Dashboard
const Dashboard = () => import('@/modules/dashboard/views/Dashboard.vue')

// Projects Core
const ProjectList = () => import('@/modules/projects/views/ProjectList.vue')
const ProjectDetail = () => import('@/modules/projects/views/ProjectDetail.vue')

// Stepper Steps
const DraftStep = () => import('@/modules/projects/views/steps/DraftStep.vue')
const ReviewStep = () => import('@/modules/projects/views/steps/ReviewStep.vue')
const PaymentStep = () => import('@/modules/projects/views/steps/PaymentStep.vue')
const EvaluationStep = () => import('@/modules/projects/views/steps/EvaluationStep.vue')
const ResultStep = () => import('@/modules/projects/views/steps/ResultStep.vue')
const TechReviewStep = () => import('@/modules/projects/views/steps/TechReviewStep.vue')
const UpdateStep = () => import('@/modules/projects/views/steps/UpdateStep.vue')
const InvoiceStep = () => import('@/modules/projects/views/steps/InvoiceStep.vue')

// Files
const FileUpload = () => import('@/modules/files/views/FileUpload.vue')

// Payments
const Prepayment = () => import('@/modules/payments/views/Prepayment.vue')
const FinalPayment = () => import('@/modules/payments/views/FinalPayment.vue')

// Reports
const Reports = () => import('@/modules/reports/views/Reports.vue')

// Audit
const AuditLogs = () => import('@/modules/audit/views/AuditLogs.vue')

// --------------------
// Routes
// --------------------

const routes: Array<RouteRecordRaw> = [
  // Auth
  { path: '/login', name: 'Login', component: Login, meta: { requiresAuth: false } },
  { path: '/otp-reset', name: 'OtpReset', component: OtpReset, meta: { requiresAuth: false } },

  // Dashboard
  { path: '/', name: 'Dashboard', component: Dashboard, meta: { requiresAuth: true } },

  // Projects
  { path: '/projects', name: 'ProjectList', component: ProjectList, meta: { requiresAuth: true } },
  { path: '/projects/:id', name: 'ProjectDetail', component: ProjectDetail, meta: { requiresAuth: true } },

  // Stepper Routes (state-specific)
  { path: '/projects/:id/draft', name: 'DraftStep', component: DraftStep, meta: { requiresAuth: true, projectState: 'DRAFT' } },
  { path: '/projects/:id/internal-review', name: 'ReviewStep', component: ReviewStep, meta: { requiresAuth: true, projectState: 'INTERNAL_REVIEW' } },
  { path: '/projects/:id/tech-review', name: 'TechReviewStep', component: TechReviewStep, meta: { requiresAuth: true, projectState: 'TECH_REVIEW' } },
  { path: '/projects/:id/invoice', name: 'InvoiceStep', component: InvoiceStep, meta: { requiresAuth: true, projectState: 'INVOICE_SENT' } },
  { path: '/projects/:id/prepayment', name: 'Prepayment', component: Prepayment, meta: { requiresAuth: true, projectState: 'WAITING_FOR_PREPAYMENT' } },
  { path: '/projects/:id/documents', name: 'DocumentStep', component: FileUpload, meta: { requiresAuth: true, projectState: 'WAITING_FOR_DOCUMENTS' } },
  { path: '/projects/:id/evaluation-docs', name: 'EvaluationStep', component: EvaluationStep, meta: { requiresAuth: true, projectState: 'DOCUMENT_EVALUATING' } },
  { path: '/projects/:id/installation', name: 'InstallationStep', component: FinalPayment, meta: { requiresAuth: true, projectState: 'WAITING_FOR_INSTALLATION' } },
  { path: '/projects/:id/product-evaluation', name: 'ProductEvaluation', component: EvaluationStep, meta: { requiresAuth: true, projectState: 'PRODUCT_EVALUATING' } },
  { path: '/projects/:id/update', name: 'UpdateStep', component: UpdateStep, meta: { requiresAuth: true, projectState: 'WAITING_FOR_UPDATE' } },
  { path: '/projects/:id/result', name: 'ResultStep', component: ResultStep, meta: { requiresAuth: true, projectState: 'COMPLETED' } },

  // Files
  { path: '/projects/:id/files', name: 'FileUpload', component: FileUpload, meta: { requiresAuth: true } },

  // Payments (mapped to state transitions)
  { path: '/projects/:id/final-payment', name: 'FinalPayment', component: FinalPayment, meta: { requiresAuth: true, projectState: 'WAITING_FOR_INSTALLATION' } },

  // Reports
  { path: '/reports', name: 'Reports', component: Reports, meta: { requiresAuth: true } },

  // Audit
  { path: '/audit-logs', name: 'AuditLogs', component: AuditLogs, meta: { requiresAuth: true } },

  // Catch-all
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

export default routes
