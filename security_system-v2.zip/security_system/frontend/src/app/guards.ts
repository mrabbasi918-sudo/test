import { Router } from 'vue-router'
import { useUserStore } from '../store/user'
import { stateMap } from './permissions'
import { ref } from 'vue'

const currentProjectState = ref<string | null>(null)

export function installGuards(router: Router) {
  const userStore = useUserStore()

  router.beforeEach(async (to, from) => {
    // 1️⃣ بررسی احراز هویت
    if (to.meta.requiresAuth && !userStore.isAuthenticated) return { name: 'Login' }

    // 2️⃣ بررسی نقش و state
    if (to.meta.projectState) {
      const requiredState: string = to.meta.projectState
      const userRole = userStore.role

      if (!currentProjectState.value) return { name: 'ProjectList' }

      const allowedRoles = Object.keys(stateMap[requiredState] || {}) as string[]
      if (!allowedRoles.includes(userRole!)) return { name: 'Dashboard' }

      if (currentProjectState.value !== requiredState) {
        return { name: 'ProjectDetail', params: { id: 'current' } }
      }
    }

    return true
  })
}

export { currentProjectState }
