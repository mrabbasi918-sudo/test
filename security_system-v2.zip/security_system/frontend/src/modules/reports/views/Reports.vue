<template>
  <v-card>
    <v-card-title>Reports</v-card-title>
    <v-card-text>
      <v-form @submit.prevent="request">
        <v-select
          v-model="type"
          :items="reportTypes"
          label="Report Type"
          required
        />
        <v-text-field
          v-model="from"
          type="date"
          label="From"
          required
        />
        <v-text-field
          v-model="to"
          type="date"
          label="To"
          required
        />
        <v-btn type="submit">Generate</v-btn>
      </v-form>

      <v-list>
        <v-list-item v-for="job in jobs" :key="job.job_id">
          <v-list-item-content>
            <div>{{ job.type }} - {{ job.status }}</div>
            <v-btn v-if="job.status === 'DONE'" :href="job.download_url" target="_blank">Download</v-btn>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import * as api from '../api'
import type { ReportJob, ReportType } from '../types'
import { useStore } from '@/store/user'

const store = useStore()
const reportTypes: ReportType[] = ['FINANCIAL', 'PROJECT_STATUS', 'PROJECT_SUMMARY']
const type = ref<ReportType>('FINANCIAL')
const from = ref<string>(new Date().toISOString().substring(0, 10))
const to = ref<string>(new Date().toISOString().substring(0, 10))
const jobs = ref<ReportJob[]>([])

const fetchJobStatus = async (job: ReportJob) => {
  if (job.status === 'PROCESSING') {
    const updated = await api.getReportStatus(job.job_id)
    Object.assign(job, updated)
  }
}

const pollJobs = () => {
  jobs.value.forEach(fetchJobStatus)
}

const request = async () => {
  const job = await api.requestReport({ type: type.value, from: from.value, to: to.value })
  jobs.value.push(job)
}

onMounted(() => {
  setInterval(pollJobs, 5000)
})
</script>
