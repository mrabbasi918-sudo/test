# Reports Module

Generates asynchronous reports for Security Assessment projects.

## Features
- Async report generation (Financial, Project Status, Project Summary)
- Role-based access (SUPER_ADMIN, INTERNAL_MANAGER)
- Reports are downloadable when completed
- Integrated with auth/store/user for access control

## API
- `POST /reports/export` → request a new report
- `GET /reports/export/{job_id}` → check status/download

## Frontend
- `Reports.vue` → list, request, and download reports
