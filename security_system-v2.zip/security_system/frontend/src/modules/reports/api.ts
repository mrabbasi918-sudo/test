import axios from 'axios'
import type { ReportRequest, ReportJob } from './types'
import { useStore } from '@/store/user'

const API_BASE = '/api/v1/reports'

export const requestReport = async (payload: ReportRequest) => {
  const store = useStore()
  const res = await axios.post<ReportJob>(`${API_BASE}/export`, payload, {
    headers: {
      'X-Request-Id': crypto.randomUUID(),
      'Authorization': `Bearer ${store.token}`
    }
  })
  return res.data
}

export const getReportStatus = async (jobId: string) => {
  const store = useStore()
  const res = await axios.get<ReportJob>(`${API_BASE}/export/${jobId}`, {
    headers: { 'Authorization': `Bearer ${store.token}` }
  })
  return res.data
}
