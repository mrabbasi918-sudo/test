export type ReportType = 'FINANCIAL' | 'PROJECT_STATUS' | 'PROJECT_SUMMARY'

export interface ReportRequest {
  type: ReportType
  from: string // ISO date
  to: string   // ISO date
}

export interface ReportJob {
  job_id: string
  status: 'PROCESSING' | 'DONE' | 'FAILED'
  download_url?: string
  requested_by: string
  requested_at: string
}

export interface ReportError {
  error_code: string
  message: string
  details?: any
}
