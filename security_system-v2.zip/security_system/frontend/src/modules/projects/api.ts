// modules/projects/api.ts
import client from '@/shared/api/client'
import type {
  Project,
  CompanyData,
  ProductData,
  Payment,
  FileEntry,
  EvaluationResult,
  Transition
} from './types'

const BASE = '/projects'

export const fetchProjects = async (page = 1, size = 20) =>
  client.get<{ data: Project[]; total: number }>(`${BASE}?page=${page}&size=${size}`)

export const fetchProject = async (project_id: string) => client.get<Project>(`${BASE}/${project_id}`)

export const createProject = async (payload: Partial<Project>, idempotencyKey: string) =>
  client.post<Project>(BASE, payload, { headers: { 'Idempotency-Key': idempotencyKey } })

export const updateCompanyData = async (project_id: string, data: CompanyData, requestId: string) =>
  client.put(`${BASE}/${project_id}/data/company`, data, { headers: { 'X-Request-Id': requestId } })

export const updateProductData = async (project_id: string, data: ProductData, requestId: string) =>
  client.put(`${BASE}/${project_id}/data/product`, data, { headers: { 'X-Request-Id': requestId } })

export const submitTransition = async (
  project_id: string,
  payload: { to_state: string; reason: string; expected_version: number },
  idempotencyKey: string
) => client.post<Transition>(`${BASE}/${project_id}/transition`, payload, { headers: { 'Idempotency-Key': idempotencyKey } })

export const uploadFile = async (project_id: string, file: File, requestId: string) => {
  const form = new FormData()
  form.append('file', file)
  return client.post<FileEntry>(`${BASE}/${project_id}/files`, form, { headers: { 'X-Request-Id': requestId } })
}

export const deleteFile = async (project_id: string, file_id: string, requestId: string) =>
  client.delete(`${BASE}/${project_id}/files/${file_id}`, { headers: { 'X-Request-Id': requestId } })

export const submitPayment = async (project_id: string, type: 'prepayment' | 'final', payload: Payment, idempotencyKey: string) =>
  client.post<Payment>(`${BASE}/${project_id}/payments/${type}`, payload, { headers: { 'Idempotency-Key': idempotencyKey } })

export const submitEvaluation = async (project_id: string, payload: EvaluationResult, requestId: string) =>
  client.post<EvaluationResult>(`${BASE}/${project_id}/evaluation/result`, payload, { headers: { 'X-Request-Id': requestId } })
