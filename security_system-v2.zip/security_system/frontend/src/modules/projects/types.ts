// modules/projects/types.ts
export type ProjectState =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'INTERNAL_REVIEW'
  | 'TECH_REVIEW'
  | 'REVISION_REQUIRED_INITIAL'
  | 'INVOICE_SENT'
  | 'WAITING_FOR_PREPAYMENT'
  | 'WAITING_FOR_DOCUMENTS'
  | 'DOCUMENT_EVALUATING'
  | 'WAITING_FOR_INSTALLATION'
  | 'PRODUCT_EVALUATING'
  | 'WAITING_FOR_UPDATE'
  | 'COMPLETED'
  | 'CANCELED'
  | 'CLOSED'

export interface Transition {
  to_state: ProjectState
  action: string
}

export interface TimelineEntry {
  project_id: string
  project_version: number
  from_state: ProjectState
  to_state: ProjectState
  actor_id: string
  role: string
  timestamp: string
  reason: string
}

export interface Project {
  project_id: string
  project_version: number
  state: ProjectState
  allowed_transitions: Transition[]
  timeline: TimelineEntry[]
  company_data?: CompanyData
  product_data?: ProductData
}

export interface CompanyData {
  name: string
  address: string
  contact_person: string
  phone: string
}

export interface ProductData {
  name: string
  description: string
  catalog_uploaded: boolean
  security_profile?: string
  price?: number
}

export interface Payment {
  payment_id: string
  amount: number
  status: 'SUCCESS' | 'FAILED' | 'PENDING'
  timestamp: string
}

export interface FileEntry {
  file_id: string
  path: string
  uploaded_at: string
}

export interface EvaluationResult {
  score: number
  comments: string
  approved: boolean
}
