<template>
  <v-container fluid>
    <v-card>
      <v-card-title>
        Projects
      </v-card-title>
      <v-card-text>
        <v-data-table
          :items="projects"
          :loading="loading"
          :headers="headers"
          item-key="project_id"
          class="elevation-1"
        >
          <template #item.state="{ item }">
            <v-chip :color="stateColor(item.state)" dark>{{ item.state }}</v-chip>
          </template>
          <template #item.actions="{ item }">
            <v-btn color="primary" @click="openDetail(item.project_id)">View</v-btn>
          </template>
        </v-data-table>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup lang="ts">
import { useProjects } from '../composables/useProjects'
import { useRouter } from 'vue-router'
import { computed, onMounted } from 'vue'

const { projects, loading, load } = useProjects()
const router = useRouter()

const headers = [
  { text: 'Project ID', value: 'project_id' },
  { text: 'Version', value: 'project_version' },
  { text: 'State', value: 'state' },
  { text: 'Actions', value: 'actions', sortable: false }
]

const openDetail = (id: string) => router.push({ name: 'ProjectDetail', params: { id } })

onMounted(() => load())

const stateColor = (state: string) => {
  switch (state) {
    case 'DRAFT': return 'grey'
    case 'SUBMITTED': return 'blue'
    case 'INTERNAL_REVIEW': return 'indigo'
    case 'TECH_REVIEW': return 'orange'
    case 'COMPLETED': return 'green'
    case 'CANCELED': return 'red'
    default: return 'primary'
  }
}
</script>
