<template>
  <v-container fluid>
    <v-card>
      <v-card-title>
        Project {{ project?.project_id }} - v{{ project?.project_version }}
      </v-card-title>
      <v-card-text>
        <v-stepper v-model="currentStep">
          <v-stepper-header>
            <v-stepper-step :complete="currentStep > 1" step="1">Draft</v-stepper-step>
            <v-stepper-step :complete="currentStep > 2" step="2">Review</v-stepper-step>
            <v-stepper-step :complete="currentStep > 3" step="3">Payment</v-stepper-step>
            <v-stepper-step :complete="currentStep > 4" step="4">Evaluation</v-stepper-step>
            <v-stepper-step :complete="currentStep > 5" step="5">Result</v-stepper-step>
          </v-stepper-header>

          <v-stepper-items>
            <v-stepper-content step="1">
              <DraftStep :project="project" @update="reloadProject"/>
            </v-stepper-content>
            <v-stepper-content step="2">
              <ReviewStep :project="project" @update="reloadProject"/>
            </v-stepper-content>
            <v-stepper-content step="3">
              <PaymentStep :project="project" @update="reloadProject"/>
            </v-stepper-content>
            <v-stepper-content step="4">
              <EvaluationStep :project="project" @update="reloadProject"/>
            </v-stepper-content>
            <v-stepper-content step="5">
              <ResultStep :project="project"/>
            </v-stepper-content>
          </v-stepper-items>
        </v-stepper>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useProject } from '../composables/useProject'
import DraftStep from './steps/DraftStep.vue'
import ReviewStep from './steps/ReviewStep.vue'
import PaymentStep from './steps/PaymentStep.vue'
import EvaluationStep from './steps/EvaluationStep.vue'
import ResultStep from './steps/ResultStep.vue'

const route = useRoute()
const projectId = route.params.id as string
const { project, loadProject } = useProject(projectId)
const currentStep = ref(1)

const reloadProject = async () => {
  await loadProject()
  // Map state to step index
  switch(project.value?.state) {
    case 'DRAFT':
    case 'REVISION_REQUIRED_INITIAL':
    case 'WAITING_FOR_UPDATE': currentStep.value = 1; break
    case 'SUBMITTED':
    case 'INTERNAL_REVIEW':
    case 'TECH_REVIEW': currentStep.value = 2; break
    case 'INVOICE_SENT':
    case 'WAITING_FOR_PREPAYMENT':
    case 'WAITING_FOR_DOCUMENTS': currentStep.value = 3; break
    case 'DOCUMENT_EVALUATING':
    case 'WAITING_FOR_INSTALLATION':
    case 'PRODUCT_EVALUATING': currentStep.value = 4; break
    case 'COMPLETED':
    case 'CLOSED': currentStep.value = 5; break
  }
}

onMounted(() => reloadProject())
</script>
