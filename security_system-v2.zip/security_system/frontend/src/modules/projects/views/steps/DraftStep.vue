<template>
  <v-card outlined>
    <v-card-title>Draft Step</v-card-title>
    <v-card-text>
      <v-form ref="form" v-model="valid">
        <v-text-field v-model="project.company_name" label="Company Name" :rules="[v => !!v || 'Required']"/>
        <v-text-field v-model="project.product_name" label="Product Name" :rules="[v => !!v || 'Required']"/>
        <v-file-input v-model="catalog" label="Product Catalog (zip/rar)" accept=".zip,.rar" />
      </v-form>
      <v-btn :disabled="!valid" color="primary" @click="saveDraft">Save Draft</v-btn>
      <v-btn :disabled="!canSubmit" color="success" @click="submit">Submit</v-btn>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useTransitions } from '../../composables/useTransitions'
import { useProject } from '../../composables/useProject'
import type { Project } from '../../types'

const props = defineProps<{ project: Project }>()
const { saveProjectData } = useProject(props.project.project_id)
const { executeTransition, getAvailableTransitions } = useTransitions(props.project.project_id, props.project.state, props.project.project_version)

const catalog = ref<File | null>(null)
const form = ref()
const valid = ref(false)

const canSubmit = computed(() => getAvailableTransitions().some(t => t.to_state === 'SUBMITTED'))

const saveDraft = async () => {
  await saveProjectData({ company_name: props.project.company_name, product_name: props.project.product_name })
}

const submit = async () => {
  if (!catalog.value) { alert('Catalog required'); return }
  await saveDraft()
  await executeTransition('SUBMITTED', 'Initial submission')
}
</script>
