<template>
  <v-card outlined>
    <v-card-title>Evaluation Step</v-card-title>
    <v-card-text>
      <v-alert v-if="readOnly" type="info">No actions available at this step</v-alert>
      <v-btn v-if="canApprove" color="success" @click="approve">Approve Product</v-btn>
      <v-btn v-if="canReject" color="error" @click="reject">Send back to Customer</v-btn>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { useTransitions } from '../../composables/useTransitions'

const props = defineProps<{ project: any }>()
const { getAvailableTransitions, executeTransition } = useTransitions(props.project.project_id, props.project.state, props.project.project_version)

const canApprove = computed(() => getAvailableTransitions().some(t => t.to_state === 'COMPLETED'))
const canReject = computed(() => getAvailableTransitions().some(t => t.to_state === 'WAITING_FOR_UPDATE'))
const readOnly = computed(() => !canApprove.value && !canReject.value)

const approve = async () => await executeTransition('COMPLETED', 'Product evaluation approved')
const reject = async () => await executeTransition('WAITING_FOR_UPDATE', 'Product evaluation requires update')
</script>
