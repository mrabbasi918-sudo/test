<template>
  <v-card outlined>
    <v-card-title>Payment Step</v-card-title>
    <v-card-text>
      <v-file-input v-model="receipt" label="Upload Payment Receipt" accept=".zip,.rar"/>
      <v-btn :disabled="!receipt" color="primary" @click="upload">Submit Payment</v-btn>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useProject } from '../../composables/useProject'

const props = defineProps<{ project: any }>()
const { uploadPaymentReceipt } = useProject(props.project.project_id)
const receipt = ref<File | null>(null)

const upload = async () => {
  if (!receipt.value) return
  await uploadPaymentReceipt(receipt.value)
}
</script>
