<template>
  <v-card outlined>
    <v-card-title>Review Step</v-card-title>
    <v-card-text>
      <v-alert v-if="!canApprove && !canReject" type="info">Read-only view</v-alert>
      <v-btn v-if="canApprove" color="success" @click="approve">Approve</v-btn>
      <v-btn v-if="canReject" color="error" @click="reject">Reject</v-btn>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { useTransitions } from '../../composables/useTransitions'

const props = defineProps<{ project: any }>()
const reason = ref('')
const { getAvailableTransitions, executeTransition } = useTransitions(props.project.project_id, props.project.state, props.project.project_version)

const canApprove = computed(() => getAvailableTransitions().some(t => t.to_state !== 'REVISION_REQUIRED_INITIAL'))
const canReject = computed(() => getAvailableTransitions().some(t => t.to_state === 'REVISION_REQUIRED_INITIAL'))

const approve = async () => { await executeTransition(getAvailableTransitions()[0].to_state, 'Approved') }
const reject = async () => {
  const r = prompt('Enter reason for rejection')
  if (!r) return
  await executeTransition('REVISION_REQUIRED_INITIAL', r)
}
</script>
