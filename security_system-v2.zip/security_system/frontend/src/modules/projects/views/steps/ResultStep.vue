<template>
  <v-card outlined>
    <v-card-title>Result Step</v-card-title>
    <v-card-text>
      <v-alert type="success" v-if="project.state === 'COMPLETED'">Evaluation completed. Download final result.</v-alert>
      <v-btn :disabled="!project.result_file" color="primary" @click="download">Download Result</v-btn>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { useProject } from '../../composables/useProject'

const props = defineProps<{ project: any }>()
const { downloadResultFile } = useProject(props.project.project_id)

const download = async () => {
  if (!props.project.result_file) return
  await downloadResultFile(props.project.result_file)
}
</script>
