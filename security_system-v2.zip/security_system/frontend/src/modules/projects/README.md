# Projects Core Module

This module handles all project-related functionality, fully aligned with **Security Assessment** workflow.

## Features
- Role-based access control (RBAC) for all project actions
- State Machine enforced transitions (DRAFT → SUBMITTED → INTERNAL_REVIEW … → COMPLETED → CLOSED)
- Versioned projects (`project_version` incremented on customer edits)
- Immutable historical versions
- Optimistic locking and Idempotency for all sensitive actions
- Audit-friendly timeline (`TimelineEvent`)

## API
- `GET /api/v1/projects` → list projects (RBAC filtered)
- `GET /api/v1/projects/{project_id}` → fetch project details
- `PUT /api/v1/projects/{project_id}/data/company` → update company data (DRAFT/REVISION_REQUIRED_INITIAL/WAITING_FOR_UPDATE)
- `PUT /api/v1/projects/{project_id}/data/product` → update product data (same allowed states)
- `POST /api/v1/projects/{project_id}/transition` → execute state transition (idempotent, optimistic locking)
- `POST /api/v1/projects/{project_id}/files` → upload immutable file
- `DELETE /api/v1/projects/{project_id}/files/{file_id}` → soft delete by SUPER_ADMIN only
- `POST /api/v1/projects/{project_id}/payments/prepayment` → upload prepayment receipt
- `POST /api/v1/projects/{project_id}/payments/final` → final payment

## Composables
- `useProject(projectId)` → fetch, update, upload files & payments
- `useProjects()` → fetch all projects
- `useTransitions(projectId, state, version)` → check allowed transitions & execute state changes

## Frontend Integration
- Stepper-based UX for Draft, Review, Payment, Evaluation, and Result steps
- Progress bar, timeline, notifications
- Role-based dynamic action buttons
- Read-only views for unauthorized roles
- Automatic project versioning and workflow compliance
