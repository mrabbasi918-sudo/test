// modules/projects/composables/useProjects.ts
import { ref } from 'vue'
import { fetchProjects } from '../api'
import type { Project } from '../types'
import { useUserStore } from '@/store/user'

export const useProjects = () => {
  const projects = ref<Project[]>([])
  const total = ref(0)
  const loading = ref(false)
  const error = ref<string | null>(null)
  const userStore = useUserStore()

  const load = async (page = 1, size = 20) => {
    loading.value = true
    try {
      const res = await fetchProjects(page, size)
      // Role-based filtering
      projects.value = res.data.data.filter((p) => {
        if (userStore.role === 'SUPER_ADMIN') return true
        if (userStore.role === 'CUSTOMER') return p.timeline.some((t) => t.actor_id === userStore.user_id)
        if (userStore.role === 'INTERNAL_MANAGER') return ['SUBMITTED', 'INTERNAL_REVIEW'].includes(p.state)
        if (userStore.role === 'TECH_MANAGER') return ['TECH_REVIEW', 'DOCUMENT_EVALUATING', 'PRODUCT_EVALUATING'].includes(p.state)
        return false
      })
      total.value = res.data.total
      error.value = null
    } catch (err: any) {
      error.value = err.message
    } finally {
      loading.value = false
    }
  }

  return { projects, total, loading, error, load }
}
