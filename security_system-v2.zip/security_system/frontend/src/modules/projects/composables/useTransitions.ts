// modules/projects/composables/useTransitions.ts
import { ref } from 'vue'
import { submitTransition } from '../api'
import type { Transition } from '../types'
import { useUserStore } from '@/store/user'
import { statePermissions } from '@/shared/constants/permissions'
import { generateIdempotencyKey } from '@/shared/utils'

export const useTransitions = (projectId: string, currentState: string, projectVersion: number) => {
  const transitions = ref<Transition[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)
  const userStore = useUserStore()

  const getAvailableTransitions = () => {
    const perms = statePermissions[currentState] || {}
    return Object.keys(perms)
      .filter((toState) => perms[toState].includes(userStore.role) || userStore.role === 'SUPER_ADMIN')
      .map((toState) => ({ to_state: toState, action: 'APPROVE' }))
  }

  const executeTransition = async (toState: string, reason: string) => {
    if (!getAvailableTransitions().some((t) => t.to_state === toState)) throw new Error('Transition not allowed')
    const idempotencyKey = generateIdempotencyKey()
    loading.value = true
    try {
      const payload = { to_state: toState, reason, expected_version: projectVersion }
      const res = await submitTransition(projectId, payload, idempotencyKey)
      transitions.value.push({ ...res.data, actor_id: userStore.user_id, role: userStore.role, timestamp: new Date().toISOString() })
      error.value = null
      return res.data
    } catch (err: any) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  return { transitions, loading, error, getAvailableTransitions, executeTransition }
}
