// modules/projects/composables/useProject.ts
import { ref } from 'vue'
import { fetchProject, submitTransition } from '../api'
import type { Project } from '../types'
import { useUserStore } from '@/store/user'
import { statePermissions } from '@/shared/constants/permissions'
import { generateIdempotencyKey } from '@/shared/utils'

export const useProject = (projectId: string) => {
  const project = ref<Project | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)
  const userStore = useUserStore()

  const load = async () => {
    loading.value = true
    try {
      const res = await fetchProject(projectId)
      project.value = res.data
      error.value = null
    } catch (err: any) {
      error.value = err.message
    } finally {
      loading.value = false
    }
  }

  const canTransition = (toState: string) => {
    if (!project.value) return false
    const perms = statePermissions[project.value.state]?.[toState] || []
    return perms.includes(userStore.role) || userStore.role === 'SUPER_ADMIN'
  }

  const submit = async (toState: string, reason: string) => {
    if (!project.value) throw new Error('Project not loaded')
    if (!canTransition(toState)) throw new Error('Transition not allowed')
    const idempotencyKey = generateIdempotencyKey()
    const payload = { to_state: toState, reason, expected_version: project.value.project_version }
    const res = await submitTransition(project.value.project_id, payload, idempotencyKey)
    project.value.project_version++
    project.value.state = res.data.to_state
    project.value.timeline.push({ ...res.data, actor_id: userStore.user_id, role: userStore.role, timestamp: new Date().toISOString() })
  }

  return { project, loading, error, load, canTransition, submit }
}
