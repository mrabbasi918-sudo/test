<template>
  <v-container fluid>
    <v-row>
      <v-col cols="12" md="4">
        <v-card>
          <v-card-title>Welcome</v-card-title>
          <v-card-text>
            <div><strong>User:</strong> {{ user.fullName }}</div>
            <div><strong>Role:</strong> {{ user.role }}</div>
            <div><strong>Authenticated:</strong> {{ user.isAuthenticated ? 'Yes' : 'No' }}</div>
          </v-card-text>
          <v-card-actions>
            <v-btn color="primary" @click="logout">Logout</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>

      <v-col cols="12" md="8">
        <v-card>
          <v-card-title>Projects Overview</v-card-title>
          <v-card-text>
            <v-alert type="info" border="left" colored-border>
              This dashboard displays project summaries according to your role and current permissions.
            </v-alert>

            <v-row>
              <v-col
                v-for="summary in projectSummaries"
                :key="summary.state"
                cols="12"
                sm="6"
                md="4"
              >
                <v-card outlined>
                  <v-card-title>{{ summary.state }}</v-card-title>
                  <v-card-text>{{ summary.count }} projects</v-card-text>
                </v-card>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useUserStore } from '@/store/user'
import { ref, onMounted } from 'vue'
import { projectStates } from '@/app/permissions'

// Reactive store
const userStore = useUserStore()

const user = computed(() => ({
  fullName: userStore.fullName,
  role: userStore.role,
  isAuthenticated: userStore.isAuthenticated
}))

// Logout action
const logout = () => userStore.logout()

// Mocked project summaries for demo
const projectSummaries = ref(
  projectStates.map(state => ({
    state,
    count: Math.floor(Math.random() * 5) // Example count, in real app call API
  }))
)

// TODO: Replace with real API call to fetch projects per role/state
onMounted(() => {
  // fetchProjectsSummary()
})
</script>
