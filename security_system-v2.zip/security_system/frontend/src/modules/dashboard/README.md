# Dashboard Module

## Overview
The Dashboard module provides a high-level overview of the Security Assessment system for the logged-in user.
It is reactive to user state and permissions, and displays project summaries according to the user's role.

## Features
- Welcome card with user information (full name, role, authentication status)
- Logout functionality integrated with Pinia store
- Projects overview cards per project state
- Reactive to `store/user.ts` changes

## Usage
- Accessible only to authenticated users (`meta.requiresAuth = true`)
- Can be extended to include charts, notifications, and more detailed summaries
- Integrates seamlessly with state machine and role permissions

## Notes
- Currently project summaries are mocked. Replace with real API calls to `/projects` endpoints filtered by role.
- Ensure that `store/user.ts` is initialized before mounting the Dashboard.
