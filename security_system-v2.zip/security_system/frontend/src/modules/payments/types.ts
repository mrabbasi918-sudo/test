export type PaymentStatus = 'PENDING' | 'SUCCESS' | 'FAILED'

export interface Payment {
  payment_id: string
  project_id: string
  project_version: number
  type: 'PREPAYMENT' | 'FINAL'
  amount: number
  status: PaymentStatus
  timestamp: string
  paid_by: string
}

export interface PaymentRequest {
  amount: number
}

export interface PaymentResponse {
  payment_id: string
  status: PaymentStatus
  timestamp: string
}

export interface ApiError {
  error_code: string
  message: string
  details?: any
}
