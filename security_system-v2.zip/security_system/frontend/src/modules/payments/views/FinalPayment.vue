<template>
  <v-card>
    <v-card-title>Final Payment</v-card-title>
    <v-card-text>
      <v-text-field
        v-model="amount"
        label="Amount"
        type="number"
        :disabled="!canFinalPay"
      />
      <v-btn :disabled="!canFinalPay" @click="pay">Pay</v-btn>
      <v-list>
        <v-list-item v-for="p in payments" :key="p.payment_id">
          <v-list-item-content>{{ p.type }} - {{ p.amount }} - {{ p.status }}</v-list-item-content>
        </v-list-item>
      </v-list>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { usePayments } from '../composables/usePayments'

const props = defineProps<{
  projectId: string
  projectState: string
}>()

const { payments, canFinalPay, fetchPayments, createFinalPayment } = usePayments(props.projectId, props.projectState)
const amount = ref<number>(0)

const pay = async () => {
  try {
    await createFinalPayment(amount.value)
    amount.value = 0
  } catch (err: any) {
    console.error(err)
    alert(err.message)
  }
}

onMounted(fetchPayments)
</script>
