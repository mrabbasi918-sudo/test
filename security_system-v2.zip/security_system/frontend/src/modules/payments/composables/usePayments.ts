import { ref, computed } from 'vue'
import { useStore } from '@/store/user'
import * as api from './api'
import type { Payment } from './types'
import { useFiles } from '../files/composables/useFiles'

export const usePayments = (projectId: string, projectState: string) => {
  const store = useStore()
  const payments = ref<Payment[]>([])
  const loading = ref(false)

  // Integrate Files module to check completeness
  const { files } = useFiles(projectId, projectState)
  const allRequiredFilesUploaded = computed(() =>
    files.value.every(f => f.status === 'UPLOADED')
  )

  const canPrepay = computed(() => {
    return store.user.role === 'CUSTOMER' &&
      ['INVOICE_SENT'].includes(projectState) &&
      allRequiredFilesUploaded.value
  })

  const canFinalPay = computed(() => {
    return store.user.role === 'CUSTOMER' &&
      ['WAITING_FOR_INSTALLATION'].includes(projectState)
  })

  const fetchPayments = async () => {
    loading.value = true
    try {
      payments.value = await api.getPayments(projectId)
    } finally {
      loading.value = false
    }
  }

  const createPrepayment = async (amount: number) => {
    if (!canPrepay.value) throw new Error('Prepayment not allowed')
    const requestId = crypto.randomUUID()
    const payment = await api.createPrepayment(projectId, { amount }, requestId)
    payments.value.push({ ...payment, project_id: projectId, paid_by: store.user.user_id, project_version: payments.value.length + 1, type: 'PREPAYMENT' })
    return payment
  }

  const createFinalPayment = async (amount: number) => {
    if (!canFinalPay.value) throw new Error('Final payment not allowed')
    const requestId = crypto.randomUUID()
    const payment = await api.createFinalPayment(projectId, { amount }, requestId)
    payments.value.push({ ...payment, project_id: projectId, paid_by: store.user.user_id, project_version: payments.value.length + 1, type: 'FINAL' })
    return payment
  }

  return {
    payments,
    loading,
    canPrepay,
    canFinalPay,
    fetchPayments,
    createPrepayment,
    createFinalPayment
  }
}
