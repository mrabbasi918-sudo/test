# Payments Module

Handles **prepayment and final payment** for Security Assessment projects.

## Features
- Role-based actions:
  - Customer: initiate payments
  - System/Internal Manager: automatic state transitions after payment
- Optimistic locking & Idempotency
- Audit-friendly logs
- Integrates with Projects and Files modules to ensure payments are valid

## API
- `POST /projects/{project_id}/payments/prepayment` → prepayment
- `POST /projects/{project_id}/payments/final` → final payment
- `GET /projects/{project_id}/payments` → list payments

## Composables
- `usePayments(projectId, projectState)` → fetch, create payments
- Checks project state, files completeness, and user role

## Frontend
- `Prepayment.vue` → customer prepayment form
- `FinalPayment.vue` → final payment after installation
