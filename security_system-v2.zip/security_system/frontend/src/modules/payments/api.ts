import axios from 'axios'
import type { PaymentRequest, PaymentResponse, Payment } from './types'

const API_BASE = '/api/v1/projects'

export const createPrepayment = async (projectId: string, payload: PaymentRequest, requestId: string) => {
  const res = await axios.post<PaymentResponse>(`${API_BASE}/${projectId}/payments/prepayment`, payload, {
    headers: { 'X-Request-Id': requestId }
  })
  return res.data
}

export const createFinalPayment = async (projectId: string, payload: PaymentRequest, requestId: string) => {
  const res = await axios.post<PaymentResponse>(`${API_BASE}/${projectId}/payments/final`, payload, {
    headers: { 'X-Request-Id': requestId }
  })
  return res.data
}

export const getPayments = async (projectId: string): Promise<Payment[]> => {
  const res = await axios.get<Payment[]>(`${API_BASE}/${projectId}/payments`)
  return res.data
}
