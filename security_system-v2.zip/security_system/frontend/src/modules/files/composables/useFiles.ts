import { ref, computed } from 'vue'
import { useStore } from '@/store/user'
import type { ProjectFile } from './types'
import * as api from './api'

export const useFiles = (projectId: string, projectState: string) => {
  const files = ref<ProjectFile[]>([])
  const loading = ref(false)
  const store = useStore()

  const canUpload = computed(() => {
    const userRole = store.user.role
    const allowedStates = ['DRAFT', 'REVISION_REQUIRED_INITIAL', 'WAITING_FOR_UPDATE']
    return allowedStates.includes(projectState) && userRole === 'CUSTOMER'
  })

  const canDelete = computed(() => store.user.role === 'SUPER_ADMIN')

  const fetchFiles = async () => {
    loading.value = true
    try {
      files.value = await api.getProjectFiles(projectId)
    } finally {
      loading.value = false
    }
  }

  const upload = async (file: File) => {
    if (!canUpload.value) throw new Error('Upload not allowed')
    const requestId = crypto.randomUUID()
    const uploaded = await api.uploadFile(projectId, file, requestId)
    files.value.push({ ...uploaded, uploaded_by: store.user.user_id })
    return uploaded
  }

  const remove = async (fileId: string) => {
    if (!canDelete.value) throw new Error('Delete not allowed')
    const requestId = crypto.randomUUID()
    const deleted = await api.deleteFile(projectId, fileId, requestId)
    files.value = files.value.map(f => f.file_id === fileId ? { ...f, status: 'DELETED' } : f)
    return deleted
  }

  return {
    files,
    loading,
    canUpload,
    canDelete,
    fetchFiles,
    upload,
    remove
  }
}
