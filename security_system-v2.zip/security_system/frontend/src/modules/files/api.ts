import axios from 'axios'
import type { ProjectFile, FileUploadResponse, FileDeleteResponse } from './types'

const API_BASE = '/api/v1/projects'

export const uploadFile = async (projectId: string, file: File, requestId: string) => {
  const formData = new FormData()
  formData.append('file', file)
  const res = await axios.post<FileUploadResponse>(`${API_BASE}/${projectId}/files`, formData, {
    headers: { 'X-Request-Id': requestId }
  })
  return res.data
}

export const deleteFile = async (projectId: string, fileId: string, requestId: string) => {
  const res = await axios.delete<FileDeleteResponse>(`${API_BASE}/${projectId}/files/${fileId}`, {
    headers: { 'X-Request-Id': requestId }
  })
  return res.data
}

export const getProjectFiles = async (projectId: string): Promise<ProjectFile[]> => {
  const res = await axios.get<ProjectFile[]>(`${API_BASE}/${projectId}/files`)
  return res.data
}
