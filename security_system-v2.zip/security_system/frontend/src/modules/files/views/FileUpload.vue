<template>
  <v-card>
    <v-card-title>Upload Files</v-card-title>
    <v-card-text>
      <v-file-input
        v-model="selectedFile"
        label="Select file"
        accept=".zip,.rar"
        :disabled="!canUpload"
        @change="onUpload"
      />
      <v-progress-linear v-if="loading" indeterminate color="primary" class="my-2" />
      <v-list>
        <v-list-item
          v-for="file in files"
          :key="file.file_id"
        >
          <v-list-item-content>{{ file.filename }}</v-list-item-content>
          <v-list-item-action>
            <v-btn icon @click="deleteFile(file.file_id)" v-if="canDelete && file.status !== 'DELETED'">
              <v-icon>mdi-delete</v-icon>
            </v-btn>
          </v-list-item-action>
        </v-list-item>
      </v-list>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useFiles } from '../composables/useFiles'

const props = defineProps<{
  projectId: string
  projectState: string
}>()

const { files, loading, canUpload, canDelete, fetchFiles, upload, remove } = useFiles(props.projectId, props.projectState)
const selectedFile = ref<File | null>(null)

const onUpload = async () => {
  if (!selectedFile.value) return
  try {
    await upload(selectedFile.value)
    selectedFile.value = null
  } catch (err: any) {
    console.error(err)
    alert(err.message)
  }
}

const deleteFile = async (fileId: string) => {
  try {
    await remove(fileId)
  } catch (err: any) {
    console.error(err)
    alert(err.message)
  }
}

onMounted(fetchFiles)
</script>
