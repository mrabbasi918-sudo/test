# Files Module

Handles **file upload, listing, and deletion** for Security Assessment projects.

## Features
- Immutable, versioned files per project version
- Role-based access:
  - Customer: upload in DRAFT / REVISION_REQUIRED_INITIAL / WAITING_FOR_UPDATE
  - SUPER_ADMIN: soft-delete any file
- Integration with MinIO backend
- Audit-friendly logs
- File metadata stored in ProjectFile

## API
- `POST /api/v1/projects/{project_id}/files` → upload file (zip/rar ≤100MB, immutable)
- `GET /api/v1/projects/{project_id}/files` → list project files
- `DELETE /api/v1/projects/{project_id}/files/{file_id}` → soft delete by SUPER_ADMIN

## Composables
- `useFiles(projectId)` → fetch, upload, delete files
- Checks project state and user role before allowing action

## Frontend
- `FileUpload.vue` → drag & drop, progress bar, notifications
- Role-based UI and file actions
