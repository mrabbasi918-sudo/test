export type FileStatus = 'UPLOADED' | 'DELETED'

export interface ProjectFile {
  file_id: string
  filename: string
  path: string
  uploaded_by: string
  role: 'CUSTOMER' | 'INTERNAL_MANAGER' | 'TECH_MANAGER' | 'SUPER_ADMIN'
  project_version: number
  status: FileStatus
  uploaded_at: string
  size: number // in bytes
}

export interface FileUploadResponse {
  file_id: string
  status: FileStatus
  path: string
}

export interface FileDeleteResponse {
  file_id: string
  status: FileStatus
}

export interface ApiError {
  error_code: string
  message: string
  details?: any
}
