export interface AuditLog {
  log_id: string
  project_id?: string
  project_version?: number
  user_id: string
  role: 'CUSTOMER' | 'INTERNAL_MANAGER' | 'TECH_MANAGER' | 'SUPER_ADMIN'
  action_type: string
  timestamp: string // ISO-8601
  details: any
}

export interface AuditQuery {
  project_id?: string
  user_id?: string
  action_type?: string
  date_from?: string
  date_to?: string
}

export interface AuditResponse {
  logs: AuditLog[]
  total: number
  page: number
  size: number
}
