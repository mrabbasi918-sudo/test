# Audit Module

Provides append-only audit logs for Security Assessment platform.

## Features
- Logs every state transition, upload/download, role/user changes, login/logout
- Role-based access: only authenticated users with proper roles
- Supports filtering by project_id, user_id, action_type, date range
- Pagination support

## API
- `GET /audit/logs` → fetch audit logs with filters and pagination

## Frontend
- `AuditLogs.vue` → searchable, paginated log viewer
