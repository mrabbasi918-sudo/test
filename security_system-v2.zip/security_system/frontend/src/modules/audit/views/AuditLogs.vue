<template>
  <v-card>
    <v-card-title>Audit Logs</v-card-title>
    <v-card-text>
      <v-form @submit.prevent="search">
        <v-text-field v-model="filters.project_id" label="Project ID" />
        <v-text-field v-model="filters.user_id" label="User ID" />
        <v-text-field v-model="filters.action_type" label="Action Type" />
        <v-text-field v-model="filters.date_from" type="date" label="From" />
        <v-text-field v-model="filters.date_to" type="date" label="To" />
        <v-btn type="submit">Search</v-btn>
      </v-form>

      <v-data-table
        :headers="headers"
        :items="logs"
        :items-per-page="pageSize"
        :page.sync="page"
        class="elevation-1"
      >
        <template #item.details="{ item }">
          <pre>{{ item.details }}</pre>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
import { ref, reactive, watchEffect } from 'vue'
import * as api from '../api'
import type { AuditLog, AuditQuery } from '../types'

const filters = reactive<AuditQuery>({
  project_id: '',
  user_id: '',
  action_type: '',
  date_from: '',
  date_to: ''
})

const logs = ref<AuditLog[]>([])
const page = ref(1)
const pageSize = 20

const headers = [
  { text: 'Timestamp', value: 'timestamp' },
  { text: 'User ID', value: 'user_id' },
  { text: 'Role', value: 'role' },
  { text: 'Action', value: 'action_type' },
  { text: 'Project ID', value: 'project_id' },
  { text: 'Version', value: 'project_version' },
  { text: 'Details', value: 'details' }
]

const fetchLogs = async () => {
  const res = await api.getAuditLogs(filters, page.value, pageSize)
  logs.value = res.logs
}

const search = () => {
  page.value = 1
  fetchLogs()
}

watchEffect(() => fetchLogs())
</script>
