import axios from 'axios'
import type { AuditQuery, AuditResponse } from './types'
import { useStore } from '@/store/user'

const API_BASE = '/api/v1/audit'

export const getAuditLogs = async (query: AuditQuery, page = 1, size = 20) => {
  const store = useStore()
  const params = { ...query, page, size }
  const res = await axios.get<AuditResponse>(`${API_BASE}/logs`, {
    params,
    headers: {
      'X-Request-Id': crypto.randomUUID(),
      'Authorization': `Bearer ${store.token}`
    }
  })
  return res.data
}
