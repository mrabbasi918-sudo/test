import client from '@/shared/api/client'
import { LoginRequest, LoginResponse, OtpRequest, OtpVerifyRequest } from './types'

const BASE_URL = '/api/v1/auth'

export async function loginApi(data: LoginRequest): Promise<LoginResponse> {
  return client.post(`${BASE_URL}/login`, data)
}

export async function logoutApi(): Promise<void> {
  return client.post(`${BASE_URL}/logout`)
}

export async function requestOtpApi(data: OtpRequest): Promise<void> {
  return client.post(`${BASE_URL}/otp/request`, data)
}

export async function verifyOtpApi(data: OtpVerifyRequest): Promise<LoginResponse> {
  return client.post(`${BASE_URL}/otp/verify`, data)
}
