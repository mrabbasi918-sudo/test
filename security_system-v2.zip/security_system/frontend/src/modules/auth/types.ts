// DTOs و تایپ‌ها برای Auth

export interface LoginRequest {
  username: string
  password: string
  captcha: string
}

export interface LoginResponse {
  id: string
  fullName: string
  role: 'CUSTOMER' | 'INTERNAL_MANAGER' | 'TECH_MANAGER' | 'SUPER_ADMIN'
  token: string // JWT
}

export interface OtpRequest {
  mobile: string
  captcha: string
}

export interface OtpVerifyRequest {
  mobile: string
  otp: string
  newPassword?: string
}

export interface ApiError {
  error_code: string
  message: string
  details?: any
}
