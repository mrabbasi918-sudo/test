import { ref } from 'vue'
import { useUserStore } from '@/store/user'
import { loginApi, logoutApi, requestOtpApi, verifyOtpApi } from '../api'
import type { LoginRequest, OtpRequest, OtpVerifyRequest, LoginResponse } from '../types'

export function useAuth() {
  const userStore = useUserStore()
  const loading = ref(false)
  const error = ref<string | null>(null)
  const attempts = ref(0)
  const maxAttempts = 5
  const isLocked = ref(false)

  // Login
  const login = async (data: LoginRequest) => {
    if (isLocked.value) {
      error.value = `Account locked. Try again later.`
      return
    }

    loading.value = true
    error.value = null

    try {
      const res: LoginResponse = await loginApi(data)
      userStore.login(res)
      attempts.value = 0
    } catch (err: any) {
      attempts.value++
      error.value = err?.message || 'Login failed'
      if (attempts.value >= maxAttempts) isLocked.value = true
      throw err
    } finally {
      loading.value = false
    }
  }

  // Logout
  const logout = async () => {
    loading.value = true
    try {
      await logoutApi()
      userStore.logout()
    } finally {
      loading.value = false
    }
  }

  // OTP Request
  const requestOtp = async (data: OtpRequest) => {
    loading.value = true
    try {
      await requestOtpApi(data)
    } finally {
      loading.value = false
    }
  }

  // OTP Verify
  const verifyOtp = async (data: OtpVerifyRequest) => {
    loading.value = true
    try {
      const res = await verifyOtpApi(data)
      userStore.login(res)
    } finally {
      loading.value = false
    }
  }

  return {
    loading,
    error,
    attempts,
    isLocked,
    login,
    logout,
    requestOtp,
    verifyOtp
  }
}
