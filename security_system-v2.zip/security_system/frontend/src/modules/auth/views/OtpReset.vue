<template>
  <v-container>
    <v-form @submit.prevent="handleOtpRequest">
      <v-text-field v-model="mobile" label="Mobile Number" required />
      <v-text-field v-model="captcha" label="Captcha" required>
        <template #append>
          <img :src="captchaImage" @click="refreshCaptcha" alt="Captcha" />
        </template>
      </v-text-field>
      <v-btn :loading="loading" type="submit">Request OTP</v-btn>
      <v-alert v-if="error" type="error">{{ error }}</v-alert>
    </v-form>

    <v-form v-if="otpSent" @submit.prevent="handleOtpVerify">
      <v-text-field v-model="otp" label="OTP" required />
      <v-text-field v-model="newPassword" label="New Password" type="password" />
      <v-btn :loading="loading" type="submit">Verify OTP</v-btn>
    </v-form>
  </v-container>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useAuth } from '../composables/useAuth'

const mobile = ref('')
const captcha = ref('')
const otp = ref('')
const newPassword = ref('')
const captchaImage = ref('/api/v1/auth/captcha')
const otpSent = ref(false)

const { requestOtp, verifyOtp, loading, error } = useAuth()

const handleOtpRequest = async () => {
  try {
    await requestOtp({ mobile: mobile.value, captcha: captcha.value })
    otpSent.value = true
  } catch {}
}

const handleOtpVerify = async () => {
  try {
    await verifyOtp({ mobile: mobile.value, otp: otp.value, newPassword: newPassword.value || undefined })
    window.location.href = '/'
  } catch {}
}

const refreshCaptcha = () => {
  captchaImage.value = `/api/v1/auth/captcha?ts=${Date.now()}`
}
</script>
