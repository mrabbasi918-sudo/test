<template>
  <v-container>
    <v-form @submit.prevent="handleLogin">
      <v-text-field v-model="username" label="Username" required />
      <v-text-field v-model="password" label="Password" type="password" required />
      <v-text-field v-model="captcha" label="Captcha" required>
        <template #append>
          <img :src="captchaImage" @click="refreshCaptcha" alt="Captcha" />
        </template>
      </v-text-field>
      <v-btn :loading="loading" type="submit" :disabled="isLocked">Login</v-btn>
      <v-alert v-if="error" type="error">{{ error }}</v-alert>
      <v-alert v-if="isLocked" type="warning">
        Account locked due to multiple failed attempts.
      </v-alert>
    </v-form>
  </v-container>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useAuth } from '../composables/useAuth'

const username = ref('')
const password = ref('')
const captcha = ref('')
const captchaImage = ref('/api/v1/auth/captcha')

const { login, loading, error, isLocked, attempts } = useAuth()

const handleLogin = async () => {
  try {
    await login({ username: username.value, password: password.value, captcha: captcha.value })
    // Redirect to Dashboard
    window.location.href = '/'
  } catch {}
}

const refreshCaptcha = () => {
  captchaImage.value = `/api/v1/auth/captcha?ts=${Date.now()}`
}
</script>
